# ApexImageSDK v2.9.0

SDK JavaScript orientado a PWA y Oracle APEX para captura/selección, edición, compresión y carga asíncrona de imágenes documentales.

## Novedades v2.9.0

- Se elimina el slider de rotación libre. La rotación manual queda limitada a **±90°**.
- Nuevo botón **Enderezar automáticamente**: analiza bordes y líneas dominantes en una copia reducida de la imagen y corrige pequeñas inclinaciones de hasta ±15°.
- El análisis se ejecuta en Web Worker cuando está disponible, para mantener fluida la interfaz.
- Si la confianza de detección es insuficiente, la imagen no se modifica.
- **Imagen completa** ahora conserva la orientación y cualquier enderezado aplicado; solo recalcula encuadre, zoom, pan y recorte.
- Corregido el salto de zoom después de **Imagen completa**: un nuevo pinch parte de la escala visual actual, incluso cuando es menor que el zoom base de cobertura.
- Dos dedos continúan permitiendo pan + zoom simultáneo y nunca producen rotación.
- **Restablecer** es la única acción que devuelve orientación/enderezado al estado original.
- El flujo sigue orientado a documentos requeridos: cargar de nuevo reemplaza la imagen existente; no se ofrece Eliminar.

## Modelo táctil

- 1 dedo fuera del recorte: mover imagen.
- 1 dedo dentro del recorte: mover recorte.
- Arrastrar cualquiera de los 8 manejadores: redimensionar recorte.
- 2 dedos, misma separación y misma dirección: mover imagen.
- 2 dedos acercándose/alejándose: zoom.
- 2 dedos desplazándose mientras cambia la separación: pan + zoom simultáneo.
- Giro de los dedos: sin efecto.
- `Enderezar automáticamente`: corrección automática de pequeñas inclinaciones, sin slider manual.

## Integración Oracle APEX

Archivos recomendados como Static Application Files:

```text
apex-image-sdk.css
apex-image-sdk.js
apex-image-worker.js
```

Carga:

```text
#APP_FILES#apex-image-sdk.css
#APP_FILES#apex-image-sdk.js
```

Instancia:

```javascript
const imageSdk = new ApexImageSDK({
  target: '#apexImageSdkHost',
  ui: { showLauncher: false, showPreview: false },
  autoUpload: true,
  compression: {
    targetKB: 150,
    toleranceKB: 8,
    maxWidth: 1920,
    maxHeight: 1920,
    workerUrl: '#APP_FILES#apex-image-worker.js'
  },
  upload: {
    mode: 'apexProcess',
    apexProcess: 'GUARDAR_DOCUMENTO_IMAGEN',
    requestIdKey: 'x01',
    documentIdKey: 'x02',
    base64ArrayKey: 'f01',
    refreshRegionStaticId: 'DOCUMENTOS_REPORT'
  }
}).init();
```

Desde el botón flotante de cada fila/tarjeta:

```javascript
imageSdk.openCamera({
  requestId: $v('P20_ID_SOLICITUD'),
  documentId: idDocumento,
  documentTitle: tituloDocumento
});
```

o:

```javascript
imageSdk.openGallery({
  requestId: $v('P20_ID_SOLICITUD'),
  documentId: idDocumento,
  documentTitle: tituloDocumento
});
```

## Reemplazo, no eliminación

El proceso `GUARDAR_DOCUMENTO_IMAGEN` actualiza el registro existente usando **ID_SOLICITUD + ID_DOCUMENTO**. Si ya existe imagen, el nuevo CLOB la reemplaza solamente después de completar satisfactoriamente el proceso.

El servidor debe validar que el documento pertenece a la solicitud y que la sesión actual tiene autorización para modificarla.

Ejemplo simplificado de reconstrucción del CLOB:

```sql
DECLARE
    l_clob          CLOB;
    l_id_solicitud  NUMBER := TO_NUMBER(apex_application.g_x01);
    l_id_documento  NUMBER := TO_NUMBER(apex_application.g_x02);
BEGIN
    DBMS_LOB.CREATETEMPORARY(l_clob, TRUE);

    FOR i IN 1 .. apex_application.g_f01.COUNT LOOP
        DBMS_LOB.WRITEAPPEND(
            l_clob,
            LENGTH(apex_application.g_f01(i)),
            apex_application.g_f01(i)
        );
    END LOOP;

    UPDATE documentos_cliente d
       SET d.archivo_clob = l_clob
     WHERE d.id_solicitud = l_id_solicitud
       AND d.id_documento = l_id_documento;

    IF SQL%ROWCOUNT <> 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Documento no válido para la solicitud.');
    END IF;

    apex_json.open_object;
    apex_json.write('success', TRUE);
    apex_json.close_object;
END;
```

Agrega a ese `UPDATE` la validación/autorización propia de tu aplicación.

Después de una respuesta satisfactoria, el SDK puede refrescar `DOCUMENTOS_REPORT` para que la miniatura visible provenga nuevamente del servidor.

## Demo

`demo.html` simula el Classic Report como galería de documentos obligatorios. Una imagen cargada se visualiza tocando la miniatura y se reemplaza mediante el mismo botón flotante Cámara/Fotos. No existe acción Eliminar.

Para probar Worker/cámara, sirve la carpeta por HTTP/HTTPS, por ejemplo:

```bash
python -m http.server 8080
```

## Cambios v2.9.0
- Auto-enderezado reforzado para documentos rectangulares sobre fondos con textura: prioriza bordes fuertes, reduce interferencia del fondo y calcula confianza por coherencia del ángulo dominante.
- El análisis conserva el límite de seguridad de ±15° y no modifica la imagen cuando la evidencia no es suficiente.
- El cálculo de altura móvil ahora incluye el bloque Enderezar, evitando que las acciones queden expulsadas del viewport.
- Guardar y Cancelar permanecen accesibles en el pie del editor; en móvil se oculta la ayuda extensa para priorizar la fotografía y las acciones.
- Imagen completa conserva la orientación/enderezado actual.

## v2.9.0 — detección geométrica de bordes rectos

El autoenderezado ya no presupone un fondo blanco. El analizador `straight-lines-v3` prioriza **líneas rectas largas, continuidad espacial, pares de bordes horizontales/verticales y proximidad al perímetro**, reduciendo el peso de texto, estampados, tela, madera y otras texturas cortas. La corrección continúa limitada por `straightenMaxAngle` y solo se aplica cuando supera el umbral de confianza configurado.

### Oracle APEX: visualización eficiente de imágenes almacenadas en CLOB

El SDK puede visualizar una imagen almacenada como Base64 en un CLOB, pero para producción no se recomienda concatenar todos los CLOB como `data:image/jpeg;base64,...` dentro del HTML del Classic Report. Base64 añade aproximadamente un tercio de sobrecarga y varias imágenes embebidas aumentan el peso inicial de la página.

La arquitectura recomendada es que el Classic Report devuelva metadatos (`ID_SOLICITUD`, `ID_DOCUMENTO`, tipo de documento y si tiene imagen) y una **URL segura de imagen**. Esa URL debe apuntar a un Application Process/endpoint APEX que valide la sesión, `ID_SOLICITUD`, `ID_DOCUMENTO` y la autorización del usuario antes de leer el CLOB y entregar la imagen. El visor/galería usa esa URL como `src` normal del `<img>`.

Ventajas:

- el HTML del Classic Report permanece liviano;
- el navegador solicita cada imagen como un recurso independiente;
- se puede aprovechar caché HTTP cuando la política de seguridad lo permita;
- el refresh de la región no necesita transportar todos los Base64 embebidos;
- la autorización se valida también al consultar el archivo, no solamente al subirlo;
- el mismo recurso sirve para miniatura y visor, o pueden implementarse endpoints separados para thumbnails.

Para cargas se mantiene la estrategia existente: comprimir primero en cliente, convertir a Base64 al final, dividir con `apex.server.chunk(base64)`, enviar los chunks en `f01` y los identificadores en `x01/x02`. El servidor debe reconstruir el CLOB y validar ambos identificadores y la sesión antes de actualizar el registro. Después de guardar, refrescar el Classic Report con `apex.region("DOCUMENTOS_REPORT").refresh()`.

> Si el esquema puede evolucionar en el futuro, un BLOB es más natural para contenido binario. El SDK mantiene compatibilidad con CLOB Base64 porque ese es el modelo actual de integración.
