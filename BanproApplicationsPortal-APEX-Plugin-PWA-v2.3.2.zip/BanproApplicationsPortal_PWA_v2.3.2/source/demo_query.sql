select 'cobranzas-movil' app_id,
       'Cobranzas Móvil' app_name,
       'Registra y da seguimiento a las visitas de cobro realizadas a clientes.' app_description,
       'WS_COBRANZAS' app_workspace,
       'fa-file-text-o' app_icon
  from dual
union all
select 'entrega-tarjetas',
       'Entrega de tarjetas',
       'Registra y gestiona la entrega a clientes de tarjetas de crédito, débito y prepago, brazaletes y otros medios de pago.',
       'WS_TARJETAS',
       'fa-credit-card'
  from dual