procedure render_region (
 p_plugin in apex_plugin.t_plugin,
 p_region in apex_plugin.t_region,
 p_param  in apex_plugin.t_region_render_param,
 p_result in out nocopy apex_plugin.t_region_render_result )
is l_ctx apex_exec.t_context; l_cols apex_exec.t_columns;
 l_count pls_integer; l_id pls_integer; l_name pls_integer; l_desc pls_integer; l_ws pls_integer; l_icon pls_integer;
 l_title varchar2(32767):=p_region.attributes.get_varchar2('TITLE');
 l_kicker varchar2(32767):=p_region.attributes.get_varchar2('KICKER');
 l_section_label varchar2(32767):=p_region.attributes.get_varchar2('SECTION_LABEL');
 l_section_title varchar2(32767):=p_region.attributes.get_varchar2('SECTION_TITLE');
 l_favorites_label varchar2(32767):=p_region.attributes.get_varchar2('FAVORITES_LABEL');
 l_all_label varchar2(32767):=p_region.attributes.get_varchar2('ALL_LABEL');
 l_search_placeholder varchar2(32767):=p_region.attributes.get_varchar2('SEARCH_PLACEHOLDER');
 l_access_label varchar2(32767):=p_region.attributes.get_varchar2('ACCESS_LABEL');
 l_empty_fav_title varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_FAV_TITLE');
 l_empty_fav_text varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_FAV_TEXT');
 l_empty_fav_button varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_FAV_BUTTON');
 l_empty_search_title varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_SEARCH_TITLE');
 l_empty_search_text varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_SEARCH_TEXT');
 l_empty_apps_title varchar2(32767):=p_region.attributes.get_varchar2('EMPTY_APPS_TITLE');
 l_open_callback varchar2(32767):=trim(p_region.attributes.get_varchar2('OPEN_CALLBACK'));
 l_dom varchar2(255):='bp_portal_'||p_region.id; l_app_id varchar2(4000); l_app_name varchar2(4000);
 l_app_desc varchar2(4000); l_workspace varchar2(4000); l_app_icon varchar2(4000); l_meta clob;
 function h(v varchar2,d varchar2) return varchar2 is begin return apex_escape.html(nvl(v,d)); end;
 function dn(v varchar2) return varchar2 is begin return lower(regexp_replace(v,'[^A-Za-z0-9_-]+','-')); end;
 function cv(i pls_integer) return varchar2 is c apex_exec.t_column;
 begin c:=apex_exec.get_column(l_ctx,i);
   case c.data_type
    when apex_exec.c_data_type_number then return to_char(apex_exec.get_number(l_ctx,i));
    when apex_exec.c_data_type_date then return to_char(apex_exec.get_date(l_ctx,i),'YYYY-MM-DD"T"HH24:MI:SS');
    when apex_exec.c_data_type_timestamp then return to_char(apex_exec.get_timestamp(l_ctx,i),'YYYY-MM-DD"T"HH24:MI:SS.FF');
    else return apex_exec.get_varchar2(l_ctx,i);
   end case;
 exception when others then return null; end;
begin
 if apex_application.g_debug then apex_plugin_util.debug_region(p_plugin=>p_plugin,p_region=>p_region); end if;
 apex_css.add_file(p_name=>'banpro-applications-portal',p_directory=>p_plugin.file_prefix);
 apex_javascript.add_library(p_name=>'banpro-applications-portal',p_directory=>p_plugin.file_prefix);
 sys.htp.p('<div id="'||apex_escape.html_attribute(l_dom)||'" class="bp-portal" data-click-action="'||apex_escape.html_attribute(nvl(l_open_callback,''))||'">');
 sys.htp.p('<section class="bp-hero"><div class="bp-hero-in"><div class="bp-kicker">'||h(l_kicker,'ECOSISTEMA DIGITAL')||'</div><h1 class="bp-title">'||h(l_title,'Portal de aplicaciones')||'</h1><div class="bp-search" role="search"><i class="fa fa-search"></i><label class="bp-vh" for="'||l_dom||'_search">Buscar aplicaciones</label><input class="bp-search-input" id="'||l_dom||'_search" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" placeholder="'||apex_escape.html_attribute(nvl(l_search_placeholder,'Buscar por nombre, área o palabra clave...'))||'"><button class="bp-search-clear" type="button" aria-label="Limpiar búsqueda" hidden><i class="fa fa-times"></i></button></div></div><div class="bp-geo" aria-hidden="true"><span class="bp-g bp-g1"></span><span class="bp-g bp-g2"></span><span class="bp-g bp-g3"></span><span class="bp-g bp-g4"></span><img class="bp-geo-star" src="https://www.banprogrupopromerica.com.ni/assets/plugins/GDS/img/svg/estrellaPromericaBlanca.svg" alt=""></div></section>');
 sys.htp.p('<main class="bp-content"><div class="bp-section-head"><div><div class="bp-section-tag">'||h(l_section_label,'CENTRO DE APLICACIONES')||'</div><h2 class="bp-section-title">'||h(l_section_title,'Accesos digitales')||'</h2></div><div class="bp-tools"><span class="bp-counter" aria-live="polite">0 accesos personalizados</span><button class="bp-view is-active" data-bp-layout="grid" type="button" title="Vista cuadrícula"><i class="fa fa-th-large"></i></button><button class="bp-view" data-bp-layout="list" type="button" title="Vista lista"><i class="fa fa-bars"></i></button></div></div>');
 sys.htp.p('<nav class="bp-tabs" role="tablist"><button class="bp-tab is-active" data-bp-view="favorites" type="button" role="tab" aria-selected="true">'||h(l_favorites_label,'Mis favoritos')||' <span class="bp-tab-count bp-fav-count">0</span></button><button class="bp-tab" data-bp-view="all" type="button" role="tab" aria-selected="false">'||h(l_all_label,'Todas')||' <span class="bp-tab-count bp-all-count">0</span></button></nav><div class="bp-apps" role="region" aria-live="polite">');
 l_ctx:=apex_exec.open_query_context(p_location=>apex_exec.c_location_local_db,p_sql_query=>p_region.source);
 l_cols:=apex_exec.get_columns(l_ctx); l_count:=apex_exec.get_column_count(l_ctx);
 l_id:=apex_exec.get_column_position(l_ctx,'APP_ID','APP_ID',true); l_name:=apex_exec.get_column_position(l_ctx,'APP_NAME','APP_NAME',true);
 l_desc:=apex_exec.get_column_position(l_ctx,'APP_DESCRIPTION','APP_DESCRIPTION',true); l_ws:=apex_exec.get_column_position(l_ctx,'APP_WORKSPACE','APP_WORKSPACE',true);
 l_icon:=apex_exec.get_column_position(l_ctx,'APP_ICON','APP_ICON',true);
 declare n pls_integer:=0; begin while apex_exec.next_row(l_ctx) loop n:=n+1;
  l_app_id:=cv(l_id);l_app_name:=cv(l_name);l_app_desc:=cv(l_desc);l_workspace:=cv(l_ws);l_app_icon:=cv(l_icon);
  apex_json.initialize_clob_output;apex_json.open_object;for i in 1..l_count loop apex_json.write(lower(l_cols(i).name),cv(i));end loop;apex_json.close_object;l_meta:=apex_json.get_clob_output;apex_json.free_output;
  sys.htp.prn('<article class="bp-card" data-app-id="'||apex_escape.html_attribute(l_app_id)||'" data-order="'||n||'" data-name="'||apex_escape.html_attribute(l_app_name)||'" data-description="'||apex_escape.html_attribute(l_app_desc)||'" data-search="'||apex_escape.html_attribute(l_app_name||' '||l_app_desc||' '||l_workspace)||'" data-meta="'||apex_escape.html_attribute(l_meta)||'"><div class="bp-card-top"><div class="bp-icon"><i class="fa '||apex_escape.html_attribute(l_app_icon)||'"></i></div><button class="bp-favorite" type="button"><i class="fa fa-star-o"></i></button></div><div class="bp-card-body"><h3 class="bp-card-title">'||apex_escape.html(l_app_name)||'</h3><p class="bp-card-desc">'||apex_escape.html(l_app_desc)||'</p></div><button class="bp-enter" type="button" data-meta="'||apex_escape.html_attribute(l_meta)||'"');
  for i in 1..l_count loop sys.htp.prn(' data-'||dn(l_cols(i).name)||'="'||apex_escape.html_attribute(cv(i))||'"'); end loop;
  sys.htp.p('>'||h(l_access_label,'Acceder')||' <i class="fa fa-arrow-right"></i></button></article>');
 end loop; end; apex_exec.close(l_ctx);
 sys.htp.p('</div><div class="bp-empty" data-bp-empty="favorites" hidden><div class="bp-empty-icon"><i class="fa fa-star-o"></i></div><h3>'||h(l_empty_fav_title,'Personaliza tus accesos')||'</h3><p>'||h(l_empty_fav_text,'Selecciona las aplicaciones que utilizas con mayor frecuencia para tenerlas siempre disponibles en tu vista principal.')||'</p><button class="bp-empty-action bp-open-all" type="button">'||h(l_empty_fav_button,'Explorar todas las aplicaciones')||'</button></div>');
 sys.htp.p('<div class="bp-empty" data-bp-empty="search" hidden><div class="bp-empty-icon"><i class="fa fa-search"></i></div><h3>'||h(l_empty_search_title,'Sin resultados')||'</h3><p>'||h(l_empty_search_text,'No encontramos aplicaciones que coincidan con tu búsqueda.')||'</p></div><div class="bp-empty" data-bp-empty="apps" hidden><div class="bp-empty-icon"><i class="fa fa-th-large"></i></div><h3>'||h(l_empty_apps_title,'No hay aplicaciones disponibles')||'</h3><p>No hay aplicaciones configuradas para mostrar en este momento.</p></div></main>');
 sys.htp.p('</div>');
 apex_javascript.add_onload_code(
   p_code=>'BanproApplicationsPortal.init('||
           apex_escape.js_literal(l_dom)||
           ',{storageKey:'||
           apex_escape.js_literal('banproPortalApps_'||v('APP_ID')||'_'||l_dom||'_favorites')||
           '});'
 );
 p_result.navigable_dom_id:=l_dom||'_search';
exception when others then begin apex_exec.close(l_ctx);exception when others then null;end;raise;
end render_region;