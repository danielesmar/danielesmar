# ApexProductCardsCarousel v2.0.0 — Oracle APEX 24.2.8

Versión configurable por JSON y rediseño compacto.

## Mejoras visuales y de usabilidad
- En móvil el card activo ocupa `100vw - 32px`: 16 px por lado.
- Separación real entre cards: 16 px.
- Imagen: `object-fit: contain`, sin estirar ni recortar.
- Nombre del cliente más grande, negrita y con sombra.
- Botón outline primario, fondo transparente e icono en flujo (no se monta sobre texto).
- Menor padding/altura para intentar mantener todo el card dentro del viewport.
- Gesto horizontal bloquea el desplazamiento vertical accidental dentro del carrusel.

## Configuración JSON
El atributo **Configuración JSON del Card** permite mapear alias del SELECT sin modificar el PL/SQL. Si queda vacío se usa la estructura actual.

Ejemplo:
```json
{
  "titleColumn":"DESCRIPCION_PRODUCTO",
  "imageColumn":"DIR_URL_IMAGEN_FONDO_TJT",
  "panColumn":"NUMERO_DE_TARJETA_MASCARA",
  "holderColumn":"NOMBRE_PLASTICO_TJT",
  "sections":[
    {"fields":[
      {"label":"Número solicitud","column":"ID_SOLICITUD"},
      {"label":"Evento","column":"EVENTO_DE_TARJETA"},
      {"label":"Estado","column":"DES_ESTADO_VISITA_SOLICITUD","type":"status","colorColumn":"COLOR"},
      {"label":"Dato personalizado","column":"MI_COLUMNA","span":"2","classColumn":"MI_CLASE"}
    ]}
  ],
  "button":{
    "permissionColumn":"TIENE_PERMISO_ENTREGAR_TARJETA",
    "textColumn":"TEXTO_BOTON",
    "iconColumn":"ICONO_BOTON",
    "requestColumn":"ID_SOLICITUD",
    "stateColumn":"IND_ESTADO_VISITA_SOLICITUD"
  }
}
```

### Tipos de campo
- `text`: valor normal.
- `status`: badge; `colorColumn` toma el color desde el SELECT.
- `template`: si agrega `template`, puede usar `#LABEL#`, `#VALUE#`, `#CLASS#`, `#COLOR#`. El valor y atributos se escapan antes de insertarse.
- `span: "2"`: ocupa ambas columnas.
- `classColumn`: toma una clase CSS desde el SELECT, sanitizada.

Ejemplo de template:
```json
{"label":"Prioridad","column":"PRIORIDAD","colorColumn":"COLOR_PRIORIDAD","template":"<strong style=\"color:#COLOR#\">#VALUE#</strong>"}
```

El botón conserva exactamente la clase `.entregarTarjeta` y los atributos `data-num-solicitud`, `data-estado-solicitud`, `data-csc-cita`, `data-cod-cliente`.
