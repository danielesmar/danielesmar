# Banpro Applications Portal — CLEAN v2.0.1

Reconstrucción desde cero. No deriva el metadata SQL de las versiones 1.x.

Compatibilidad objetivo:
- Oracle APEX 24.2.x (baseline)
- Oracle APEX 26.1.x (compatibilidad hacia adelante)

## Instalación
Importar `install/region_type_plugin_ni_banpro_applications_portal.sql` como Plug-in.

## Consulta demo
Copiar `source/demo_query.sql` en Source > SQL Query de la región.

Columnas obligatorias:
APP_ID, APP_NAME, APP_DESCRIPTION, APP_WORKSPACE, APP_ICON.

Las columnas adicionales del SELECT se serializan en `data-meta` y en atributos `data-*`.

## Decisiones de compatibilidad
El export usa exclusivamente `wwv_flow_imp` / `wwv_flow_imp_shared`, `SOURCE_LOCATION`,
API version 1 y atributos personalizados de tipo `TEXT`, evitando tipos de metadata
no verificados que pueden provocar ORA-06592 en el importador.

## v2.0.1
Corrección funcional después de la primera instalación exitosa:
- Inicialización movida a `apex_javascript.add_onload_code`.
- Esto garantiza que `BanproApplicationsPortal` exista antes de llamar `init()`.
- Recupera favoritos, agrupamiento Mis favoritos/Todas, contadores, búsqueda,
  limpiar búsqueda, persistencia local y cambio grid/list.
- Eliminado el header/logo propio del componente.
- Eliminado el footer propio del componente.
- No se modificó la metadata de instalación que ya fue aceptada por APEX.

## v2.0.2
- Filtro de tabs y búsqueda reescritos sobre una única función `applyFilters()`.
- Visibilidad usa `hidden` + `display:none` para evitar que Universal Theme anule el filtro.
- Búsqueda toma toda la metadata de la fila y normaliza acentos.
- Se restauraron proporciones/espaciado de cards del prototipo aprobado.
- No se modificó la estructura de instalación que ya instala correctamente.

## v2.0.3
Corrección de regresión v2.0.2: el JavaScript anterior usó selectores que no coincidían
con el HTML real del renderer (`data-tab`, `data-id`, `.bp-access`, etc.). Esta versión
usa exactamente `data-bp-view`, `data-app-id`, `.bp-enter`, `.bp-apps` y `data-bp-empty`.

## v2.0.4
Ajuste exclusivamente visual para PWA/móvil. Se mantiene intacta la lógica funcional
validada en v2.0.3. Las cards recuperan la composición del prototipo: icono a la izquierda,
texto central, favorito a la derecha y botón Acceder a todo el ancho en la segunda fila.
El modo list/grid no puede forzar la card horizontal de escritorio en pantallas <= 800px.


## v2.1.0 — PWA baseline definitivo
- CSS reconstruido desde cero tomando como referencia visual el prototipo v8.0 aprobado.
- No incluye logo/header ni footer propios del plug-in.
- Conserva sin cambios la lógica funcional validada de favoritos, tabs, búsqueda y callbacks.
- Cards PWA: icono + contenido + favorito; botón Acceder a ancho completo.
- Empty state con borde discontinuo y CTA verde sólido.
- Badges circulares en los tabs.
- Se neutralizan estilos de Universal Theme dentro del componente.
- Todos los estados de foco usan el verde del GDS Banpro; no se usa borde azul.
- Esta versión fija primero la experiencia PWA. El layout de escritorio se validará después.


## v2.1.1
- Recuperada animación FLIP de desplazamiento/entrada de cards al cambiar tabs, buscar o modificar favoritos.
- El indicador superior ahora cambia según la vista:
  - Mis favoritos: "N accesos personalizados".
  - Todas: "N aplicaciones disponibles".
- Callback corregido: el atributo APEX se entrega al runtime como texto escapado y JS lo resuelve de forma segura como función.
- Acepta `function(data, button) { ... }` y también cuerpo directo de función.
- Se conserva íntegramente el CSS PWA de v2.1.0.


## v2.1.2
- Callback robustecido: acepta expresión `function(data, button){...}`, arrow function o cuerpo JavaScript.
- El callback se invoca con `this` apuntando al botón Acceder.
- Se dispara además el evento APEX `banproappopen`.
- Orden alfabético estable por `APP_NAME` restaurado.
- La animación FLIP se conserva al filtrar, cambiar tabs y modificar favoritos.


## v2.1.3
- Callback sin `eval()` ni `new Function()`: APEX lo entrega como función JavaScript real al inicializador.
  Esto evita el bloqueo por Content Security Policy (CSP).
- `Todas`: favoritos/seleccionados primero; dentro de favoritos y no favoritos, orden alfabético por nombre.
- `Mis favoritos`: orden alfabético por nombre.
- Al marcar/desmarcar favorito se reordena con animación FLIP.


## v2.1.6
- Corrige el error JavaScript al pulsar Favorito: se eliminó una referencia residual a `before` fuera de alcance.
- El cambio de favorito usa `apply(true)`, por lo que ordenamiento, contador, filtrado y FLIP se ejecutan en una sola ruta.
- FLIP incluye fallback defensivo si `Element.animate()` no está disponible.
- Se sincronizó `source/render_function.sql` con el mecanismo de callback usado por el instalador.


## v2.2.0
- La animación de reordenamiento usa FLIP clásico con `transform` y transición CSS directa de 360 ms.
- Se eliminó la dependencia de `Element.animate()` y de `prefers-reduced-motion` para este desplazamiento solicitado.
- El atributo 15 ya no recibe código JavaScript. Ahora recibe únicamente el nombre de una función global.
- Ejemplo: `abrirAplicacion`
- La función definida en la página debe tener la forma `function abrirAplicacion(data, button) { ... }`.


## v2.2.1
- No se modificó la animación FLIP aprobada de v2.2.0.
- El atributo "Función al hacer clic" se resuelve ahora como referencia JavaScript directa, no mediante `window[nombre]`.
- Para `abrirAplicacion`, el inicializador genera: `(typeof abrirAplicacion==="function"?abrirAplicacion:null)`.
- Solo se aceptan nombres JavaScript simples y seguros en ese atributo.


## v2.2.2
- La animación aprobada de v2.2.0 no se modificó.
- "Función al hacer clic" se envía al runtime únicamente como string.
- El listener `click` del botón Acceder busca `window[actionName]` en ese momento y, si es función, ejecuta `fn(data, button)`.
- Ejemplo de atributo: `abrirAplicacion`.


## v2.2.3
- La animación FLIP aprobada no se modificó.
- El atributo "Función al hacer clic" se inserta como referencia JavaScript directa en la inicialización.
- Si el atributo contiene `abrirAplicacion`, el código generado contiene `clickAction:abrirAplicacion`.
- El listener de Acceder ejecuta directamente `clickAction(data, button)`.
- Se eliminaron `window[actionName]`, `resolveAction` y la resolución indirecta por string.


## v2.2.4
- Diagnóstico corregido: la acción estaba condicionada por `ev.defaultPrevented` después de disparar `banproappopen`.
- Ahora el listener `click` ejecuta PRIMERO y directamente `clickAction(data, button)`.
- Los eventos `banproappopen` se disparan después y ya no pueden impedir la función configurada.
- La animación FLIP aprobada no se modificó.


## v2.2.6
- Contrato final simplificado: la función recibe únicamente `data`.
- El atributo contiene solo el nombre, por ejemplo `abrirAplicacion`.
- El nombre se conserva como string durante init y se resuelve únicamente al hacer click.
- Ejecución: `clickFn(data)`.
- La animación FLIP aprobada no se modificó.


## v2.2.7
- Cambio aislado exclusivamente a la acción de Acceder.
- El atributo sigue siendo un nombre, por ejemplo `abrirAplicacion`.
- En el click se ejecuta literalmente `abrirAplicacion(data)` mediante una función generada en ese momento.
- No se modificó CSS, HTML, ordenamiento, favoritos ni animación FLIP.


## v2.2.9 — corrección APEX 24.2+
El atributo `Función al hacer clic` se lee por su Static ID mediante
`p_region.attributes.get_varchar2('OPEN_CALLBACK')`, que es la API de atributos
de Region Plug-ins en APEX moderno. Se conserva `p_region.attribute_15` solo
como fallback para compatibilidad. El valor se escribe en `data-click-action`.
No se modificaron CSS, HTML visual, favoritos ni animación FLIP.


## v2.3.0 — migración real al API moderno de Region Plug-ins
- Render convertido de Function API legacy a Procedure API.
- `p_api_version` actualizado a 3.
- Los 15 atributos se leen mediante `p_region.attributes.get_varchar2('<STATIC_ID>')`.
- `OPEN_CALLBACK` se escribe en `data-click-action`.
- El JavaScript existente ejecuta `window[clickActionName](data)`.
- CSS y animación FLIP no fueron modificados.

## v2.3.1
Corrige los seis identificadores l_title0..l_title5 generados accidentalmente en 2.3.0. Mantiene Procedure API y lectura por Static ID. Sin cambios CSS/FLIP.

## v2.3.2
Único cambio funcional: favoritos usan `banpro_portal_favorites` como clave estable de localStorage. Sin cambios en callback, renderer, CSS, FLIP, búsqueda, ordenamiento o UI.

## v2.3.3
Cambio único: persistencia de favoritos mediante cookie persistente `banpro_portal_favorites`
(Max-Age=31536000, Path=/, SameSite=Lax, Secure).
No se modificaron callback OPEN_CALLBACK, renderer, FLIP, CSS, búsqueda, ordenamiento ni UI.
El localStorage de layout permanece sin cambios.
