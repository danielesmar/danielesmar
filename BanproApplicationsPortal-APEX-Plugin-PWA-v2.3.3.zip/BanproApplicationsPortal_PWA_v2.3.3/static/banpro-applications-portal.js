(function(w,d){
"use strict";
function norm(s){return (s||"").toString().normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim()}
function meta(el){try{return JSON.parse(el.dataset.meta||"{}")}catch(e){return {}}}

w.BanproApplicationsPortal={init:function(id,o){
 var r=d.getElementById(id); if(!r||r.dataset.bpReady==="1")return; r.dataset.bpReady="1"; o=o||{};
 var apps=r.querySelector(".bp-apps"),
     cards=[].slice.call(r.querySelectorAll(".bp-card")),
     search=r.querySelector(".bp-search-input"), clear=r.querySelector(".bp-search-clear"),
     favTab=r.querySelector('[data-bp-view="favorites"]'), allTab=r.querySelector('[data-bp-view="all"]'),
     favCount=r.querySelector(".bp-fav-count"), allCount=r.querySelector(".bp-all-count"),
     counter=r.querySelector(".bp-counter"),
     emptyFav=r.querySelector('[data-bp-empty="favorites"]'),
     emptySearch=r.querySelector('[data-bp-empty="search"]'),
     emptyApps=r.querySelector('[data-bp-empty="apps"]'),
     openAll=r.querySelector(".bp-open-all"),
     gridBtn=r.querySelector('[data-bp-layout="grid"]'),
     listBtn=r.querySelector('[data-bp-layout="list"]'),
     view="favorites", key="banpro_portal_favorites", favs=new Set(), layout="grid",
     clickActionName=(r.getAttribute("data-click-action")||"").trim();
 try{
  var cookieName=key+"=", cookieValue=document.cookie.split("; ").find(function(c){return c.indexOf(cookieName)===0});
  if(cookieValue){
    (JSON.parse(decodeURIComponent(cookieValue.substring(cookieName.length)))||[]).forEach(function(x){favs.add(String(x))});
  }
}catch(e){}
 try{layout=localStorage.getItem(key+"_layout")||"grid"}catch(e){}

 function show(el,on){if(!el)return;el.hidden=!on;el.style.setProperty("display",on?"":"none",on?"":"important")}
 function save(){
  try{
    document.cookie=key+"="+encodeURIComponent(JSON.stringify(Array.from(favs)))+
      "; Max-Age=31536000; Path=/; SameSite=Lax; Secure";
  }catch(e){}
}
 function cardId(c){return String(c.dataset.appId||"")}
 function setFavUI(c){
   var on=favs.has(cardId(c)),b=c.querySelector(".bp-favorite"),i=b&&b.querySelector("i");
   c.classList.toggle("is-favorite",on);
   if(b){b.classList.toggle("is-active",on);b.setAttribute("aria-pressed",on?"true":"false");
     b.setAttribute("aria-label",(on?"Quitar de favoritos: ":"Agregar a favoritos: ")+(c.dataset.name||"Aplicación"))}
   if(i)i.className=on?"fa fa-star":"fa fa-star-o";
 }
 function searchable(c){
   var m=meta(c),vals=[c.dataset.name,c.dataset.description,c.dataset.search];
   Object.keys(m).forEach(function(k){vals.push(m[k])});
   return norm(vals.join(" "));
 }
 function positions(){
   var p={}; cards.forEach(function(c){var x=c.getBoundingClientRect();if(x.width||x.height)p[cardId(c)]={x:x.left,y:x.top}}); return p;
 }
 function sortCards(){
   if(!apps)return;
   cards.slice().sort(function(a,b){
     if(view==="all"){
       var af=favs.has(cardId(a))?0:1, bf=favs.has(cardId(b))?0:1;
       if(af!==bf)return af-bf;
     }
     return (a.dataset.name||"").localeCompare((b.dataset.name||""),"es",{sensitivity:"base"});
   }).forEach(function(c){apps.appendChild(c)});
 }
 function animateFrom(before){
   if(!before)return;
   var moving=[];
   cards.forEach(function(c){
     if(c.hidden)return;
     var old=before[cardId(c)],now=c.getBoundingClientRect();
     if(!old)return;
     var dx=old.x-now.left,dy=old.y-now.top;
     if(Math.abs(dx)>1||Math.abs(dy)>1){
       c.style.setProperty("transition","none","important");
       c.style.setProperty("transform","translate("+dx+"px,"+dy+"px)","important");
       moving.push(c);
     }
   });
   if(!moving.length)return;
   apps&&apps.offsetHeight;
   requestAnimationFrame(function(){
     moving.forEach(function(c){
       c.style.setProperty("transition","transform 360ms cubic-bezier(.22,.61,.36,1)","important");
       c.style.setProperty("transform","translate(0,0)","important");
     });
     w.setTimeout(function(){
       moving.forEach(function(c){
         c.style.removeProperty("transition");
         c.style.removeProperty("transform");
       });
     },390);
   });
 }
 function counterText(){
   if(view==="favorites"){
     var n=favs.size; return n+" acceso"+(n===1?"":"s")+" personalizado"+(n===1?"":"s");
   }
   var n=cards.length; return n+" aplicaci"+(n===1?"ón":"ones")+" disponible"+(n===1?"":"s");
 }
 function apply(animate){
   var before=animate?positions():null,q=norm(search&&search.value),visible=0;
   cards.forEach(setFavUI);
   sortCards();
   cards.forEach(function(c){
     var on=(view==="all"||favs.has(cardId(c)))&&(!q||searchable(c).indexOf(q)!==-1);
     show(c,on);if(on)visible++;
   });
   if(favCount)favCount.textContent=favs.size;if(allCount)allCount.textContent=cards.length;
   if(counter)counter.textContent=counterText();
   if(favTab){favTab.classList.toggle("is-active",view==="favorites");favTab.setAttribute("aria-selected",view==="favorites"?"true":"false")}
   if(allTab){allTab.classList.toggle("is-active",view==="all");allTab.setAttribute("aria-selected",view==="all"?"true":"false")}
   show(clear,!!q);show(emptyApps,cards.length===0);show(emptySearch,cards.length>0&&!!q&&visible===0);
   show(emptyFav,cards.length>0&&!q&&view==="favorites"&&visible===0);
   if(animate)animateFrom(before);
 }
 function setLayout(v){
   layout=v;if(apps){apps.classList.toggle("is-list",v==="list");apps.classList.toggle("is-grid",v==="grid")}
   if(gridBtn)gridBtn.classList.toggle("is-active",v==="grid");
   if(listBtn)listBtn.classList.toggle("is-active",v==="list");
   try{localStorage.setItem(key+"_layout",v)}catch(e){}
 }
 if(favTab)favTab.addEventListener("click",function(){view="favorites";apply(true)});
 if(allTab)allTab.addEventListener("click",function(){view="all";apply(true)});
 if(search){search.addEventListener("input",function(){apply(true)});search.addEventListener("search",function(){apply(true)})}
 if(clear)clear.addEventListener("click",function(){search.value="";search.focus();apply(true)});
 if(openAll)openAll.addEventListener("click",function(){view="all";apply(true)});
 if(gridBtn)gridBtn.addEventListener("click",function(){setLayout("grid")});
 if(listBtn)listBtn.addEventListener("click",function(){setLayout("list")});
 cards.forEach(function(c){
   var b=c.querySelector(".bp-favorite");
   if(b)b.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();var x=cardId(c);
     if(favs.has(x))favs.delete(x);else favs.add(x);save();
     apply(true);
     if(navigator.vibrate)navigator.vibrate(12);
     r.dispatchEvent(new CustomEvent("banprofavoritechange",{bubbles:true,detail:{data:meta(c),favorite:favs.has(x)}}))
   });
   var enter=c.querySelector(".bp-enter");
   if(enter)enter.addEventListener("click",function(e){
     e.preventDefault();
     var data=meta(enter);

     /* Acción principal: el atributo contiene solo el nombre.
        Se resuelve al producirse el clic, cuando la página APEX ya está cargada. */
     if(clickActionName){
       try{
         var fn=w[clickActionName];
         if(typeof fn==="function"){
           fn(data);
         }else if(w.console){
           console.warn("BanproApplicationsPortal: función no encontrada:",clickActionName);
         }
       }catch(err){
         if(w.console)console.error("BanproApplicationsPortal click:",err);
       }
     }

     /* Eventos informativos posteriores; nunca bloquean la acción principal. */
     try{
       r.dispatchEvent(new CustomEvent("banproappopen",{
         bubbles:true,cancelable:false,detail:{data:data,button:enter}
       }));
     }catch(ignore){}
     if(w.apex&&apex.event&&typeof apex.event.trigger==="function"){
       try{apex.event.trigger(r,"banproappopen",{data:data,button:enter})}catch(ignore2){}
     }
   });
 });
 setLayout(layout);apply(false);
}};
})(window,document);