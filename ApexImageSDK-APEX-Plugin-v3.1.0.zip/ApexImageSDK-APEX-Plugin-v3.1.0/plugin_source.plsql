function is_editable(
    p_region     in apex_plugin.t_region,
    p_request_id in varchar2
) return boolean is
    l_sql    varchar2(32767) := trim(p_region.attribute_12);
    l_value  varchar2(30);
begin
    if l_sql is null then
        return true;
    end if;

    /*
       El SQL de editabilidad puede ser de cualquiera de estas formas:
         select 'Y' from dual
         select ... where codigo_sol = :1
         select ... where codigo_sol = :P_CODIGO_SOL
       ORA-01006 ocurría cuando se enviaba USING aunque el SQL no tenía bind.
    */
    if regexp_like(l_sql, ':[A-Za-z0-9_$#]+') then
        execute immediate l_sql into l_value using p_request_id;
    else
        execute immediate l_sql into l_value;
    end if;

    return upper(trim(nvl(l_value, 'N'))) in ('Y','YES','S','SI','1','TRUE');
exception
    when no_data_found then
        return false;
    when too_many_rows then
        raise_application_error(-20031, 'El SQL de editabilidad debe devolver una sola fila.');
end;

function safe_name(p_value varchar2) return varchar2 is
begin
    return dbms_assert.simple_sql_name(trim(p_value));
end;

function f_render (
    p_region                in apex_plugin.t_region,
    p_plugin                in apex_plugin.t_plugin,
    p_is_printer_friendly   in boolean
) return apex_plugin.t_region_render_result is
    l_result       apex_plugin.t_region_render_result;
    l_host_id      varchar2(255) := nvl(p_region.static_id, 'apxisdk_' || p_region.id) || '_sdk';
    l_ajax         varchar2(4000) := apex_plugin.get_ajax_identifier;
    l_request_item varchar2(255) := p_region.attribute_01;
    l_target_kb    number := nvl(to_number(p_region.attribute_13), 150);
    l_max_width    number := nvl(to_number(p_region.attribute_14), 1920);
    l_max_height   number := nvl(to_number(p_region.attribute_15), 1920);
    l_code         varchar2(32767);
begin
    htp.p('<div id="' || apex_escape.html_attribute(l_host_id) || '" class="apxisdk-plugin-root"></div>');

    l_code := 'ApexImageSDKPlugin.init({' ||
        'regionId:' || apex_javascript.add_value(l_host_id, false) || ',' ||
        'ajaxIdentifier:' || apex_javascript.add_value(l_ajax, false) || ',' ||
        'requestItem:' || apex_javascript.add_value(l_request_item, false) || ',' ||
        'workerUrl:' || apex_javascript.add_value(p_plugin.file_prefix || 'apex-image-worker.js', false) || ',' ||
        'targetKB:' || to_char(l_target_kb, 'FM9999990D999', 'NLS_NUMERIC_CHARACTERS=''.,''') || ',' ||
        'maxWidth:' || to_char(l_max_width) || ',' ||
        'maxHeight:' || to_char(l_max_height) || ',' ||
        'primaryColor:' || apex_javascript.add_value('#08783e', false) ||
        '}).catch(function(e){console.error(''ApexImageSDK Plugin'',e);});';

    apex_javascript.add_onload_code(p_code => l_code, p_key => 'apxisdk_' || p_region.id);
    return l_result;
end;

function f_ajax (
    p_region in apex_plugin.t_region,
    p_plugin in apex_plugin.t_plugin
) return apex_plugin.t_region_ajax_result is
    l_result       apex_plugin.t_region_ajax_result;
    l_action       varchar2(20) := upper(nvl(apex_application.g_x10, 'LIST'));
    l_request_id   varchar2(4000) := apex_util.get_session_state(p_region.attribute_01);
    l_doc_id       varchar2(4000) := apex_application.g_x01;

    l_table        varchar2(261) := safe_name(nvl(p_region.attribute_02, 'APP_IMAGENES'));
    l_id_col       varchar2(261) := safe_name(nvl(p_region.attribute_03, 'ID'));
    l_req_col      varchar2(261) := safe_name(nvl(p_region.attribute_04, 'CODIGO_SOL'));
    l_title_col    varchar2(261) := safe_name(nvl(p_region.attribute_05, 'TITULO_DOC'));
    l_blob_col     varchar2(261) := safe_name(nvl(p_region.attribute_06, 'IMAGEN_BLOB'));
    l_mime_col     varchar2(261) := safe_name(nvl(p_region.attribute_07, 'MIME_TYPE'));
    l_file_col     varchar2(261) := safe_name(nvl(p_region.attribute_08, 'NOMBRE_ARCHIVO'));
    l_size_col     varchar2(261) := safe_name(nvl(p_region.attribute_09, 'TAMANO_BYTES'));
    l_date_col     varchar2(261) := safe_name(nvl(p_region.attribute_10, 'FECHA_CARGA'));
    l_user_col     varchar2(261) := safe_name(nvl(p_region.attribute_11, 'USUARIO_CARGA'));

    l_sql          varchar2(32767);
    l_cur          sys_refcursor;
    l_id           varchar2(4000);
    l_title        varchar2(4000);
    l_loaded       number;
    l_total        number := 0;
    l_loaded_count number := 0;
    l_editable     boolean;

    l_blob         blob;
    l_clob         clob;
    l_b64          clob;
    l_mime         varchar2(100);
    l_filename     varchar2(255);
    l_size         number;
    l_user         varchar2(255);
begin
    if l_request_id is null then
        l_request_id := apex_application.g_x02;
    end if;
    if l_request_id is null and l_action = 'LIST' then
        l_request_id := apex_application.g_x01;
    end if;
    if l_request_id is null then
        raise_application_error(-20001, 'No se recibió el identificador de la solicitud.');
    end if;

    l_editable := is_editable(p_region, l_request_id);

    if l_action = 'LIST' then
        apex_json.open_object;
        apex_json.write('success', true);
        apex_json.write('requestId', l_request_id);
        apex_json.write('editable', l_editable);
        apex_json.open_array('documents');

        l_sql := 'select to_char(' || l_id_col || '), ' || l_title_col ||
                 ', case when ' || l_blob_col || ' is not null then 1 else 0 end ' ||
                 'from ' || l_table || ' where ' || l_req_col || ' = :1 order by ' || l_id_col;
        open l_cur for l_sql using l_request_id;
        loop
            fetch l_cur into l_id, l_title, l_loaded;
            exit when l_cur%notfound;
            l_total := l_total + 1;
            if l_loaded = 1 then l_loaded_count := l_loaded_count + 1; end if;
            apex_json.open_object;
            apex_json.write('id', l_id);
            apex_json.write('title', l_title);
            apex_json.write('loaded', l_loaded = 1);
            apex_json.close_object;
        end loop;
        close l_cur;

        apex_json.close_array;
        apex_json.write('total', l_total);
        apex_json.write('loaded', l_loaded_count);
        apex_json.write('pending', l_total - l_loaded_count);
        apex_json.close_object;

    elsif l_action = 'GET' then
        l_sql := 'select ' || l_blob_col || ', ' || l_mime_col || ', ' || l_file_col ||
                 ' from ' || l_table || ' where ' || l_id_col || ' = :1 and ' || l_req_col || ' = :2';
        execute immediate l_sql into l_blob, l_mime, l_filename using l_doc_id, l_request_id;
        if l_blob is null then raise no_data_found; end if;
        l_b64 := apex_web_service.blob2clobbase64(l_blob);
        apex_json.open_object;
        apex_json.write('success', true);
        apex_json.write('mimeType', nvl(l_mime, 'image/jpeg'));
        apex_json.write('fileName', nvl(l_filename, 'imagen'));
        apex_json.write('base64', l_b64);
        apex_json.close_object;

    elsif l_action = 'SAVE' then
        if not l_editable then
            raise_application_error(-20010, 'La solicitud ya fue entregada y sus imágenes son de solo lectura.');
        end if;

        l_doc_id := apex_application.g_x01;
        if apex_application.g_x02 <> l_request_id then
            raise_application_error(-20011, 'El documento no pertenece a la solicitud actual.');
        end if;
        if apex_application.g_f01.count = 0 then
            raise_application_error(-20012, 'No se recibió contenido de imagen.');
        end if;
        if lower(apex_application.g_x04) not in ('image/jpeg','image/png') then
            raise_application_error(-20013, 'Tipo de imagen no permitido.');
        end if;

        dbms_lob.createtemporary(l_clob, true);
        for i in 1 .. apex_application.g_f01.count loop
            dbms_lob.writeappend(l_clob, length(apex_application.g_f01(i)), apex_application.g_f01(i));
        end loop;
        l_blob := apex_web_service.clobbase642blob(l_clob);
        l_size := dbms_lob.getlength(l_blob);
        l_user := coalesce(sys_context('APEX$SESSION','APP_USER'), user);

        l_sql := 'update ' || l_table || ' set ' ||
                 l_blob_col || '=:1,' || l_file_col || '=:2,' || l_mime_col || '=:3,' ||
                 l_size_col || '=:4,' || l_date_col || '=sysdate,' || l_user_col || '=:5 ' ||
                 'where ' || l_id_col || '=:6 and ' || l_req_col || '=:7';
        execute immediate l_sql using l_blob, apex_application.g_x03, lower(apex_application.g_x04), l_size, l_user, l_doc_id, l_request_id;
        if sql%rowcount = 0 then
            raise_application_error(-20014, 'Documento no encontrado para la solicitud actual.');
        end if;
        if dbms_lob.istemporary(l_clob) = 1 then dbms_lob.freetemporary(l_clob); end if;

        apex_json.open_object;
        apex_json.write('success', true);
        apex_json.write('id', l_doc_id);
        apex_json.write('requestId', l_request_id);
        apex_json.write('size', l_size);
        apex_json.close_object;
    else
        raise_application_error(-20020, 'Acción no soportada: ' || l_action);
    end if;

    return l_result;
exception
    when no_data_found then
        if dbms_lob.istemporary(l_clob) = 1 then dbms_lob.freetemporary(l_clob); end if;
        apex_json.open_object;
        apex_json.write('success', false);
        apex_json.write('message', 'Documento o imagen no encontrado.');
        apex_json.close_object;
        return l_result;
    when others then
        if dbms_lob.istemporary(l_clob) = 1 then dbms_lob.freetemporary(l_clob); end if;
        apex_json.open_object;
        apex_json.write('success', false);
        apex_json.write('message', sqlerrm);
        apex_json.close_object;
        return l_result;
end;
