# ApexImageSDK Gallery Plug-in v3.1.0

Region Plug-in autocontenido para Oracle APEX 24.2.8. Integra ApexImageSDK v2.15.0, galería, contador, visor, cámara/fotos, editor, compresión, Worker y persistencia BLOB.

## Qué corrige v3.1.0

- Corrige ORA-01006 en el SQL opcional de editabilidad. El plug-in ahora detecta si el SQL contiene una variable de enlace antes de usar `USING`.
- Acepta SQL de editabilidad sin bind (`select 'Y' from dual`) y SQL con un bind (`... where codigo_sol = :1` o `... where codigo_sol = :P_CODIGO_SOL`).
- Las URLs JS/CSS del plug-in se exportan una por línea, como requiere APEX.
- Los cinco archivos estáticos se almacenan dentro del plug-in; no deben añadirse a cada página.
- Mantiene la comprobación de solo lectura también en SAVE: ocultar el botón no es la única protección.

## Instalación

1. Importe `region_type_plugin_com_banpro_apex_image_sdk.sql` en Shared Components > Plug-ins.
2. No agregue `apex-image-sdk.js`, CSS ni Worker a la página. El plug-in los contiene.
3. Cree una región de tipo **ApexImageSDK Gallery**.
4. Configure **Item código solicitud** con el item de página, por ejemplo `P1_CODIGO_SOL`.
5. Configure tabla/columnas. Los valores predeterminados corresponden a `APP_IMAGENES`.
6. Configure opcionalmente **SQL de editabilidad**.

Ejemplo para bloquear una solicitud entregada:

```sql
select case
         when estado = 'ENTREGADA' then 'N'
         else 'Y'
       end
  from solicitudes
 where codigo_sol = :1
```

También es válido un SQL sin bind:

```sql
select 'Y' from dual
```

El SQL debe devolver exactamente una fila y un valor compatible con Y/N. Si no se configura, el plug-in considera la solicitud editable.

## Contrato interno LIST

LIST devuelve JSON similar a:

```json
{
  "success": true,
  "requestId": "SOL-2026-00481",
  "editable": true,
  "documents": [
    {"id":"1","title":"Cédula frontal","loaded":true},
    {"id":"2","title":"Cédula reverso","loaded":false}
  ],
  "total": 2,
  "loaded": 1,
  "pending": 1
}
```

La galería y el contador se generan a partir de esta respuesta. `GET` obtiene el BLOB de una imagen y `SAVE` reemplaza el BLOB del documento existente.

## Solicitud entregada

Cuando el SQL de editabilidad devuelve `N`:

- no se muestran botones Agregar/Reemplazar;
- las imágenes existentes siguen disponibles en el visor;
- se muestra el estado de solo lectura;
- SAVE vuelve a ejecutar la validación en servidor y rechaza modificaciones.

## Archivos encapsulados

- `apex-image-sdk.js` — SDK v2.15.0
- `apex-image-sdk.css`
- `apex-image-worker.js`
- `apex-image-plugin.js`
- `apex-image-plugin.css`

No configure estos archivos en JavaScript File URLs o CSS File URLs de la página.

## Tabla predeterminada

El plug-in espera por defecto las columnas:

`ID`, `CODIGO_SOL`, `TITULO_DOC`, `NOMBRE_ARCHIVO`, `MIME_TYPE`, `IMAGEN_BLOB`, `TAMANO_BYTES`, `FECHA_CARGA`, `USUARIO_CARGA`.

Los nombres son configurables en los atributos de la región.

## Compatibilidad

Objetivo: Oracle APEX 24.2.8. Se mantienen callbacks de Region Plug-in compatibles con la API clásica disponible en APEX 24.2. El Ajax cliente utiliza `apex.server.plugin` y el identificador generado por `apex_plugin.get_ajax_identifier`.

## Nota de seguridad

El SQL de editabilidad protege el estado funcional (por ejemplo ENTREGADA). En producción, la aplicación debe además aplicar la autorización del usuario a la solicitud/documento según su propio modelo de seguridad.
