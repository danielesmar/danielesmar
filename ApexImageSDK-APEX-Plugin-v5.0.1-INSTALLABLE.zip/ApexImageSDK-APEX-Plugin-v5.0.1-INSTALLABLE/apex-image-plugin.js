/* ApexImageSDK APEX Region Plugin v4.0.0 - wraps ApexImageSDK v2.15.0 */
(function (global) {
  'use strict';

  const instances = new Map();
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function b64ToObjectUrl(base64, mime) {
    const bin = atob(base64 || '');
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return URL.createObjectURL(new Blob([bytes], { type: mime || 'image/jpeg' }));
  }

  class ApexImageRegion {
    constructor(cfg) {
      this.cfg = cfg;
      this.el = document.getElementById(cfg.regionId);
      this.docs = [];
      this.urls = new Map();
      this.current = null;
      this.sdk = null;
      this.viewerZoom=1; this.viewerX=0; this.viewerY=0; this.viewerPointers=new Map(); this.viewerPinch=null;
      this.bound = false;
    }

    async init() {
      if (!this.el) throw new Error('ApexImageSDK Plugin: región no encontrada: ' + this.cfg.regionId);
      this.el.classList.add('apxisdk-region');
      this.el.style.setProperty('--apxisdk-primary', this.cfg.primaryColor || '#08783e');
      this.el.innerHTML = `
        <div class="apxisdkp-summary" data-summary></div>
        <div class="apxisdkp-grid" data-grid aria-live="polite"></div>
        <div class="apxisdkp-empty" data-empty hidden></div>
        <div class="apxisdkp-host" data-sdk-host></div>
        <div class="apxisdkp-source" data-source hidden role="menu" aria-label="Origen de imagen">
          <button type="button" data-camera><span class="fa fa-camera" aria-hidden="true"></span><span>Cámara</span></button>
          <button type="button" data-photos><span class="fa fa-picture-o" aria-hidden="true"></span><span>Galería</span></button>
        </div>
        <div class="apxisdkp-viewer" data-viewer hidden role="dialog" aria-modal="true" aria-label="Visualizador de documento">
          <div class="apxisdkp-viewer-backdrop" data-viewer-close></div>
          <div class="apxisdkp-viewer-content">
            <div class="apxisdkp-viewer-header"><strong data-viewer-title>Documento</strong><button type="button" data-viewer-close aria-label="Cerrar"><span class="fa fa-times" aria-hidden="true"></span></button></div>
            <div class="apxisdkp-viewer-area" data-viewer-area><img data-viewer-image alt=""></div>
          </div>
        </div>`;
      this.bind();
      this.initSdk();
      this.renderSkeleton();
      await this.refresh();
      if (global.apex?.region?.create) {
        global.apex.region.create(this.cfg.regionId, {
          type: 'ApexImageSDK',
          refresh: () => this.refresh(),
          focus: () => this.el.querySelector('.apxisdkp-card button, .apxisdkp-card img')?.focus(),
          getDocuments: () => this.docs.slice(),
          isEditable: () => !!this.editable
        });
      }
      return this;
    }

    initSdk() {
      if (typeof global.ApexImageSDK === 'undefined') throw new Error('ApexImageSDK v2.15.0 no está cargado.');
      const host = this.el.querySelector('[data-sdk-host]');
      this.sdk = new global.ApexImageSDK({
        target: host,
        ui: { showLauncher: false, showPreview: false },
        autoUpload: true,
        compression: {
          targetKB: Number(this.cfg.targetKB || 150), toleranceKB: 8,
          maxWidth: Number(this.cfg.maxWidth || 1920), maxHeight: Number(this.cfg.maxHeight || 1920),
          workerUrl: this.cfg.workerUrl
        },
        upload: {
          mode: 'apexPlugin', ajaxIdentifier: this.cfg.ajaxIdentifier,
          documentIdKey: 'x01', requestIdKey: 'x02', fileNameKey: 'x03', mimeTypeKey: 'x04', fileSizeKey: 'x05', base64ArrayKey: 'f01',
          extraData: { x10: 'SAVE', x06: this.cfg.componentMode || 'CARGA', pageItems: this.pageItemsSelector() }
        },
        onComplete: async () => { this.current = null; await this.refresh(); },
        onError: err => console.error('ApexImageSDK SAVE:', err)
      }).init();
    }

    bind() {
      if (this.bound) return;
      this.bound = true;
      this.el.addEventListener('click', e => {
        const add = e.target.closest('[data-add]');
        if (add) {
          e.preventDefault(); e.stopPropagation();
          const card = add.closest('[data-doc-id]');
          const doc = this.docs.find(d => String(d.id) === String(card?.dataset.docId));
          if (!doc?.editable) return;
          this.current = { documentId: card.dataset.docId, requestId: doc.requestId || this.requestId, documentTitle: card.dataset.title || 'Documento' };
          this.openSource(add);
          return;
        }
        if (e.target.closest('[data-camera]')) { const c={...this.current}; this.closeSource(); if(c.documentId) this.sdk.openCamera(c); return; }
        if (e.target.closest('[data-photos]')) { const c={...this.current}; this.closeSource(); if(c.documentId) this.sdk.openGallery(c); return; }
        if (e.target.closest('[data-viewer-close]')) { this.closeViewer(); return; }
        const thumb = e.target.closest('[data-view]');
        if (thumb && !e.target.closest('[data-add]')) {
          const card = thumb.closest('[data-doc-id]');
          if (card?.classList.contains('is-loaded')) this.openViewer(card);
        }
      });
      const viewerArea=this.el.querySelector('[data-viewer-area]'),viewerImage=this.el.querySelector('[data-viewer-image]');
      const applyViewer=()=>{viewerImage.style.transform=`translate3d(${this.viewerX}px,${this.viewerY}px,0) scale(${this.viewerZoom})`;};
      const clampViewer=()=>{const a=viewerArea.getBoundingClientRect(),baseW=viewerImage.offsetWidth,baseH=viewerImage.offsetHeight,maxX=Math.max(0,(baseW*this.viewerZoom-a.width)/2),maxY=Math.max(0,(baseH*this.viewerZoom-a.height)/2);this.viewerX=Math.max(-maxX,Math.min(maxX,this.viewerX));this.viewerY=Math.max(-maxY,Math.min(maxY,this.viewerY));};
      viewerArea.addEventListener('wheel',e=>{if(this.el.querySelector('[data-viewer]').hidden)return;e.preventDefault();this.viewerZoom=Math.max(1,Math.min(5,this.viewerZoom*Math.exp(-e.deltaY*.0015)));if(this.viewerZoom===1){this.viewerX=0;this.viewerY=0;}clampViewer();applyViewer();},{passive:false});
      viewerArea.addEventListener('pointerdown',e=>{if(this.el.querySelector('[data-viewer]').hidden)return;viewerArea.setPointerCapture?.(e.pointerId);this.viewerPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.viewerPointers.size===2){const p=[...this.viewerPointers.values()];this.viewerPinch={d:Math.hypot(p[1].x-p[0].x,p[1].y-p[0].y),z:this.viewerZoom};}});
      viewerArea.addEventListener('pointermove',e=>{const prev=this.viewerPointers.get(e.pointerId);if(!prev)return;const dx=e.clientX-prev.x,dy=e.clientY-prev.y;this.viewerPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.viewerPointers.size===1&&this.viewerZoom>1){this.viewerX+=dx;this.viewerY+=dy;clampViewer();applyViewer();}else if(this.viewerPointers.size===2){const p=[...this.viewerPointers.values()],d=Math.hypot(p[1].x-p[0].x,p[1].y-p[0].y);if(this.viewerPinch?.d){this.viewerZoom=Math.max(1,Math.min(5,this.viewerPinch.z*d/this.viewerPinch.d));if(this.viewerZoom===1){this.viewerX=0;this.viewerY=0;}clampViewer();applyViewer();}}});
      const endViewerPointer=e=>{this.viewerPointers.delete(e.pointerId);if(this.viewerPointers.size<2)this.viewerPinch=null;};
      viewerArea.addEventListener('pointerup',endViewerPointer);viewerArea.addEventListener('pointercancel',endViewerPointer);
      viewerArea.addEventListener('dblclick',e=>{e.preventDefault();this.viewerZoom=this.viewerZoom>1?1:2;if(this.viewerZoom===1){this.viewerX=0;this.viewerY=0;}clampViewer();applyViewer();});
      document.addEventListener('pointerdown', e => {
        const menu = this.el?.querySelector('[data-source]');
        if (!menu || menu.hidden || this.el.contains(e.target) && (menu.contains(e.target) || e.target.closest('[data-add]'))) return;
        this.closeSource();
      });
      document.addEventListener('keydown', e => { if (e.key === 'Escape') { this.closeSource(); this.closeViewer(); } });
    }

    openSource(button) {
      const menu = this.el.querySelector('[data-source]');
      const r = button.getBoundingClientRect(), width = 210;
      menu.style.left = Math.min(innerWidth-width-10, Math.max(10, r.right-width)) + 'px';
      menu.style.top = Math.max(10, r.top-126) + 'px';
      menu.hidden = false;
    }
    closeSource() { const m=this.el?.querySelector('[data-source]'); if(m) m.hidden=true; }

    pageItemsSelector() {
      return [this.cfg.requestItem].filter(Boolean).map(x => '#' + x).join(',');
    }

    async server(data) {
      const pageItems = this.pageItemsSelector();
      if (pageItems) data.pageItems = pageItems;
      return global.apex.server.plugin(this.cfg.ajaxIdentifier, data, { dataType: 'json' });
    }

    async refresh() {
      this.closeSource();
      const res = await this.server({ x10: 'LIST', x01: this.cfg.requestItem ? global.apex.item(this.cfg.requestItem).getValue() : this.cfg.requestId });
      if (!res || res.success === false) throw new Error(res?.message || 'No fue posible cargar documentos.');
      this.requestId = res.requestId;
      this.editable = (res.documents || []).some(d => !!d.editable);
      this.docs = res.documents || [];
      this.render(res);
      await this.loadImages();
      return res;
    }

    renderSkeleton() {
      const s=this.el.querySelector('[data-summary]'), g=this.el.querySelector('[data-grid]'), e=this.el.querySelector('[data-empty]');
      if(e) e.hidden=true;
      if(s) {
        s.hidden = !this.cfg.showSummary;
        s.innerHTML = this.cfg.showSummary ? '<div class="apxisdkp-sk-line apxisdkp-sk-summary"></div><div class="apxisdkp-sk-pill"></div>' : '';
      }
      if(g) {
        g.hidden=false;
        g.setAttribute('aria-busy','true');
        g.innerHTML = Array.from({length:4},()=>'<div class="apxisdkp-sk-card" aria-hidden="true"><div class="apxisdkp-sk-thumb"></div><div class="apxisdkp-sk-body"><div class="apxisdkp-sk-line"></div><div class="apxisdkp-sk-line is-short"></div></div></div>').join('');
      }
    }

    render(res) {
      const s=this.el.querySelector('[data-summary]'), g=this.el.querySelector('[data-grid]'), e=this.el.querySelector('[data-empty]');
      g.removeAttribute('aria-busy');
      s.hidden = !this.cfg.showSummary;
      if(e) e.hidden=true;
      if(!this.docs.length) {
        g.innerHTML='';
        g.hidden=true;
        if(e) {
          e.innerHTML = this.cfg.emptyHtml || '';
          e.hidden = false;
        }
        if(this.cfg.showSummary) {
          s.innerHTML = `<div><span>Solicitud</span><strong>${esc(res.requestId || '')}</strong></div><div class="apxisdkp-count"><strong>0</strong><span>/</span><strong>0</strong><span>cargados</span></div>`;
        } else {
          s.innerHTML='';
        }
        return;
      }
      g.hidden=false;
      s.innerHTML = this.cfg.showSummary ? `<div><span>Solicitud</span><strong>${esc(res.requestId || '')}</strong>${!this.editable?'<small><span class="fa fa-lock" aria-hidden="true"></span> Solicitud entregada · solo lectura</small>':''}</div><div class="apxisdkp-count"><strong>${Number(res.loaded||0)}</strong><span>/</span><strong>${Number(res.total||0)}</strong><span>cargados</span></div>` : '';
      g.innerHTML = this.docs.map(d => {
        const correction = !!d.requiresCorrection, editable = !!d.editable;
        const badge = correction ? '<div class="apxisdkp-correction-badge"><span class="fa fa-exclamation-triangle"></span> Requiere corrección</div>' : '';
        const reason = correction && d.reason ? `<div class="apxisdkp-correction-reason"><strong>Motivo:</strong> ${esc(d.reason)}</div>` : '';
        const status = d.status ? `<span class="apxisdkp-status">${esc(d.status)}</span>` : '';
        return `<article class="apxisdkp-card ${d.loaded?'is-loaded':'is-pending'} ${correction?'is-correction':''}" data-doc-id="${esc(d.id)}" data-title="${esc(d.title)}"><div class="apxisdkp-thumb" data-view>${badge}${d.loaded?'<div class="apxisdkp-image-loading"><span class="fa fa-refresh fa-anim-spin" aria-hidden="true"></span></div>':'<div class="apxisdkp-placeholder"><span class="bi bi-image-circle" aria-hidden="true"></span><span>Sin imagen</span></div>'}${editable?`<button class="apxisdkp-add" type="button" data-add aria-label="${d.loaded?'Reemplazar':'Agregar'} ${esc(d.title)}"><span class="fa ${d.loaded?'fa-refresh':'fa-plus'}" aria-hidden="true"></span></button>`:''}</div><div class="apxisdkp-body"><strong>${esc(d.title)}</strong>${status}<span>${esc(d.statusDescription || '')}</span>${reason}</div></article>`;
      }).join('');
    }

    async loadImages() {
      for (const [id,url] of this.urls) { URL.revokeObjectURL(url); }
      this.urls.clear();
      await Promise.all(this.docs.filter(d=>d.loaded).map(async d => {
        try {
          const r=await this.server({x10:'GET',x01:String(d.id),x02:String(d.requestId || this.requestId)});
          if(!r || r.success===false || !r.base64) return;
          const url=b64ToObjectUrl(r.base64,r.mimeType); this.urls.set(String(d.id),url);
          const card=this.el.querySelector(`[data-doc-id="${CSS.escape(String(d.id))}"]`); const thumb=card?.querySelector('[data-view]');
          if(thumb){ const old=thumb.querySelector('.apxisdkp-image-loading'); if(old) old.remove(); const img=document.createElement('img'); img.className='apxisdkp-doc-image'; img.src=url; img.alt=d.title||'Documento'; img.loading='lazy'; thumb.insertBefore(img,thumb.firstChild); }
        } catch(e){ console.error('ApexImageSDK GET',e); }
      }));
    }

    openViewer(card) {
      const img=card.querySelector('.apxisdkp-doc-image'); if(!img) return;
      const v=this.el.querySelector('[data-viewer]'),vi=v.querySelector('[data-viewer-image]');this.viewerZoom=1;this.viewerX=0;this.viewerY=0;this.viewerPointers.clear();this.viewerPinch=null;vi.style.transform='translate3d(0,0,0) scale(1)';vi.src=img.src;v.querySelector('[data-viewer-title]').textContent=card.dataset.title||'Documento';v.hidden=false;document.body.classList.add('apxisdkp-viewer-open');
    }
    closeViewer() { const v=this.el?.querySelector('[data-viewer]'); if(!v||v.hidden)return; v.hidden=true;const vi=v.querySelector('[data-viewer-image]');vi.removeAttribute('src');vi.style.transform='';this.viewerZoom=1;this.viewerX=0;this.viewerY=0;this.viewerPointers.clear();this.viewerPinch=null;document.body.classList.remove('apxisdkp-viewer-open'); }
  }

  global.ApexImageSDKPlugin = {
    version: '4.3.2', sdkVersion: '2.15.0',
    init: cfg => { const x=new ApexImageRegion(cfg); instances.set(cfg.regionId,x); return x.init(); },
    get: id => instances.get(id)
  };
})(window);
