procedure render (
    p_plugin in apex_plugin.t_plugin,
    p_region in apex_plugin.t_region,
    p_param  in apex_plugin.t_region_render_param,
    p_result in out nocopy apex_plugin.t_region_render_result )
is
    l_ctx apex_exec.t_context;
    l_region_id varchar2(255) := 'apxpc_'||p_region.id;
    l_count pls_integer := 0;
    l_csc_item varchar2(255) := nvl(p_region.attributes.get_varchar2('attr_csc_item'),'P9_CSC_CITA');
    l_client_item varchar2(255) := nvl(p_region.attributes.get_varchar2('attr_client_item'),'P9_COD_CLIENTE');
    l_cfg varchar2(32767) := p_region.attributes.get_varchar2('attr_card_json');
    l_csc_cita varchar2(4000); l_cod_cliente varchar2(4000);
    l_sections pls_integer; l_fields pls_integer; l_template varchar2(4000);

    function h(p varchar2) return varchar2 is begin return apex_escape.html(nvl(p,'')); end;
    function a(p varchar2) return varchar2 is begin return apex_escape.html_attribute(nvl(p,'')); end;
    function val(p_name varchar2) return varchar2 is
      n pls_integer;
    begin
      if p_name is null then return null; end if;
      n:=apex_exec.get_column_position(p_context=>l_ctx,p_column_name=>upper(p_name),p_is_required=>false);
      if n is null then return null; end if;
      return apex_exec.get_varchar2(p_context=>l_ctx,p_column_idx=>n);
    exception when others then return null; end;
    function cls(p varchar2) return varchar2 is begin return regexp_replace(nvl(p,''),'[^A-Za-z0-9_ -]',''); end;
    function color(p varchar2) return varchar2 is begin if regexp_like(nvl(p,''),'^(#[0-9A-Fa-f]{3,8}|[A-Za-z]{3,20})$') then return p; end if; return '#a96000'; end;
    function jv(p_path varchar2,p0 number default null,p1 number default null,p_default varchar2 default null) return varchar2 is
      x varchar2(32767);
    begin x:=apex_json.get_varchar2(p_path=>p_path,p0=>p0,p1=>p1); return nvl(x,p_default); exception when others then return p_default; end;
    function render_tpl(p_tpl varchar2,p_label varchar2,p_value varchar2,p_class varchar2,p_color varchar2) return varchar2 is
      x varchar2(32767):=p_tpl;
    begin
      x:=replace(x,'#LABEL#',h(p_label)); x:=replace(x,'#VALUE#',h(p_value));
      x:=replace(x,'#CLASS#',a(cls(p_class))); x:=replace(x,'#COLOR#',a(color(p_color))); return x;
    end;
begin
  if apex_application.g_debug then apex_plugin_util.debug_region(p_plugin=>p_plugin,p_region=>p_region); end if;
  l_csc_cita:=apex_util.get_session_state(l_csc_item); l_cod_cliente:=apex_util.get_session_state(l_client_item);
  if l_cfg is null then l_cfg:=q'~{
    "titleColumn":"DESCRIPCION_PRODUCTO","imageColumn":"DIR_URL_IMAGEN_FONDO_TJT","panColumn":"NUMERO_DE_TARJETA_MASCARA","holderColumn":"NOMBRE_PLASTICO_TJT",
    "sections":[{"fields":[
      {"label":"Número solicitud","column":"ID_SOLICITUD"},{"label":"Evento","column":"EVENTO_DE_TARJETA"},
      {"label":"Tipo producto","column":"CATEG_TARJETA_DESC"},{"label":"Tipo tarjeta","column":"TIPO_TARJETA_SOLICITADA"},
      {"label":"Cuenta crédito","column":"NUM_CTA_CREDITO"},{"label":"Estado entrega","column":"DES_ESTADO_VISITA_SOLICITUD","type":"status","colorColumn":"COLOR"}
    ]}],
    "button":{"permissionColumn":"TIENE_PERMISO_ENTREGAR_TARJETA","textColumn":"TEXTO_BOTON","iconColumn":"ICONO_BOTON","requestColumn":"ID_SOLICITUD","stateColumn":"IND_ESTADO_VISITA_SOLICITUD"}
  }~'; end if;
  apex_json.parse(l_cfg);

  htp.p('<div id="'||a(l_region_id)||'" class="apxpc"><div class="apxpc-viewport"><div class="apxpc-track">');
  l_ctx:=apex_exec.open_query_context();
  while apex_exec.next_row(l_ctx) loop
    l_count:=l_count+1;
    htp.p('<div class="apxpc-slide'||case when l_count=1 then ' is-active' end||'" data-index="'||to_char(l_count-1)||'"><article class="apxpc-card">');
    htp.p('<div class="apxpc-title"><span class="apxpc-title-icon" aria-hidden="true"></span><span class="apxpc-title-text">'||h(val(jv('titleColumn',p_default=>'DESCRIPCION_PRODUCTO')))||'</span></div>');
    htp.p('<div class="apxpc-bank">');
    if val(jv('imageColumn',p_default=>'DIR_URL_IMAGEN_FONDO_TJT')) is not null then htp.p('<img class="apxpc-bank-img" src="'||a(val(jv('imageColumn',p_default=>'DIR_URL_IMAGEN_FONDO_TJT')))||'" alt="">'); end if;
    htp.p('<div class="apxpc-bank-shade"></div><div class="apxpc-pan">'||h(val(jv('panColumn',p_default=>'NUMERO_DE_TARJETA_MASCARA')))||'</div><div class="apxpc-holder">'||h(val(jv('holderColumn',p_default=>'NOMBRE_PLASTICO_TJT')))||'</div></div>');

    htp.p('<div class="apxpc-sections">');
    l_sections:=nvl(apex_json.get_count('sections'),0);
    for s in 1..l_sections loop
      htp.p('<div class="apxpc-section '||a(cls(jv('sections[%d].class',s)))||'">');
      l_fields:=nvl(apex_json.get_count(p_path=>'sections[%d].fields',p0=>s),0);
      for f in 1..l_fields loop
        declare
          lab varchar2(4000):=jv('sections[%d].fields[%d].label',s,f);
          col varchar2(4000):=jv('sections[%d].fields[%d].column',s,f);
          typ varchar2(100):=lower(jv('sections[%d].fields[%d].type',s,f,'text'));
          spanv varchar2(20):=jv('sections[%d].fields[%d].span',s,f,'1');
          cc varchar2(4000):=jv('sections[%d].fields[%d].classColumn',s,f);
          kc varchar2(4000):=jv('sections[%d].fields[%d].colorColumn',s,f);
          tpl varchar2(4000):=jv('sections[%d].fields[%d].template',s,f);
          vv varchar2(32767); cv varchar2(4000); kv varchar2(4000);
        begin
          vv:=val(col); cv:=val(cc); kv:=val(kc);
          htp.p('<div class="apxpc-field '||case when spanv='2' then 'apxpc-field--full ' end||a(cls(cv))||'"><div class="apxpc-label">'||h(lab)||'</div><div class="apxpc-value">');
          if tpl is not null then htp.p(render_tpl(tpl,lab,vv,cv,kv));
          elsif typ='status' then htp.p('<span class="apxpc-status '||a(cls(cv))||'" style="color:'||a(color(kv))||'"><span class="apxpc-status-dot"></span>'||h(vv)||'</span>');
          else htp.p(h(vv)); end if;
          htp.p('</div></div>');
        end;
      end loop;
      htp.p('</div>');
    end loop;
    htp.p('</div>');

    if upper(nvl(val(jv('button.permissionColumn',p_default=>'TIENE_PERMISO_ENTREGAR_TARJETA')),'N'))='Y' then
      htp.p('<a href="#" class="apxpc-action entregarTarjeta" data-num-solicitud="'||a(val(jv('button.requestColumn',p_default=>'ID_SOLICITUD')))||'" data-estado-solicitud="'||a(val(jv('button.stateColumn',p_default=>'IND_ESTADO_VISITA_SOLICITUD')))||'" data-csc-cita="'||a(l_csc_cita)||'" data-cod-cliente="'||a(l_cod_cliente)||'">'||h(nvl(val(jv('button.textColumn',p_default=>'TEXTO_BOTON')),'Realizar Entrega'))||'<span class="apxpc-action-icon fa '||a(cls(nvl(val(jv('button.iconColumn',p_default=>'ICONO_BOTON')),'fa-chevron-right')))||'" aria-hidden="true"></span></a>');
    end if;
    htp.p('</article></div>');
  end loop;
  apex_exec.close(l_ctx);
  htp.p('</div></div>');
  if l_count>1 then htp.p('<div class="apxpc-dots" aria-label="Productos">'); for i in 0..l_count-1 loop htp.p('<button type="button" class="apxpc-dot'||case when i=0 then ' is-active' end||'" data-index="'||to_char(i)||'" aria-label="Producto '||to_char(i+1)||'"></button>'); end loop; htp.p('</div>');
  elsif l_count=0 then htp.p('<div class="apxpc-empty">'||h(nvl(p_region.no_data_found_message,'No hay productos disponibles.'))||'</div>'); end if;
  htp.p('</div>');
  if l_count=1 then apex_javascript.add_onload_code('document.getElementById('||apex_javascript.add_value(l_region_id,false)||').classList.add("is-single");'); end if;
  apex_javascript.add_onload_code('ApexProductCards.init('||apex_javascript.add_value(l_region_id,false)||');');
exception when others then begin apex_exec.close(l_ctx); exception when others then null; end; raise;
end render;
