CREATE TABLE  "SEGMENTS" 
   (	"SEGMENTID" NUMBER, 
	"SEGMENTTITLE" VARCHAR2(50), 
	"SEGMENTPARENT" NUMBER, 
	"SEGMENTTYPE" VARCHAR2(4), 
	"PAGEID" NUMBER(4,0), 
	"ITEMROLE" VARCHAR2(10), 
	 CONSTRAINT "SEGMENTS_PK" PRIMARY KEY ("SEGMENTID") USING INDEX ENABLE
   );

insert into segments values (1,'Cloud Financials',0,'App',null,null);

insert into segments values (2,'CF Home',1,'Menu',null,null); 
insert into segments values (3,'Transactions',1,'Menu',null,null); 
insert into segments values (4,'Reports',1,'Menu',null,null); 

insert into segments values (10,'Home',2,'Page',1,null); 
insert into segments values (11,'Vouchers',3,'Page',2,null); 
insert into segments values (12,'Ledgers',4,'Page',3,null); 

insert into segments values (20,'Display',11,'Item',2,'Display'); 
insert into segments values (21,'Print',11,'Item',2,'Print'); 

insert into segments values (22,'Display',12,'Item',3,'Display'); 
insert into segments values (23,'Print',12,'Item',3,'Print'); 


CREATE TABLE  "GROUP_MASTER" 
   (	"GROUPID" NUMBER(4,0), 
	"GROUPTITLE" VARCHAR2(25), 
	 CONSTRAINT "GM_PK" PRIMARY KEY ("GROUPID") USING INDEX ENABLE
   );

insert into group_master values (1,'Admins');
insert into group_master values (2,'Managers');


CREATE TABLE  "GROUP_DETAIL" 
   (	"GROUPID" NUMBER(4,0), 
	"SEGMENTID" NUMBER, 
	"ALLOW_ACCESS" VARCHAR2(1)
   );


ALTER TABLE "GROUP_DETAIL" ADD CONSTRAINT "FK_GD1" FOREIGN KEY ("GROUPID") REFERENCES  "GROUP_MASTER" ("GROUPID") ENABLE;
ALTER TABLE "GROUP_DETAIL" ADD CONSTRAINT "FK_GD2" FOREIGN KEY ("SEGMENTID") REFERENCES "SEGMENTS" ("SEGMENTID") ENABLE;

insert into group_detail values (1,1,'Y');

insert into group_detail values (1,2,'Y');
insert into group_detail values (1,3,'Y');
insert into group_detail values (1,4,'Y');

insert into group_detail values (1,10,'Y');
insert into group_detail values (1,11,'Y');
insert into group_detail values (1,12,'Y');

insert into group_detail values (1,20,'Y');
insert into group_detail values (1,21,'Y');

insert into group_detail values (1,22,'Y');
insert into group_detail values (1,23,'Y');



insert into group_detail values (2,1,'Y');

insert into group_detail values (2,2,'Y');
insert into group_detail values (2,3,'Y');
insert into group_detail values (2,4,'Y');

insert into group_detail values (2,10,'Y');
insert into group_detail values (2,11,'N');
insert into group_detail values (2,12,'N');

insert into group_detail values (2,20,'N');
insert into group_detail values (2,21,'N');

insert into group_detail values (2,22,'N');
insert into group_detail values (2,23,'N');


CREATE TABLE  "APP_USERS" 
   (	"USERID" VARCHAR2(50), 
	"GROUPID" NUMBER(4,0), 
	"PASSWORD" VARCHAR2(4000), 
	"ADMIN" VARCHAR2(1), 
	 CONSTRAINT "APP_USERS_PK" PRIMARY KEY ("USERID") USING INDEX  ENABLE
   );

ALTER TABLE  "APP_USERS" ADD CONSTRAINT "FK_APP_USERS" FOREIGN KEY ("GROUPID") REFERENCES "GROUP_MASTER" ("GROUPID") ENABLE;

-- Password for both users is 123
insert into app_users values ('USER1',1,'B63CD33A7818A6D6297323EF7D7C657B','Y');
insert into app_users values ('USER2',2,'BAA15097879D0ABA7C9A662CA8645419','N');









