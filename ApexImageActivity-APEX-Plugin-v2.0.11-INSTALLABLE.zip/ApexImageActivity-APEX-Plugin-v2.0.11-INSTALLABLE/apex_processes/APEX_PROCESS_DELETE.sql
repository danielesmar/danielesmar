-- APEX Ajax Callback Process - DELETE
-- Configure el nombre de este proceso en el atributo "Proceso APEX DELETE" del plug-in.
-- IMPORTANTE: sustituya CSC_ACTIVIDAD_IMAGEN por el nombre real de la PK si su tabla usa otro nombre.
declare
    pIdImagen             varchar2(4000) := apex_application.g_x01;
    PARAM_TIPO_ACTIVIDAD  varchar2(4000) := apex_application.g_x02;
    l_csc_tipo_actividad  number;
begin
    if pIdImagen is null then raise_application_error(-20011,'ID de imagen requerido.'); end if;
    if PARAM_TIPO_ACTIVIDAD is null then raise_application_error(-20012,'Debe seleccionar el tipo de actividad.'); end if;

    l_csc_tipo_actividad := PV.PV_INTC_CONFIGURACIONES.ObtenerIdPorCodigoCatalogo(
        pCatalogo => 'TIPO_ACTIVIDAD',
        pCodigo   => PARAM_TIPO_ACTIVIDAD
    );

    if l_csc_tipo_actividad is null then
        raise_application_error(-20014,'No se encontró TIPO_ACTIVIDAD para el código recibido: '||PARAM_TIPO_ACTIVIDAD);
    end if;

    delete from pv_actividades_imagenes_tmp
     where CSC_ACTIVIDAD_IMAGEN = to_number(pIdImagen)
       and CSC_TIPO_ACTIVIDAD = l_csc_tipo_actividad
       and COD_APLICACION = v('APP_ID')
       and USR_TCG = v('APP_USER_TCG');

    if sql%rowcount = 0 then raise_application_error(-20013,'La imagen no existe o no pertenece al contexto actual.'); end if;

    apex_json.open_object;
    apex_json.write('success',true);
    apex_json.close_object;
exception
    when others then
        apex_debug.error('ApexImageActivity v2 DELETE: %s',sqlerrm);
        apex_json.open_object;
        apex_json.write('success',false);
        apex_json.write('message',sqlerrm);
        apex_json.close_object;
end;