/* ApexImageSDK Worker v2.11.0 — compression + auto-straighten analysis */
'use strict';

self.onmessage = async (event) => {
  const { id, action, file, imageData, options } = event.data || {};
  try {
    if (action === 'straighten') {
      const result = analyzeStraightenPixels(imageData, options?.maxAngle || 15);
      self.postMessage({ id, type: 'straighten', result });
      return;
    }
    const result = await compressImage(file, options || {}, (p) => {
      self.postMessage({ id, type: 'progress', progress: p });
    });
    self.postMessage({ id, type: 'done', blob: result.blob, meta: result.meta });
  } catch (err) {
    self.postMessage({ id, type: 'error', error: err?.message || String(err) });
  }
};

async function compressImage(file, o, progress) {
  if (typeof createImageBitmap !== 'function' || typeof OffscreenCanvas === 'undefined') {
    throw new Error('Worker image APIs are not supported.');
  }
  progress(5);
  let bitmap;
  try {
    bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' });
  } catch (_) {
    bitmap = await createImageBitmap(file);
  }
  progress(15);

  const originalWidth = bitmap.width;
  const originalHeight = bitmap.height;
  const targetBytes = Math.max(1, o.targetKB || 150) * 1024;
  const toleranceBytes = Math.max(0, o.toleranceKB || 8) * 1024;
  const maxBytes = targetBytes + toleranceBytes;
  const maxWidth = o.maxWidth || 1920;
  const maxHeight = o.maxHeight || 1920;
  const minQuality = clamp(o.minQuality ?? 0.45, 0.1, 0.98);
  const maxQuality = clamp(o.maxQuality ?? 0.9, minQuality, 0.99);
  const iterations = Math.max(2, o.iterations || 7);
  const mimeType = o.mimeType || 'image/jpeg';
  const scaleStep = clamp(o.scaleStep ?? 0.88, 0.6, 0.98);
  const minDimension = Math.max(320, o.minDimension || 720);

  let dims = fit(originalWidth, originalHeight, maxWidth, maxHeight);
  let best = null;
  let scalePass = 0;

  while (true) {
    const canvas = new OffscreenCanvas(dims.width, dims.height);
    const keepAlpha = mimeType === 'image/png';
    const ctx = canvas.getContext('2d', { alpha: keepAlpha, desynchronized: true });
    if (!ctx) throw new Error('2D canvas context unavailable.');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    if (!keepAlpha) {
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, dims.width, dims.height);
    }
    ctx.drawImage(bitmap, 0, 0, dims.width, dims.height);

    let low = minQuality;
    let high = maxQuality;
    let passBest = null;

    for (let i = 0; i < iterations; i++) {
      const q = (low + high) / 2;
      const blob = await canvas.convertToBlob({ type: mimeType, quality: q });
      const candidate = { blob, quality: q, width: dims.width, height: dims.height };
      if (!best || score(blob.size, targetBytes) < score(best.blob.size, targetBytes)) best = candidate;
      if (blob.size <= maxBytes) {
        if (!passBest || q > passBest.quality) passBest = candidate;
        low = q;
      } else {
        high = q;
      }
      progress(Math.min(90, 20 + scalePass * 12 + ((i + 1) / iterations) * 45));
    }

    if (passBest) {
      best = passBest;
      break;
    }

    if (Math.min(dims.width, dims.height) <= minDimension) break;
    const nextW = Math.max(1, Math.round(dims.width * scaleStep));
    const nextH = Math.max(1, Math.round(dims.height * scaleStep));
    if (nextW === dims.width || nextH === dims.height) break;
    dims = { width: nextW, height: nextH };
    scalePass++;
    if (scalePass > 8) break;
  }

  bitmap.close?.();
  if (!best) throw new Error('Unable to encode image.');
  progress(100);
  return {
    blob: best.blob,
    meta: {
      originalBytes: file.size,
      compressedBytes: best.blob.size,
      originalWidth,
      originalHeight,
      width: best.width,
      height: best.height,
      quality: Number(best.quality.toFixed(4)),
      mimeType: best.blob.type || mimeType,
      targetKB: o.targetKB || 150
    }
  };
}

function fit(w, h, mw, mh) {
  const r = Math.min(1, mw / w, mh / h);
  return { width: Math.max(1, Math.round(w * r)), height: Math.max(1, Math.round(h * r)) };
}
function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
function score(bytes, target) { return Math.abs(bytes - target); }


function analyzeStraightenPixels(imageData, maxAngle = 15) {
  if (!imageData || !imageData.data) return { angle:0, confidence:0 };
  const {data,width:w,height:h}=imageData;
  if(w<40||h<40)return {angle:0,confidence:0};

  // v2.9: straight-line geometry detector. It deliberately avoids assuming a
  // white background: candidate angles are scored by long, spatially coherent
  // edge runs near the document perimeter, while short text/texture edges are
  // strongly discounted.
  const gray=new Uint8Array(w*h), mag=new Float32Array(w*h), ori=new Float32Array(w*h);
  for(let i=0,j=0;i<data.length;i+=4,j++) gray[j]=.299*data[i]+.587*data[i+1]+.114*data[i+2];
  const strengths=[];
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
    const i=y*w+x;
    const gx=-gray[i-w-1]+gray[i-w+1]-2*gray[i-1]+2*gray[i+1]-gray[i+w-1]+gray[i+w+1];
    const gy=-gray[i-w-1]-2*gray[i-w]-gray[i-w+1]+gray[i+w-1]+2*gray[i+w]+gray[i+w+1];
    const m=Math.hypot(gx,gy); mag[i]=m; ori[i]=Math.atan2(gy,gx); if(m>25)strengths.push(m);
  }
  if(strengths.length<80)return {angle:0,confidence:0,samples:strengths.length,method:'straight-lines-v3'};
  strengths.sort((a,b)=>a-b);
  const threshold=Math.max(38,strengths[Math.floor(strengths.length*.78)]||38);
  const edgePts=[];
  const mx=w*.08,my=h*.08;
  for(let y=2;y<h-2;y+=2)for(let x=2;x<w-2;x+=2){
    const i=y*w+x,m=mag[i]; if(m<threshold)continue;
    // Favor the outer 38% where document borders normally live; keep the
    // center at reduced weight so tightly framed documents still work.
    const nx=Math.min(x,w-1-x)/(w*.5), ny=Math.min(y,h-1-y)/(h*.5);
    const perimeter=(nx<.38||ny<.38)?1:.42;
    edgePts.push({x,y,m,a:ori[i],p:perimeter});
  }
  if(edgePts.length<40)return {angle:0,confidence:0,samples:edgePts.length,method:'straight-lines-v3'};

  const step=.5, candidates=[];
  for(let deg=-maxAngle;deg<=maxAngle+1e-6;deg+=step){
    const r=deg*Math.PI/180, cr=Math.cos(r),sr=Math.sin(r);
    let score=0,support=0;
    // Horizontal document borders: tangent angle r, normal r+90.
    // Vertical borders: tangent r+90, normal r. Bin projected coordinates;
    // long straight borders concentrate many edge points into the same bins.
    for(const mode of [0,1]){
      const bins=new Map();
      for(const pt of edgePts){
        let expected=mode===0?r+Math.PI/2:r;
        let d=Math.abs(Math.atan2(Math.sin(pt.a-expected),Math.cos(pt.a-expected)));
        d=Math.min(d,Math.PI-d); if(d>12*Math.PI/180)continue;
        const rho=mode===0?(-pt.x*sr+pt.y*cr):(pt.x*cr+pt.y*sr);
        const along=mode===0?(pt.x*cr+pt.y*sr):(pt.x*sr-pt.y*cr);
        const key=Math.round(rho/4), b=bins.get(key)||{wt:0,min:1e9,max:-1e9,n:0};
        const wt=Math.min(5,pt.m/threshold)*pt.p; b.wt+=wt;b.n++;b.min=Math.min(b.min,along);b.max=Math.max(b.max,along);bins.set(key,b);
      }
      const dimension=mode===0?w:h;
      const lines=[];
      for(const b of bins.values()){
        const span=(b.max-b.min)/Math.max(1,dimension);
        if(b.n>=4&&span>.22){ const continuity=Math.min(1,span/.65); lines.push(b.wt*continuity*continuity); }
      }
      lines.sort((a,b)=>b-a); const top=lines.slice(0,4); score+=top.reduce((a,b)=>a+b,0); support+=top.length;
    }
    candidates.push({deg,score,support});
  }
  candidates.sort((a,b)=>b.score-a.score); const best=candidates[0], second=candidates.find(c=>Math.abs(c.deg-best.deg)>=2)||candidates[1]||{score:0};
  if(!best||best.score<=0||best.support<2)return {angle:0,confidence:0,samples:edgePts.length,method:'straight-lines-v3'};
  // Refine with weighted neighboring candidates for smooth sub-degree output.
  const near=candidates.filter(c=>Math.abs(c.deg-best.deg)<=1.0); let sw=0,sa=0;
  for(const c of near){const wt=c.score*c.score;sw+=wt;sa+=c.deg*wt;}
  const angle=sw?sa/sw:best.deg;
  const separation=Math.max(0,(best.score-second.score)/Math.max(1,best.score));
  const density=Math.min(1,best.score/Math.max(35,Math.min(w,h)*.16));
  const confidence=Math.min(1,.50*density+.35*Math.min(1,separation*3)+.15*Math.min(1,best.support/5));
  return {angle:+angle.toFixed(2),confidence:+confidence.toFixed(3),samples:edgePts.length,method:'straight-lines-v3'};
}
