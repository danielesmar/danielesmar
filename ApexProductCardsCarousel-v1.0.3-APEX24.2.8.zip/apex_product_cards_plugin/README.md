# ApexProductCardsCarousel v1.0.3 — Oracle APEX 24.2.8

Corrige el error de ejecución ORA-06502 "character to number conversion error".

## Causa
La función interna `val()` estaba llamando:
`apex_exec.get_varchar2(l_ctx, p_name)`

El segundo parámetro de `APEX_EXEC.GET_VARCHAR2` es un índice numérico
`PLS_INTEGER`, no el alias textual de la columna. Oracle intentaba convertir
por ejemplo `DESCRIPCION_PRODUCTO` a NUMBER y producía ORA-06502.

## Corrección
Ahora primero se resuelve el alias mediante:
`APEX_EXEC.GET_COLUMN_POSITION`

y luego se obtiene el valor mediante:
`APEX_EXEC.GET_VARCHAR2(... p_column_idx => l_col_idx)`.

Se mantienen las correcciones de instalación de v1.0.1 y v1.0.2 y el contrato
del botón `.entregarTarjeta` con sus mismos data attributes.
