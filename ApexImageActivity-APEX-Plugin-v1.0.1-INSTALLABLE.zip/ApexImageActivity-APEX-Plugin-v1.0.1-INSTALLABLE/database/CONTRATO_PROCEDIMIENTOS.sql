-- Contratos esperados por ApexImageActivity v1.0.1
-- Implemente estos procedimientos en su paquete corporativo. El plug-in NO hace INSERT/DELETE directo.
/*
procedure INSERTAR_IMAGEN(
 pIdSesion in varchar2, pUsuario in varchar2, pTipoFuncionalidad in integer,
 pNombreArchivo in varchar2, pTamanoBytes in number, pExtension in varchar2,
 pMimeType in varchar2, pContenido in clob,
 pCodigoError out number, pMensajeUsuario out varchar2, pMensajeTecnico out varchar2);
procedure ELIMINAR_IMAGEN(
 pIdImagen in number, pIdSesion in varchar2, pUsuario in varchar2, pTipoFuncionalidad in integer,
 pCodigoError out number, pMensajeUsuario out varchar2, pMensajeTecnico out varchar2);
*/
