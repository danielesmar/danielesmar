window.ApexProductCards=(function(){"use strict";
function init(regionId){
 var root=document.getElementById(regionId);
 if(!root||root.dataset.apxpcReady==="Y")return;
 root.dataset.apxpcReady="Y";
 var viewport=root.querySelector(".apxpc-viewport"),
     track=root.querySelector(".apxpc-track"),
     slides=[].slice.call(root.querySelectorAll(".apxpc-slide")),
     dots=[].slice.call(root.querySelectorAll(".apxpc-dot"));
 if(!viewport||!track||!slides.length)return;

 var active=0,startX=0,startY=0,baseX=0,currentX=0,gesture=null,dragging=false;
 var mobile=function(){return matchMedia("(max-width:600px)").matches};
 var clamp=function(v,a,b){return Math.max(a,Math.min(b,v))};

 function centerX(i){
   var s=slides[i], edge=16;
   if(!mobile()||slides.length<2)return 0;
   /* First and last cards sit against the corresponding viewport edge.
      Interior cards stay centered so both neighbours remain visible. */
   if(i===0)return edge-s.offsetLeft;
   if(i===slides.length-1)return viewport.clientWidth-edge-(s.offsetLeft+s.offsetWidth);
   return viewport.clientWidth/2-(s.offsetLeft+s.offsetWidth/2);
 }
 function visualProgress(x){
   if(!mobile()||slides.length<2)return;
   var cs=getComputedStyle(track);
   var gap=parseFloat(cs.columnGap||cs.gap||"0")||0;
   var step=slides[0].offsetWidth+gap;
   slides.forEach(function(s,n){
     var dist=Math.abs((n-active)-((x-baseX)/step));
     var proximity=clamp(1-dist,0,1);
     var scale=.85+(.15*proximity);
     var opacity=.68+(.32*proximity);
     s.style.transform="scale("+scale.toFixed(4)+")";
     s.style.opacity=opacity.toFixed(4);
     s.style.zIndex=String(Math.round(proximity*10)+1);
   });
 }
 function clearVisual(){
   slides.forEach(function(s){s.style.transform="";s.style.opacity="";s.style.zIndex=""});
 }
 function setActive(i){
   active=clamp(i,0,slides.length-1);
   slides.forEach(function(s,n){s.classList.toggle("is-active",n===active)});
   dots.forEach(function(d,n){d.classList.toggle("is-active",n===active)});
 }
 function position(i,animate){
   setActive(i);
   if(mobile()&&slides.length>1){
     currentX=centerX(active); baseX=currentX;
     track.style.transition=animate===false?"none":"transform .42s cubic-bezier(.22,.72,.20,1)";
     track.style.transform="translate3d("+currentX+"px,0,0)";
     clearVisual();
   }else{
     track.style.transform="";clearVisual();
   }
 }
 dots.forEach(function(d){d.addEventListener("click",function(){position(Number(d.dataset.index),true)})});
 track.addEventListener("click",function(e){
   var s=e.target.closest(".apxpc-slide");
   if(s&&mobile()&&slides.length>1&&!dragging&&!e.target.closest(".entregarTarjeta"))position(Number(s.dataset.index),true);
 });

 viewport.addEventListener("touchstart",function(e){
   if(!mobile()||slides.length<2)return;
   startX=e.touches[0].clientX;startY=e.touches[0].clientY;
   gesture=null;dragging=false;baseX=centerX(active);currentX=baseX;
   track.style.transition="none";
 },{passive:true});

 viewport.addEventListener("touchmove",function(e){
   if(!mobile()||slides.length<2)return;
   var dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY,ax=Math.abs(dx),ay=Math.abs(dy);
   if(gesture===null&&Math.max(ax,ay)>=7)gesture=(ax>ay*1.08)?"horizontal":"vertical";
   if(gesture!=="horizontal")return; // native vertical page scroll remains available
   if(e.cancelable)e.preventDefault();
   dragging=true;
   var resistance=1;
   if((active===0&&dx>0)||(active===slides.length-1&&dx<0))resistance=.28;
   currentX=baseX+(dx*resistance);
   track.style.transform="translate3d("+currentX+"px,0,0)";
   visualProgress(currentX); // continuous zoom in/out while finger moves
 },{passive:false});

 viewport.addEventListener("touchend",function(e){
   if(!mobile()||slides.length<2){gesture=null;return}
   var dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;
   if(gesture==="horizontal"){
     var threshold=Math.min(58,slides[active].offsetWidth*.18);
     var next=active;
     if(Math.abs(dx)>threshold&&Math.abs(dx)>Math.abs(dy)*1.08)next=clamp(active+(dx<0?1:-1),0,slides.length-1);
     position(next,true);
     setTimeout(function(){dragging=false},40);
   }else dragging=false;
   gesture=null;
 },{passive:true});
 viewport.addEventListener("touchcancel",function(){position(active,true);gesture=null;dragging=false},{passive:true});
 window.addEventListener("resize",function(){requestAnimationFrame(function(){position(active,false)})});
 position(0,false);
}
return{init:init};
})();