# ApexImageActivity Region Plug-in v1.0.0
Oracle APEX 24.2.8. Galería dinámica para adjuntar imágenes a actividades.

## Flujo
LIST (SQL de región) → Agregar (Cámara/Galería) → editor ApexImageSDK → compresión → SP INSERT → refresh. Cada imagen puede abrirse en visor o eliminarse previa confirmación mediante SP DELETE.

## Atributos
1 ID imagen (mapping)
2 BLOB imagen
3 MIME type
4 Nombre archivo
5 Item ID sesión (VARCHAR2)
6 Item usuario
7 Item tipo funcionalidad (INTEGER)
8 Máximo imágenes
9 Procedimiento INSERT (PAQUETE.PROCEDIMIENTO)
10 Procedimiento DELETE (PAQUETE.PROCEDIMIENTO)
11 Target KB

## SQL
La fuente SQL debe devolver las imágenes del contexto actual y usar binds de página si corresponde. Ejemplo conceptual:
```sql
select id_imagen, imagen_blob, mime_type, nombre_archivo
from su_tabla
where id_sesion = :PXX_ID_SESION
```
No se asume ninguna tabla física. El límite se valida también server-side.

## Contratos PL/SQL
Ver `database/CONTRATO_PROCEDIMIENTOS.sql`. INSERT recibe sesión, usuario, tipo funcionalidad y metadatos/contenido; DELETE recibe ID imagen, sesión, usuario y tipo funcionalidad. Ambos usan 3 OUT estándar.

## Marca
Primario `#00683B`, secundario `#69BE38`. El plug-in no declara `font-family`; hereda la tipografía de la aplicación.
