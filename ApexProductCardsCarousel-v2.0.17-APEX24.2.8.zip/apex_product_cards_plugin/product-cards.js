window.ApexProductCards=(function(){"use strict";
function init(regionId){
 var root=document.getElementById(regionId);
 if(!root||root.dataset.apxpcReady==="Y")return;
 root.dataset.apxpcReady="Y";
 var viewport=root.querySelector(".apxpc-viewport"),
     track=root.querySelector(".apxpc-track"),
     slides=[].slice.call(root.querySelectorAll(".apxpc-slide")),
     dots=[].slice.call(root.querySelectorAll(".apxpc-dot"));
 if(!viewport||!track||!slides.length)return;

 var active=0,startX=0,startY=0,baseX=0,currentX=0,gesture=null,dragging=false;
 var mobile=function(){return matchMedia("(max-width:600px)").matches};
 var clamp=function(v,a,b){return Math.max(a,Math.min(b,v))};
 var haptic=function(ms){
   if(!mobile())return;
   if(typeof navigator!=="undefined"&&typeof navigator.vibrate==="function"){
     try{navigator.vibrate(ms)}catch(e){}
   }
 };

 function centerX(i){
   var s=slides[i], edge=16;
   if(!mobile()||slides.length<2)return 0;
   /* First and last cards sit against the corresponding viewport edge.
      Interior cards stay centered so both neighbours remain visible. */
   if(i===0)return edge-s.offsetLeft;
   if(i===slides.length-1)return viewport.clientWidth-edge-(s.offsetLeft+s.offsetWidth);
   return viewport.clientWidth/2-(s.offsetLeft+s.offsetWidth/2);
 }
 function visualProgress(x){
   if(!mobile()||slides.length<2)return;
   var cs=getComputedStyle(track);
   var gap=parseFloat(cs.columnGap||cs.gap||"0")||0;
   var step=slides[0].offsetWidth+gap;
   var delta=x-baseX;

   slides.forEach(function(s,n){
     var dist=Math.abs((n-active)+(delta/step));
     var proximity=clamp(1-dist,0,1);
     var scale=.85+(.15*proximity);
     var card=s.querySelector(".apxpc-card");
     if(!card)return;

     /* Scale the visual card, never the slide/layout box.
        The facing edge is anchored, so the real 12px gap never changes. */
     if(n<active){
       card.style.transformOrigin="right center";
     }else if(n>active){
       card.style.transformOrigin="left center";
     }else{
       card.style.transformOrigin=delta<0?"right center":(delta>0?"left center":"center center");
     }

     card.style.setProperty("transform","scale("+scale.toFixed(4)+")","important");
     card.style.zIndex=String(Math.round(proximity*10)+1);
   });
 }
 function clearVisual(){
   slides.forEach(function(s){
     var card=s.querySelector(".apxpc-card");
     if(card){
       card.style.removeProperty("transform");
       card.style.removeProperty("transform-origin");
       card.style.removeProperty("z-index");
       card.style.removeProperty("transition");
     }
   });
 }
 function setActive(i){
   active=clamp(i,0,slides.length-1);
   slides.forEach(function(s,n){s.classList.toggle("is-active",n===active)});
   dots.forEach(function(d,n){d.classList.toggle("is-active",n===active)});
   root.classList.toggle("apxpc-has-prev",active>0);
   root.classList.toggle("apxpc-has-next",active<slides.length-1);
 }
 function position(i,animate){
   var next=clamp(i,0,slides.length-1);

   if(mobile()&&slides.length>1){
     var targetX=centerX(next);
     var dur=animate===false?0:620;
     var easing="cubic-bezier(.22,.61,.20,1)";

     /* IMPORTANT:
        During drag, transform transitions are disabled. Re-enabling a transition
        and assigning the final transform in the same rendering frame can make
        the browser jump directly to the final state. We first preserve the
        exact dragged frame, force style resolution, then commit the target on
        the next animation frame. */
     track.style.transition=dur===0?"none":"transform "+dur+"ms "+easing;

     slides.forEach(function(s){
       var card=s.querySelector(".apxpc-card");
       if(card) card.style.transition=dur===0?"none":"transform "+dur+"ms "+easing;
     });

     /* Force the browser to recognize the current dragged transforms as the
        animation's starting point. No margin/gap/layout property is touched. */
     void track.offsetWidth;

     setActive(next);
     active=next;
     currentX=targetX;
     baseX=targetX;

     var applyTarget=function(){
       track.style.transform="translate3d("+targetX+"px,0,0)";
       slides.forEach(function(s,n){
         var card=s.querySelector(".apxpc-card");
         if(!card)return;
         card.style.transformOrigin=n<active?"right center":(n>active?"left center":"center center");
         card.style.setProperty("transform","scale("+(n===active?"1":".85")+")","important");
         card.style.zIndex=n===active?"11":"1";
       });
     };

     if(dur===0){
       applyTarget();
     }else{
       requestAnimationFrame(function(){
         requestAnimationFrame(applyTarget);
       });
       window.setTimeout(function(){
         slides.forEach(function(s){
           var card=s.querySelector(".apxpc-card");
           if(card)card.style.removeProperty("transition");
         });
         track.style.removeProperty("transition");
       },dur+80);
     }
   }else{
     setActive(next);
     active=next;
     track.style.transform="";
     clearVisual();
   }
 }
 root.addEventListener("click",function(e){
   var action=e.target.closest(".entregarTarjeta");
   if(action&&root.contains(action))haptic(7);
 },false);

 dots.forEach(function(d){d.addEventListener("click",function(){position(Number(d.dataset.index),true)})});
 track.addEventListener("click",function(e){
   var s=e.target.closest(".apxpc-slide");
   if(s&&mobile()&&slides.length>1&&!dragging&&!e.target.closest(".entregarTarjeta")){
     var idx=Number(s.dataset.index);
     if(idx!==active)haptic(9);
     position(idx,true);
   }
 });

 viewport.addEventListener("touchstart",function(e){
   if(!mobile()||slides.length<2)return;
   startX=e.touches[0].clientX;startY=e.touches[0].clientY;
   gesture=null;dragging=false;baseX=centerX(active);currentX=baseX;
   track.style.transition="none";
   slides.forEach(function(s){var c=s.querySelector(".apxpc-card");if(c)c.style.transition="none"});
 },{passive:true});

 viewport.addEventListener("touchmove",function(e){
   if(!mobile()||slides.length<2)return;
   var dx=e.touches[0].clientX-startX,dy=e.touches[0].clientY-startY,ax=Math.abs(dx),ay=Math.abs(dy);
   if(gesture===null&&Math.max(ax,ay)>=7)gesture=(ax>ay*1.08)?"horizontal":"vertical";
   if(gesture!=="horizontal")return; // native vertical page scroll remains available
   if(e.cancelable)e.preventDefault();
   dragging=true;
   var resistance=1;
   if((active===0&&dx>0)||(active===slides.length-1&&dx<0))resistance=.08;
   currentX=baseX+(dx*resistance);
   track.style.transform="translate3d("+currentX+"px,0,0)";
   visualProgress(currentX); // continuous zoom in/out while finger moves
 },{passive:false});

 viewport.addEventListener("touchend",function(e){
   if(!mobile()||slides.length<2){gesture=null;return}
   var dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;
   if(gesture==="horizontal"){
     var threshold=Math.min(58,slides[active].offsetWidth*.18);
     var next=active;
     if(Math.abs(dx)>threshold&&Math.abs(dx)>Math.abs(dy)*1.08)next=clamp(active+(dx<0?1:-1),0,slides.length-1);
     if(next!==active)haptic(9);
     position(next,true);
     setTimeout(function(){dragging=false},700);
   }else dragging=false;
   gesture=null;
 },{passive:true});
 viewport.addEventListener("touchcancel",function(){position(active,true);gesture=null;dragging=false},{passive:true});
 window.addEventListener("resize",function(){requestAnimationFrame(function(){position(active,false)})});
 position(0,false);
}
return{init:init};
})();