create or replace package pkg_apex_image_sdk as

    procedure actualizar_imagen (
        p_id_imagen       in  varchar2,
        p_id_solicitud    in  varchar2,
        p_nombre_archivo  in  varchar2,
        p_tamano_bytes    in  number,
        p_extension       in  varchar2,
        p_mime_type       in  varchar2,
        p_contenido       in  clob,
        p_estado_actual   in  varchar2,
        p_estado_nuevo    in  varchar2,
        p_operacion       in  varchar2,
        p_codigo_error    out number,
        p_mensaje_error   out varchar2,
        p_mensaje_tecnico out varchar2
    );

end pkg_apex_image_sdk;
/

create or replace package body pkg_apex_image_sdk as

    procedure actualizar_imagen (
        p_id_imagen       in  varchar2,
        p_id_solicitud    in  varchar2,
        p_nombre_archivo  in  varchar2,
        p_tamano_bytes    in  number,
        p_extension       in  varchar2,
        p_mime_type       in  varchar2,
        p_contenido       in  clob,
        p_estado_actual   in  varchar2,
        p_estado_nuevo    in  varchar2,
        p_operacion       in  varchar2,
        p_codigo_error    out number,
        p_mensaje_error   out varchar2,
        p_mensaje_tecnico out varchar2
    ) is
        l_id              app_imagenes.id%type;
        l_blob            blob;
        l_tamano_real     number;
        l_firma           varchar2(16);
        l_mime_real       varchar2(100);
        l_extension_real  varchar2(10);
        l_operacion       varchar2(20);
        l_estado_actual   varchar2(100);
        l_estado_nuevo    varchar2(100);
        l_usuario         varchar2(100);
        l_existe          number;
    begin
        p_codigo_error := 0;
        p_mensaje_error := null;
        p_mensaje_tecnico := null;

        l_operacion     := upper(trim(p_operacion));
        l_estado_actual := upper(trim(p_estado_actual));
        l_estado_nuevo  := upper(trim(p_estado_nuevo));

        if trim(p_id_imagen) is null or trim(p_id_solicitud) is null then
            p_codigo_error := 1001;
            p_mensaje_error := 'No se recibió la identificación completa del documento.';
            return;
        end if;

        if p_contenido is null or dbms_lob.getlength(p_contenido) = 0 then
            p_codigo_error := 1002;
            p_mensaje_error := 'No se recibió contenido de imagen.';
            return;
        end if;

        if l_operacion not in ('CARGA','CORRECCION') then
            p_codigo_error := 1003;
            p_mensaje_error := 'La operación solicitada no es válida.';
            p_mensaje_tecnico := 'Operación recibida: '||substr(p_operacion,1,100);
            return;
        end if;

        if l_operacion = 'CORRECCION' and l_estado_nuevo is null then
            p_codigo_error := 1004;
            p_mensaje_error := 'No se configuró el estado nuevo para la corrección.';
            return;
        end if;

        begin
            l_id := to_number(trim(p_id_imagen));
        exception
            when value_error then
                p_codigo_error := 1005;
                p_mensaje_error := 'El identificador de imagen no es válido.';
                return;
        end;

        select count(*)
          into l_existe
          from app_imagenes
         where id = l_id
           and codigo_sol = p_id_solicitud;

        if l_existe = 0 then
            p_codigo_error := 1006;
            p_mensaje_error := 'El documento no pertenece a la solicitud indicada.';
            return;
        end if;

        /*
          VALIDACIÓN DE ESTADO AUTORITATIVO
          ---------------------------------
          p_estado_actual llega desde el SQL del plug-in como contexto.
          Antes del UPDATE debe reconsultarse el estado real en la tabla corporativa
          que lo almacena.

          Regla indicada para CORRECCION:
            E = En corrección       -> permite cargar -> nuevo estado P
            P = Pendiente revisión  -> permite cargar -> permanece P

          APP_IMAGENES no contiene actualmente una columna ESTADO, por lo que este
          paquete no inventa dónde se persiste. Sustituya este bloque por la consulta
          a la tabla corporativa de estados cuando esté definida.

          Ejemplo conceptual:
             select estado into l_estado_bd
               from <TABLA_ESTADO>
              where ... for update;

             if l_operacion = 'CORRECCION'
                and l_estado_bd not in ('E','P') then
                 devolver error funcional;
             end if;

             if l_estado_bd <> l_estado_actual then
                 devolver error por cambio concurrente;
             end if;
        */

        l_blob := apex_web_service.clobbase642blob(p_contenido);

        if l_blob is null or dbms_lob.getlength(l_blob) = 0 then
            p_codigo_error := 1007;
            p_mensaje_error := 'La imagen está vacía o no pudo decodificarse.';
            return;
        end if;

        l_tamano_real := dbms_lob.getlength(l_blob);
        l_firma := rawtohex(dbms_lob.substr(l_blob,8,1));

        if substr(l_firma,1,6) = 'FFD8FF' then
            l_mime_real := 'image/jpeg';
            l_extension_real := 'jpg';
        elsif l_firma = '89504E470D0A1A0A' then
            l_mime_real := 'image/png';
            l_extension_real := 'png';
        else
            p_codigo_error := 1008;
            p_mensaje_error := 'El contenido no corresponde a una imagen JPEG o PNG válida.';
            p_mensaje_tecnico := 'Firma detectada: '||nvl(l_firma,'(NULL)');
            return;
        end if;

        if lower(trim(p_mime_type)) <> l_mime_real then
            p_codigo_error := 1009;
            p_mensaje_error := 'El MIME recibido no coincide con el contenido.';
            p_mensaje_tecnico := 'MIME enviado='||p_mime_type||'; detectado='||l_mime_real;
            return;
        end if;

        if lower(replace(trim(p_extension),'.','')) not in
           (l_extension_real,
            case when l_extension_real='jpg' then 'jpeg' else l_extension_real end)
        then
            p_codigo_error := 1010;
            p_mensaje_error := 'La extensión no coincide con el contenido.';
            return;
        end if;

        if p_tamano_bytes is not null and p_tamano_bytes <> l_tamano_real then
            p_codigo_error := 1011;
            p_mensaje_error := 'El tamaño informado no coincide con la imagen recibida.';
            p_mensaje_tecnico := 'Enviado='||p_tamano_bytes||'; real='||l_tamano_real;
            return;
        end if;

        l_usuario := substr(coalesce(sys_context('APEX$SESSION','APP_USER'),user),1,100);

        update app_imagenes
           set imagen_blob    = l_blob,
               nombre_archivo = substr(p_nombre_archivo,1,255),
               mime_type      = l_mime_real,
               tamano_bytes   = l_tamano_real,
               fecha_carga    = sysdate,
               usuario_carga  = l_usuario
         where id = l_id
           and codigo_sol = p_id_solicitud;

        if sql%rowcount = 0 then
            p_codigo_error := 1012;
            p_mensaje_error := 'No fue posible actualizar la imagen.';
            return;
        end if;

        /*
          TRANSICIÓN DE ESTADO
          --------------------
          En CORRECCION, después de validar el estado real:
              E -> P
              P -> P

          Use p_estado_nuevo como transición configurada por la región, pero valide
          contra las reglas corporativas antes de persistirla.

          Ejemplo conceptual:
             if l_operacion = 'CORRECCION' then
                 update <TABLA_ESTADO>
                    set estado = l_estado_nuevo
                  where ...;
             end if;

          No se implementa contra APP_IMAGENES porque esa tabla no posee ESTADO.
        */

        p_codigo_error := 0;
        p_mensaje_error := null;
        p_mensaje_tecnico := null;

        -- Sin COMMIT.
    exception
        when others then
            p_codigo_error := sqlcode;
            p_mensaje_error := 'Ocurrió un error al actualizar la imagen.';
            p_mensaje_tecnico := substr(sqlerrm,1,4000);
    end actualizar_imagen;

end pkg_apex_image_sdk;
/
