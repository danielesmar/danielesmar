# Product Cards Carousel – Oracle APEX 24.2.8

Region Plug-in para reemplazar la región Cards actual por el carrusel diseñado en el prototipo.

## Comportamiento

- Escritorio: cards horizontales con scroll.
- Móvil con 2+ productos: card central al 70% del viewport, 15% reservado a izquierda y 15% a derecha; vecinos reducidos al 88%, card central con foco; swipe/tap/dots.
- Móvil con 1 producto: card al 100% del ancho disponible, sin espacios laterales, sin dots y sin efecto carrusel.
- La imagen de la tarjeta ocupa el 100% del ancho interno del card.
- Número enmascarado y nombre del plástico se superponen dentro de la tarjeta.
- Textos largos (evento/tipo de tarjeta) crecen en varias líneas.
- El botón conserva exactamente la clase `entregarTarjeta` y los atributos `data-num-solicitud`, `data-estado-solicitud`, `data-csc-cita`, `data-cod-cliente`.

## Instalación

1. Shared Components > Plug-ins > Import.
2. Importar `region_type_plugin_com_banpro_product_cards_carousel.sql`.
3. En la página, crear una región del tipo **Product Cards Carousel**.
4. Pegar la consulta SQL en Source.
5. En los atributos del plug-in indicar los items que alimentan el botón:
   - Item CSC Cita: `P9_CSC_CITA`
   - Item Código Cliente: `P9_COD_CLIENTE`
6. En **Page Items to Submit**, agregar los items que use la consulta cuando la región se refresque por AJAX, por ejemplo `P9_CSC_CITA,P9_COD_CLIENTE,P9_APP_USER_TCG`.
7. Mantener tu Dynamic Action / JavaScript actual que escucha `.entregarTarjeta`.

## Alias SQL esperados

El plug-in obtiene los datos por **nombre de columna**, no por posición. Los alias principales son:

`NUMERO_DE_TARJETA_MASCARA`, `NUM_CTA_CREDITO`, `EVENTO_DE_TARJETA`, `DESCRIPCION_PRODUCTO`, `DIR_URL_IMAGEN_FONDO_TJT`, `TIPO_TARJETA_SOLICITADA`, `CATEG_TARJETA_DESC`, `NOMBRE_CLIENTE`, `ID_SOLICITUD`, `TEXTO_BOTON`, `ICONO_BOTON`, `COLOR`, `IND_ESTADO_VISITA_SOLICITUD`, `DES_ESTADO_VISITA_SOLICITUD`, `TIENE_PERMISO_ENTREGAR_TARJETA`, `NOMBRE_PLASTICO_TJT`.

## Consulta basada en la región actual

```sql
SELECT NUMERO_DE_TARJETA_MASCARA,
       NUM_CTA_CREDITO,
       EVENTO_DE_TARJETA,
       DESCRIPCION_PRODUCTO,
       DIR_URL_IMAGEN_FONDO_TJT,
       TIPO_TARJETA_SOLICITADA,
       CATEG_TARJETA_DESC,
       ESTADO_PAQUETE,
       CATEG_TARJETA,
       NOMBRE_CLIENTE,
       ID_SOLICITUD,
       NVL(REGEXP_SUBSTR(CS.INFO_ESTADO, '[^|]+', 1, 1), 'Realizar Entrega') AS TEXTO_BOTON,
       NVL(REGEXP_SUBSTR(CS.INFO_ESTADO, '[^|]+', 1, 2), 'fa-chevron-right') AS ICONO_BOTON,
       NVL(REGEXP_SUBSTR(CS.INFO_ESTADO, '[^|]+', 1, 3), '#f9ab00') AS COLOR,
       NVL(REGEXP_SUBSTR(CS.INFO_ESTADO, '[^|]+', 1, 4), 'fa-hourglass-half') AS ICONO,
       NVL(CS.IND_ESTADO_VISITA_SOLICITUD, 'A') AS IND_ESTADO_VISITA_SOLICITUD,
       NVL(CS.DES_ESTADO_VISITA_SOLICITUD, 'AGENDADO') AS DES_ESTADO_VISITA_SOLICITUD,
       PV.PV_UTIL_TARJETAS.ValidarPermiso('CITAS_ENTREGAR_TARJETA') AS TIENE_PERMISO_ENTREGAR_TARJETA,
       NOMBRE_PLASTICO_TJT
  FROM CV.CV_VW_SOLICITUDES_PRODUCTOS@TCBP S
  LEFT JOIN PV.PV_VW_VISITAS C
    ON S.COD_CLIENTE = C.COD_CLIENTE
   AND C.USR_GESTOR = S.USUARIO_SOLICITUD
   AND C.CSC_VISITA = :P9_CSC_CITA
  LEFT JOIN PV.PV_VW_CITA_SOLICITUDES CS
    ON C.CSC_VISITA = CS.CSC_VISITA
   AND CS.NUM_SOLICITUD = S.ID_SOLICITUD
   AND CS.COD_PAQUETE = S.NUM_PAQUETE
 WHERE S.COD_CLIENTE = :P9_COD_CLIENTE
   AND COD_ESTADO_PAQUETE = 'P'
   AND USUARIO_SOLICITUD = :P9_APP_USER_TCG
 ORDER BY IND_ESTADO_VISITA_SOLICITUD DESC
```

> Revisa el último `ORDER BY` contra tu SQL original antes de pasar a producción; la fotografía corta el extremo derecho de esa línea.

## Evento del botón

El HTML emitido conserva esta forma lógica:

```html
<a href="#"
   class="apxpc-action entregarTarjeta"
   data-num-solicitud="..."
   data-estado-solicitud="..."
   data-csc-cita="..."
   data-cod-cliente="...">
   Realizar Entrega
</a>
```

Por eso el manejador actual delegado, por ejemplo `$(document).on('click', '.entregarTarjeta', ...)`, puede seguir utilizándose sin cambiar el contrato.

## Archivos incluidos

- `region_type_plugin_com_banpro_product_cards_carousel.sql` – importable en APEX 24.2.
- `product-cards.css` – fuente CSS legible.
- `product-cards.js` – fuente JavaScript legible.
- `plugin_code.sql` – PL/SQL de render separado para mantenimiento.
