-- LAND_WATER TABLE
-------------------------------------------------------------
create table states_land_water (
	id                     number not null primary key,
	name                   varchar2(255),
	state_code             varchar2(2),
	land_area              number,
	water_area             number,
	geometry               sdo_geometry );
/


-- STORED PROCEDURE TO LOAD DATA FROM .JSON FILE
------------------------------------------------------------
create or replace procedure land_water_data(
    p_data_file	 in varchar2)
is
    l_land_water_json   blob;
begin
    if p_data_file is not null then
        select blob_content
          into l_land_water_json
          from apex_application_temp_files
         where name = p_data_file;
    end if;

    if l_land_water_json is not null then
        delete from states_land_water;
        insert into states_land_water (id, name, state_code, land_area, water_area, geometry )
        ( 
            select id, name, state_code, land_area, water_area, geometry
              from json_table(
                       l_land_water_json format json,
                       '$[*]'
                       columns (
                                 id          number             path '$.id',
                                 name        varchar2(255)      path '$.name',
                                 state_code  varchar2(255)      path '$.state_code',
                                 land_area   number             path '$.land_area',
                                 water_area  number             path '$.water_area',
                                 geometry    mdsys.sdo_geometry path '$.geometry' ) ) );
    end if;
end;
/