# ApexProductCardsCarousel v2.0.1 — Oracle APEX 24.2.8

## Cambios de esta versión

- Gesto móvil con **bloqueo direccional**:
  - Si el movimiento dominante es vertical, APEX/la página conserva su scroll normal.
  - Si el movimiento dominante es horizontal, el carrusel captura el gesto y evita el desplazamiento vertical de ese gesto.
  - Se usa una zona muerta de 8 px para no decidir la dirección por micro-movimientos del dedo.
- En móvil, con 2 o más registros:
  - card activo = `100vw - 64px`;
  - gap real entre cards = `16px`;
  - quedan 32 px libres a cada lado del card activo;
  - después del gap se ven **16 px del card vecino**, de modo que el usuario sabe que hay más contenido.
- Con un solo registro se mantiene el modo single: ancho disponible completo con 16 px de margen, sin dots ni peek lateral.
- Imagen física de tarjeta: **274 × 176 px**, centrada, `object-fit: contain`, sin borde/radio añadido por el plug-in.
- Nombre del cliente más grande y con sombra.
- Número/últimos dígitos más grandes y con sombra.
- Indicador activo del carrusel en verde primario `#00683B`.
- Botón outline primario sin background; icono en flujo flex para que nunca se monte sobre el texto.
- Contenido vertical más compacto.

## Configuración JSON completa equivalente al diseño actual

```json
{
  "titleColumn": "DESCRIPCION_PRODUCTO",
  "imageColumn": "DIR_URL_IMAGEN_FONDO_TJT",
  "panColumn": "NUMERO_DE_TARJETA_MASCARA",
  "holderColumn": "NOMBRE_PLASTICO_TJT",
  "sections": [
    {
      "class": "datos-producto",
      "fields": [
        {"label":"Número solicitud","column":"ID_SOLICITUD"},
        {"label":"Evento","column":"EVENTO_DE_TARJETA"},
        {"label":"Tipo producto","column":"CATEG_TARJETA_DESC"},
        {"label":"Tipo tarjeta","column":"TIPO_TARJETA_SOLICITADA"},
        {"label":"Cuenta crédito","column":"NUM_CTA_CREDITO"},
        {
          "label":"Estado entrega",
          "column":"DES_ESTADO_VISITA_SOLICITUD",
          "type":"status",
          "colorColumn":"COLOR"
        }
      ]
    }
  ],
  "button": {
    "permissionColumn": "TIENE_PERMISO_ENTREGAR_TARJETA",
    "textColumn": "TEXTO_BOTON",
    "iconColumn": "ICONO_BOTON",
    "requestColumn": "ID_SOLICITUD",
    "stateColumn": "IND_ESTADO_VISITA_SOLICITUD"
  }
}
```

## Columnas del SELECT consideradas por la configuración anterior

- `DESCRIPCION_PRODUCTO`: título del producto.
- `DIR_URL_IMAGEN_FONDO_TJT`: URL de la imagen física.
- `NUMERO_DE_TARJETA_MASCARA`: número enmascarado/últimos dígitos.
- `NOMBRE_PLASTICO_TJT`: nombre mostrado sobre la tarjeta.
- `ID_SOLICITUD`: número de solicitud y `data-num-solicitud`.
- `EVENTO_DE_TARJETA`: evento.
- `CATEG_TARJETA_DESC`: tipo de producto.
- `TIPO_TARJETA_SOLICITADA`: tipo de tarjeta.
- `NUM_CTA_CREDITO`: cuenta.
- `DES_ESTADO_VISITA_SOLICITUD`: texto del estado.
- `COLOR`: color semántico del estado.
- `TIENE_PERMISO_ENTREGAR_TARJETA`: controla si se genera el botón.
- `TEXTO_BOTON`: texto del botón.
- `ICONO_BOTON`: clase Font Awesome del botón.
- `IND_ESTADO_VISITA_SOLICITUD`: `data-estado-solicitud`.

Los valores `data-csc-cita` y `data-cod-cliente` continúan viniendo de los items configurables del plug-in, por defecto `P9_CSC_CITA` y `P9_COD_CLIENTE`.

## Campos dinámicos adicionales

Cada entrada de `sections[].fields[]` admite:

```json
{
  "label": "Prioridad",
  "column": "PRIORIDAD",
  "type": "status",
  "colorColumn": "COLOR_PRIORIDAD",
  "classColumn": "CLASE_PRIORIDAD",
  "span": "2",
  "template": "<strong style=\"color:#COLOR#\">#VALUE#</strong>"
}
```

Marcadores disponibles en `template`:
`#VALUE#`, `#LABEL#`, `#COLOR#`, `#CLASS#`.

## Contrato del botón

Se conserva:

```html
<a class="apxpc-action entregarTarjeta"
   data-num-solicitud="..."
   data-estado-solicitud="..."
   data-csc-cita="..."
   data-cod-cliente="...">
</a>
```

Por tanto, el evento JavaScript existente asociado a `.entregarTarjeta` no necesita cambiar.
