window.ApexProductCards=(function(){"use strict";
function init(regionId){
 var root=document.getElementById(regionId);
 if(!root||root.dataset.apxpcReady==="Y")return;
 root.dataset.apxpcReady="Y";
 var viewport=root.querySelector(".apxpc-viewport"),
     track=root.querySelector(".apxpc-track"),
     slides=[].slice.call(root.querySelectorAll(".apxpc-slide")),
     dots=[].slice.call(root.querySelectorAll(".apxpc-dot"));
 if(!viewport||!track||!slides.length)return;

 var active=0,startX=0,startY=0,gesture=null;
 var mobile=function(){return matchMedia("(max-width:600px)").matches};

 function position(i,animate){
   active=Math.max(0,Math.min(slides.length-1,i));
   slides.forEach(function(s,n){s.classList.toggle("is-active",n===active)});
   dots.forEach(function(d,n){d.classList.toggle("is-active",n===active)});
   if(mobile()&&slides.length>1){
     var s=slides[active];
     var x=viewport.clientWidth/2-(s.offsetLeft+s.offsetWidth/2);
     track.style.transition=animate===false?"none":"transform .28s cubic-bezier(.22,.7,.25,1)";
     track.style.transform="translate3d("+x+"px,0,0)";
   }else{
     track.style.transform="";
   }
 }

 dots.forEach(function(d){
   d.addEventListener("click",function(){position(Number(d.dataset.index))});
 });

 track.addEventListener("click",function(e){
   var s=e.target.closest(".apxpc-slide");
   if(s&&mobile()&&slides.length>1&&!e.target.closest(".entregarTarjeta")){
     position(Number(s.dataset.index));
   }
 });

 viewport.addEventListener("touchstart",function(e){
   if(!mobile()||slides.length<2)return;
   startX=e.touches[0].clientX;
   startY=e.touches[0].clientY;
   gesture=null;
 },{passive:true});

 viewport.addEventListener("touchmove",function(e){
   if(!mobile()||slides.length<2)return;
   var dx=e.touches[0].clientX-startX;
   var dy=e.touches[0].clientY-startY;
   var ax=Math.abs(dx), ay=Math.abs(dy);

   /* Direction lock only after a small dead-zone.
      Vertical gestures remain native page scrolling.
      Horizontal gestures belong exclusively to the carousel. */
   if(gesture===null && Math.max(ax,ay)>=8){
     gesture=(ax>ay*1.12)?"horizontal":"vertical";
   }
   if(gesture==="horizontal" && e.cancelable){
     e.preventDefault();
   }
 },{passive:false});

 viewport.addEventListener("touchend",function(e){
   if(!mobile()||slides.length<2){gesture=null;return;}
   var dx=e.changedTouches[0].clientX-startX;
   var dy=e.changedTouches[0].clientY-startY;
   if(gesture==="horizontal" && Math.abs(dx)>35 && Math.abs(dx)>Math.abs(dy)*1.12){
     position(active+(dx<0?1:-1));
   }
   gesture=null;
 },{passive:true});

 viewport.addEventListener("touchcancel",function(){gesture=null},{passive:true});
 window.addEventListener("resize",function(){requestAnimationFrame(function(){position(active,false)})});
 position(0,false);
}
return{init:init};
})();