namespace Domain.Entities
{
    public class FacturaDetalle
    {
        public int Id { get; set; }
        public int FacturaId { get; set; }
        public int ProductoId { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }

        public Factura Factura { get; set; } = null!;
        public Producto Producto { get; set; } = null!;
    }
}