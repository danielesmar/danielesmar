namespace Domain.Entities
{
    public class Invoice
    {
        public int Id { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
        public ICollection<InvoiceDetail> Details { get; set; } = new List<InvoiceDetail>();
    }
}