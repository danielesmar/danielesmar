using Xunit;
using System.Threading.Tasks;
using Application.Features.Clientes;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using Application.Interfaces;

namespace Tests.IntegrationTests
{
    public class ClienteIntegrationTests
    {
        private async Task<IApplicationDbContext> GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
                .Options;

            var context = new ApplicationDbContext(options);
            await context.Database.EnsureCreatedAsync();
            return context;
        }

        [Fact]
        public async Task CreateCliente_Should_Save_To_Database()
        {
            var context = await GetDbContext();
            var handler = new CreateClienteHandler(context);
            var id = await handler.Handle(new CreateClienteCommand("John Doe", "john@example.com"), CancellationToken.None);

            Assert.True(id > 0);
        }
    }
}