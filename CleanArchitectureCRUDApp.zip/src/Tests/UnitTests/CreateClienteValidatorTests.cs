using Xunit;
using Application.Features.Clientes;
using Application.Validators;

namespace Tests.UnitTests
{
    public class CreateClienteValidatorTests
    {
        [Fact]
        public void Validator_Should_Have_Error_When_Nombre_Is_Empty()
        {
            var validator = new CreateClienteValidator();
            var result = validator.Validate(new CreateClienteCommand("", "test@example.com"));
            Assert.False(result.IsValid);
        }

        [Fact]
        public void Validator_Should_Have_Error_When_Email_Is_Invalid()
        {
            var validator = new CreateClienteValidator();
            var result = validator.Validate(new CreateClienteCommand("John", "notanemail"));
            Assert.False(result.IsValid);
        }

        [Fact]
        public void Validator_Should_Pass_With_Valid_Data()
        {
            var validator = new CreateClienteValidator();
            var result = validator.Validate(new CreateClienteCommand("John", "john@example.com"));
            Assert.True(result.IsValid);
        }
    }
}