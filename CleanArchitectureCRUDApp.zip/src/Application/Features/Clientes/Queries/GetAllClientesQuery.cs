using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Clientes.Queries
{
    public record GetAllClientesQuery : IRequest<List<ClienteDto>>;

    public class ClienteDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }

    public class GetAllClientesHandler : IRequestHandler<GetAllClientesQuery, List<ClienteDto>>
    {
        private readonly IApplicationDbContext _context;

        public GetAllClientesHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<ClienteDto>> Handle(GetAllClientesQuery request, CancellationToken cancellationToken)
        {
            return await _context.Clientes
                .Select(c => new ClienteDto
                {
                    Id = c.Id,
                    Nombre = c.Nombre,
                    Email = c.Email
                }).ToListAsync(cancellationToken);
        }
    }
}