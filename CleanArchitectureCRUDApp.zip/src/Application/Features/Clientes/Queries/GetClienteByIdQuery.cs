using MediatR;
using Application.Interfaces;

namespace Application.Features.Clientes.Queries
{
    public record GetClienteByIdQuery(int Id) : IRequest<ClienteDto?>;

    public class GetClienteByIdHandler : IRequestHandler<GetClienteByIdQuery, ClienteDto?>
    {
        private readonly IApplicationDbContext _context;

        public GetClienteByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ClienteDto?> Handle(GetClienteByIdQuery request, CancellationToken cancellationToken)
        {
            var cliente = await _context.Clientes.FindAsync(new object[] { request.Id }, cancellationToken);
            return cliente == null ? null : new ClienteDto
            {
                Id = cliente.Id,
                Nombre = cliente.Nombre,
                Email = cliente.Email
            };
        }
    }
}