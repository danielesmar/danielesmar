using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Clientes.Commands
{
    public record DeleteClienteCommand(int Id) : IRequest<bool>;

    public class DeleteClienteHandler : IRequestHandler<DeleteClienteCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteClienteHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteClienteCommand request, CancellationToken cancellationToken)
        {
            var cliente = await _context.Clientes.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (cliente == null) return false;

            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}