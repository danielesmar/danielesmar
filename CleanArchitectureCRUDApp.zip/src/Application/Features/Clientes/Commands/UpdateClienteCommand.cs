using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Clientes.Commands
{
    public record UpdateClienteCommand(int Id, string Nombre, string Email) : IRequest<bool>;

    public class UpdateClienteHandler : IRequestHandler<UpdateClienteCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public UpdateClienteHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(UpdateClienteCommand request, CancellationToken cancellationToken)
        {
            var cliente = await _context.Clientes.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (cliente == null) return false;

            cliente.Nombre = request.Nombre;
            cliente.Email = request.Email;
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}