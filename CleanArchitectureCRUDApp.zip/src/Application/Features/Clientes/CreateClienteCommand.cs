using MediatR;
using Domain.Entities;
using Application.Interfaces;

namespace Application.Features.Clientes
{
    public record CreateClienteCommand(string Nombre, string Email) : IRequest<int>;

    public class CreateClienteHandler : IRequestHandler<CreateClienteCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public CreateClienteHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateClienteCommand request, CancellationToken cancellationToken)
        {
            var entity = new Cliente { Nombre = request.Nombre, Email = request.Email };
            _context.Clientes.Add(entity);
            await _context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}