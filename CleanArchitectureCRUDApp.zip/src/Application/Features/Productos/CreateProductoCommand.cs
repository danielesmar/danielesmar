using MediatR;
using Domain.Entities;
using Application.Interfaces;

namespace Application.Features.Productos
{
    public record CreateProductoCommand(string Nombre, decimal Precio) : IRequest<int>;

    public class CreateProductoHandler : IRequestHandler<CreateProductoCommand, int>
    {
        private readonly IApplicationDbContext _context;
        public CreateProductoHandler(IApplicationDbContext context) => _context = context;

        public async Task<int> Handle(CreateProductoCommand request, CancellationToken cancellationToken)
        {
            var entity = new Producto { Nombre = request.Nombre, Precio = request.Precio };
            _context.Productos.Add(entity);
            await _context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}