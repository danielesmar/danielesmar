using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Productos.Commands
{
    public record UpdateProductosCommand(int Id, string Nombre, decimal Precio) : IRequest<bool>;

    public class UpdateProductosHandler : IRequestHandler<UpdateProductosCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public UpdateProductosHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(UpdateProductosCommand request, CancellationToken cancellationToken)
        {
            var item = await _context.Productos.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (item == null) return false;

            item.Nombre = request.Nombre;
            item.Precio = request.Precio;
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}