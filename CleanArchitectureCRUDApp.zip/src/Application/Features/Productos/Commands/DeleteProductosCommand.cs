using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Productos.Commands
{
    public record DeleteProductosCommand(int Id) : IRequest<bool>;

    public class DeleteProductosHandler : IRequestHandler<DeleteProductosCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteProductosHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteProductosCommand request, CancellationToken cancellationToken)
        {
            var item = await _context.Productos.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (item == null) return false;

            _context.Productos.Remove(item);
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}