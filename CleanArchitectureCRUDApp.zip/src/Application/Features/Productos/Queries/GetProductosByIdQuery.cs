using MediatR;
using Application.Interfaces;

namespace Application.Features.Productos.Queries
{
    public record GetProductosByIdQuery(int Id) : IRequest<ProductosDto?>;

    public class GetProductosByIdHandler : IRequestHandler<GetProductosByIdQuery, ProductosDto?>
    {
        private readonly IApplicationDbContext _context;

        public GetProductosByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ProductosDto?> Handle(GetProductosByIdQuery request, CancellationToken cancellationToken)
        {
            var item = await _context.Productos.FindAsync(new object[] { request.Id }, cancellationToken);
            return item == null ? null : new ProductosDto
            {
                Id = item.Id,
                Nombre = item.Nombre,
                Precio = item.Precio
            };
        }
    }
}