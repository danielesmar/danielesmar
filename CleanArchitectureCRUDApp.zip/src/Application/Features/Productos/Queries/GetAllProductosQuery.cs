using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Productos.Queries
{
    public record GetAllProductosQuery : IRequest<List<ProductosDto>>;

    public class ProductosDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
    }

    public class GetAllProductosHandler : IRequestHandler<GetAllProductosQuery, List<ProductosDto>>
    {
        private readonly IApplicationDbContext _context;

        public GetAllProductosHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<ProductosDto>> Handle(GetAllProductosQuery request, CancellationToken cancellationToken)
        {
            return await _context.Productos.Select(p => new ProductosDto
            {
                Id = p.Id,
                Nombre = p.Nombre,
                Precio = p.Precio
            }).ToListAsync(cancellationToken);
        }
    }
}