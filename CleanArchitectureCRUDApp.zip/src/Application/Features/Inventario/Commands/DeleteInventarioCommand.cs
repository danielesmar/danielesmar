using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Inventario.Commands
{
    public record DeleteInventarioCommand(int Id) : IRequest<bool>;

    public class DeleteInventarioHandler : IRequestHandler<DeleteInventarioCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteInventarioHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteInventarioCommand request, CancellationToken cancellationToken)
        {
            var item = await _context.Inventario.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (item == null) return false;

            _context.Inventario.Remove(item);
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}