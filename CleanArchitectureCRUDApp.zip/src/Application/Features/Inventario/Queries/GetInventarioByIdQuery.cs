using MediatR;
using Application.Interfaces;

namespace Application.Features.Inventario.Queries
{
    public record GetInventarioByIdQuery(int Id) : IRequest<InventarioDto?>;

    public class GetInventarioByIdHandler : IRequestHandler<GetInventarioByIdQuery, InventarioDto?>
    {
        private readonly IApplicationDbContext _context;

        public GetInventarioByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<InventarioDto?> Handle(GetInventarioByIdQuery request, CancellationToken cancellationToken)
        {
            var item = await _context.Inventario.FindAsync(new object[] { request.Id }, cancellationToken);
            return item == null ? null : new InventarioDto
            {
                Id = item.Id,
                Nombre = item.Nombre,
                Precio = item.Precio
            };
        }
    }
}