using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Inventario.Queries
{
    public record GetAllInventarioQuery : IRequest<List<InventarioDto>>;

    public class InventarioDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
    }

    public class GetAllInventarioHandler : IRequestHandler<GetAllInventarioQuery, List<InventarioDto>>
    {
        private readonly IApplicationDbContext _context;

        public GetAllInventarioHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<InventarioDto>> Handle(GetAllInventarioQuery request, CancellationToken cancellationToken)
        {
            return await _context.Inventario.Select(p => new InventarioDto
            {
                Id = p.Id,
                Nombre = p.Nombre,
                Precio = p.Precio
            }).ToListAsync(cancellationToken);
        }
    }
}