using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Facturacion.Queries
{
    public record GetAllFacturacionQuery : IRequest<List<FacturacionDto>>;

    public class FacturacionDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Precio { get; set; }
    }

    public class GetAllFacturacionHandler : IRequestHandler<GetAllFacturacionQuery, List<FacturacionDto>>
    {
        private readonly IApplicationDbContext _context;

        public GetAllFacturacionHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<FacturacionDto>> Handle(GetAllFacturacionQuery request, CancellationToken cancellationToken)
        {
            return await _context.Facturacion.Select(p => new FacturacionDto
            {
                Id = p.Id,
                Nombre = p.Nombre,
                Precio = p.Precio
            }).ToListAsync(cancellationToken);
        }
    }
}