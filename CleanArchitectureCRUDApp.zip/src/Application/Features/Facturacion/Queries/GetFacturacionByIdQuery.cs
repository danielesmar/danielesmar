using MediatR;
using Application.Interfaces;

namespace Application.Features.Facturacion.Queries
{
    public record GetFacturacionByIdQuery(int Id) : IRequest<FacturacionDto?>;

    public class GetFacturacionByIdHandler : IRequestHandler<GetFacturacionByIdQuery, FacturacionDto?>
    {
        private readonly IApplicationDbContext _context;

        public GetFacturacionByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<FacturacionDto?> Handle(GetFacturacionByIdQuery request, CancellationToken cancellationToken)
        {
            var item = await _context.Facturacion.FindAsync(new object[] { request.Id }, cancellationToken);
            return item == null ? null : new FacturacionDto
            {
                Id = item.Id,
                Nombre = item.Nombre,
                Precio = item.Precio
            };
        }
    }
}