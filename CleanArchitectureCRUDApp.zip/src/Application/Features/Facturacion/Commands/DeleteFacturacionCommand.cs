using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Facturacion.Commands
{
    public record DeleteFacturacionCommand(int Id) : IRequest<bool>;

    public class DeleteFacturacionHandler : IRequestHandler<DeleteFacturacionCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteFacturacionHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteFacturacionCommand request, CancellationToken cancellationToken)
        {
            var item = await _context.Facturacion.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (item == null) return false;

            _context.Facturacion.Remove(item);
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}