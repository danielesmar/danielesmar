using MediatR;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Facturacion.Commands
{
    public record UpdateFacturacionCommand(int Id, string Nombre, decimal Precio) : IRequest<bool>;

    public class UpdateFacturacionHandler : IRequestHandler<UpdateFacturacionCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public UpdateFacturacionHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(UpdateFacturacionCommand request, CancellationToken cancellationToken)
        {
            var item = await _context.Facturacion.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);
            if (item == null) return false;

            item.Nombre = request.Nombre;
            item.Precio = request.Precio;
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}