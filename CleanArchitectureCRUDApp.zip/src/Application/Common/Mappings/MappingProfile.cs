using AutoMapper;
using Domain.Entities;
using Application.Features.Clientes.Queries;
using Application.Features.Productos.Queries;
using Application.Features.Inventario.Queries;
using Application.Features.Facturacion.Queries;

namespace Application.Common.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Cliente, ClienteDto>().ReverseMap();
            CreateMap<Producto, ProductoDto>().ReverseMap();
            CreateMap<Inventario, InventarioDto>().ReverseMap();
            CreateMap<FacturaDetalle, FacturaDetalleDto>().ReverseMap();
        }
    }
}