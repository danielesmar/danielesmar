using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain.Entities;

namespace Infrastructure.Data.Configurations
{
    public class FacturaDetalleConfiguration : IEntityTypeConfiguration<FacturaDetalle>
    {
        public void Configure(EntityTypeBuilder<FacturaDetalle> builder)
        {
            builder.HasKey(fd => fd.Id);
            builder.Property(fd => fd.Cantidad).IsRequired();
            builder.Property(fd => fd.Precio).IsRequired();
            builder.HasOne<Factura>()
                   .WithMany()
                   .HasForeignKey(fd => fd.FacturaId)
                   .OnDelete(DeleteBehavior.Cascade);
            builder.HasOne<Producto>()
                   .WithMany()
                   .HasForeignKey(fd => fd.ProductoId)
                   .OnDelete(DeleteBehavior.Cascade);
        }
    }
}