using DbUp;
using System.Reflection;

namespace Infrastructure.Migrations
{
    public static class DbUpMigrator
    {
        public static void RunMigration(string connectionString)
        {
            var upgrader = DeployChanges.To
                .SqlDatabase(connectionString)
                .WithScriptsEmbeddedInAssembly(Assembly.GetExecutingAssembly())
                .LogToConsole()
                .Build();

            if (upgrader.IsUpgradeRequired())
            {
                var result = upgrader.PerformUpgrade();
                if (!result.Successful)
                {
                    throw new Exception("Migration failed", result.Error);
                }
            }
        }
    }
}