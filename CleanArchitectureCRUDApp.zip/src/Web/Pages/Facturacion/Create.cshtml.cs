using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Application.Features.Facturacion;
using MediatR;

namespace Web.Pages.Facturacion
{
    public class CreateModel : PageModel
    {
        private readonly IMediator _mediator;
        public CreateModel(IMediator mediator) => _mediator = mediator;

        [BindProperty]
        public CreateFacturaCommand Factura { get; set; } = new();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _mediator.Send(Factura);
            return new JsonResult(new { success = true });
        }
    }
}