using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Domain.Entities;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Web.Pages.Productos
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public IndexModel(ApplicationDbContext context) => _context = context;

        public IActionResult OnGetGetAll()
        {
            var productos = _context.Productos.Select(p => new {
                p.Id,
                p.Nombre,
                p.Precio
            }).ToList();
            return new JsonResult(productos);
        }

        public IActionResult OnGetGet(int id)
        {
            var p = _context.Productos.FirstOrDefault(x => x.Id == id);
            if (p == null) return NotFound();
            return new JsonResult(new { p.Id, p.Nombre, p.Precio });
        }

        public IActionResult OnPostUpdate([FromForm] Producto model)
        {
            var p = _context.Productos.FirstOrDefault(x => x.Id == model.Id);
            if (p == null) return NotFound();

            p.Nombre = model.Nombre;
            p.Precio = model.Precio;
            _context.SaveChanges();
            return new JsonResult(new { success = true });
        }

        public IActionResult OnDeleteDelete(int id)
        {
            var p = _context.Productos.FirstOrDefault(x => x.Id == id);
            if (p == null) return NotFound();
            _context.Productos.Remove(p);
            _context.SaveChanges();
            return new JsonResult(new { success = true });
        }
    }
}