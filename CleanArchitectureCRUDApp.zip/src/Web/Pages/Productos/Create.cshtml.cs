using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Application.Features.Productos;
using MediatR;

namespace Web.Pages.Productos
{
    public class CreateModel : PageModel
    {
        private readonly IMediator _mediator;
        public CreateModel(IMediator mediator) => _mediator = mediator;

        [BindProperty]
        public CreateProductoCommand Producto { get; set; } = new();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _mediator.Send(Producto);
            return new JsonResult(new { success = true });
        }
    }
}