using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Application.Features.Inventario;
using MediatR;

namespace Web.Pages.Inventario
{
    public class CreateModel : PageModel
    {
        private readonly IMediator _mediator;
        public CreateModel(IMediator mediator) => _mediator = mediator;

        [BindProperty]
        public CreateInventarioCommand Inventario { get; set; } = new();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _mediator.Send(Inventario);
            return new JsonResult(new { success = true });
        }
    }
}