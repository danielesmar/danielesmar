function ajaxFormSubmit(formId, path, fallback = () => {}) {
    const form = $(formId);
    form.on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: path,
            data: form.serialize(),
            success: function(response) {
                fallback(response);
            },
            error: function(xhr) {
                console.error(xhr.responseText);
            }
        });
    });
}

function ajaxGet(url, onSuccess) {
    $.ajax({
        type: 'GET',
        url: url,
        success: onSuccess,
        error: function(xhr) {
            console.error(xhr.responseText);
        }
    });
}

function ajaxDelete(url, onSuccess) {
    $.ajax({
        type: 'DELETE',
        url: url,
        success: onSuccess,
        error: function(xhr) {
            console.error(xhr.responseText);
        }
    });
}