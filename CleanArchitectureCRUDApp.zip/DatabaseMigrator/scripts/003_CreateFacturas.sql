IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Facturas' AND xtype='U')
BEGIN
    CREATE TABLE Facturas (
        Id INT PRIMARY KEY IDENTITY,
        Fecha DATETIME NOT NULL DEFAULT GETDATE()
    );
END