IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Inventarios' AND xtype='U')
BEGIN
    CREATE TABLE Inventarios (
        Id INT PRIMARY KEY IDENTITY,
        ProductoId INT NOT NULL,
        Cantidad INT NOT NULL,
        FOREIGN KEY (ProductoId) REFERENCES Productos(Id)
    );
END