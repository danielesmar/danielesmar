IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Productos' AND xtype='U')
BEGIN
    CREATE TABLE Productos (
        Id INT PRIMARY KEY IDENTITY,
        Nombre NVARCHAR(100) NOT NULL,
        Precio DECIMAL(18,2) NOT NULL
    );
END