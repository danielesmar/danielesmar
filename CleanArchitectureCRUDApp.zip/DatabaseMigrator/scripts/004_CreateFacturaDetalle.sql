IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='FacturaDetalles' AND xtype='U')
BEGIN
    CREATE TABLE FacturaDetalles (
        Id INT PRIMARY KEY IDENTITY,
        FacturaId INT NOT NULL,
        ProductoId INT NOT NULL,
        Cantidad INT NOT NULL,
        Precio DECIMAL(18,2) NOT NULL,
        FOREIGN KEY (FacturaId) REFERENCES Facturas(Id),
        FOREIGN KEY (ProductoId) REFERENCES Productos(Id)
    );
END