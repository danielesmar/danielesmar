# GDS Code39 Scanner v0.6.1 R8 — Oracle APEX 24.2.8

## Correcciones R8

### Primer toque del botón
Se agregó un bloqueo de inicialización (`starting Promise`) para impedir carreras mientras `getUserMedia` y el scanner están arrancando. Un segundo evento durante el arranque reutiliza la misma inicialización en vez de iniciar otra cámara.

### Flash al detener
La secuencia de cierre ahora es:
1. Solicitar `torch:false` al track activo.
2. Restablecer el estado interno del flash.
3. Restablecer el texto a `Encender flash`.
4. Detener todos los MediaStreamTrack.
5. Liberar el video/worker.
6. Ocultar el lector y mostrar nuevamente el botón disparador.

`Scanner.stop()` también contiene una segunda protección que intenta `torch:false` antes de cerrar el track, cubriendo cierre manual, auto-stop y callbacks.

## Se mantiene
- Scanner Container Static ID.
- CSS declarativo + fallback runtime.
- UI responsive.
- ROI Code39.
- sonido/vibración.
- refresh de región y callback.
- compatibilidad objetivo Oracle APEX 24.2.8.

Se incrementó `p_files_version` a 8 para invalidar los archivos estáticos anteriores.
