# ApexImageSDK APEX Region Plug-in v4.4.11

Base: v4.4.0.

Fix del motor táctil y validación:
- `_drawEditor()` vuelve a ser puro: nunca corrige pan ni zoom durante el render.
- El pan se limita antes de dibujar, eliminando el ciclo gesto -> render -> corrección -> salto.
- Pinch usa el punto medio de los dedos y un mínimo de zoom derivado del crop actual.
- El interior del crop ahora desplaza la imagen; los 8 handles siguen redimensionando el crop.
- Carga inicial, Restablecer e Imagen completa inicializan la misma geometría válida.
- Rotación y Enderezar normalizan geometría una sola vez después de la transformación.
- Guardar valida sin cerrar el editor.
- Toast de validación compacto, neutral y no bloqueante; se elimina el gran óvalo rojo.

No se modifican backend, AJAX, PL/SQL, package, mappings, SAVE remoto,
compresión, summary, skeleton ni HTML sin registros.


## v4.4.11 — Enderezado por área seleccionada

- `Enderezar` analiza únicamente los píxeles visibles dentro del recorte actual.
- La imagen fuente completa no se recorta ni se destruye durante el análisis.
- Si el recorte corresponde a la imagen completa, el análisis equivale al comportamiento anterior.
- Se conserva el recorte, zoom y encuadre del usuario; después de aplicar el ángulo se normalizan únicamente los límites necesarios.
- Backend, AJAX, persistencia, compresión y contrato PL/SQL permanecen sin cambios.


## v4.4.11 — Gesto de selección restaurado
- Corregida una regresión confirmada: el SDK calculaba si el toque estaba dentro del recorte, pero no utilizaba ese resultado.
- Un dedo dentro del rectángulo ahora mueve la selección sobre la imagen.
- Un dedo fuera del rectángulo continúa desplazando la imagen.
- Dos dedos continúan controlando pan + pinch/zoom de la imagen.
- Los ocho anclajes continúan redimensionando el recorte.
- La selección se detiene en el límite válido de la imagen y no puede abarcar píxeles vacíos.
- Enderezado por área seleccionada, backend, AJAX, compresión y persistencia permanecen intactos.


## v4.4.11 — orientación/responsive
- Conserva la funcionalidad validada de v4.4.3.
- Recalcula el editor ante resize/orientationchange/Visual Viewport sin reiniciar la edición.
- Mantiene crop, zoom, pan y rotación al cambiar orientación.
- Añade layout compacto específico para móvil horizontal, manteniendo visibles herramientas y acciones.
- Al volver a vertical, restaura el layout móvil normal sin cerrar el editor.


## v4.4.11 — Mensajes SAVE no bloqueantes
- El error de guardado se muestra como toast dentro del editor, por encima del modal.
- Si SAVE falla, el editor permanece abierto y conserva imagen, crop, zoom, pan y rotación.
- Guardar queda bloqueado mientras hay una petición en curso para impedir envíos duplicados.
- Al fallar, Guardar se habilita nuevamente.
- Al guardar correctamente, se cierra el editor y aparece el toast global: “Imagen guardada correctamente.”
- Se elimina el `apex.message.alert` bloqueante del flujo de guardado.
- No se modifica crop, touch, orientación, enderezado, compresión, AJAX ni contrato PL/SQL.


## v4.4.11 — Compresión PNG corregida + loader APEX
- Corregido el caso en que un PNG opaco se mantenía como PNG y podía guardarse con cientos de KB.
- Se detecta transparencia real en el recorte: solo se conserva PNG cuando realmente hay píxeles transparentes.
- PNG opaco/fotográfico se convierte a JPEG y usa la compresión adaptativa configurada (~150 KB).
- Loader BLOB cambiado a `fa fa-refresh fa-anim-spin`.
- Se mantienen intactos crop, touch, orientación, enderezado, toasts SAVE, AJAX y PL/SQL.


## v4.4.11 — Nombres de parámetros del SP
Único ajuste de integración: pIdImagen, pIdSolicitud, pNombreArchivo, pTamanoBytes, pExtension, pMimeType, pContenido, pEstado, pOperacion, pCodigoError, pMensajeUsuario y pMensajeTecnico. Se mantienen los mismos 9 IN + 3 OUT y no se altera ninguna función del SDK.


## v4.4.11 — Corrección de Enderezar
- El Web Worker deja de ser un punto único de fallo para Enderezar.
- Si el Worker no carga, falla o expira, el análisis se ejecuta automáticamente en el hilo principal.
- Se conserva el análisis sobre el área seleccionada y todas las funciones ya validadas.


## v4.4.11 — Corrección nominal del SP
Cambios exclusivos en parámetros del procedimiento empresarial:
- `pEstado_actual` → `pEstadoActual`
- `pEstado_nuevo` → `pEstadoNuevo`
- `pMensajeError` → `pMensajeUsuario`
No se modifica ninguna función del SDK, editor, compresión, enderezado, AJAX o UI.


## v4.4.11 — Ajuste visual
El editor cerrado queda fuera del layout y no dibuja `.apxisdk__card`. El plug-in no define `font-family`, por lo que hereda Nunito Sans de la aplicación. Sin cambios funcionales.


## v4.4.11 — Corrección real del borde residual
La línea provenía de la `.apxisdk__card` raíz, que permanece en el DOM en modo integración, no de la tarjeta interna del editor. En `.apxisdk--integration` la tarjeta raíz queda sin borde, fondo, radio ni sombra. También se eliminaron referencias CSS a fuentes para heredar íntegramente Nunito Sans de la aplicación. Sin cambios JavaScript/backend.
