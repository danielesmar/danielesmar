procedure render (
    p_plugin in apex_plugin.t_plugin,
    p_region in apex_plugin.t_region,
    p_param  in apex_plugin.t_region_render_param,
    p_result in out nocopy apex_plugin.t_region_render_result )
is
    l_ctx             apex_exec.t_context;
    l_region_id       varchar2(255) := 'apxpc_' || p_region.id;
    l_count           pls_integer := 0;
    l_csc_item        varchar2(255) := nvl(p_region.attributes.get_varchar2('attr_csc_item'),'P9_CSC_CITA');
    l_client_item     varchar2(255) := nvl(p_region.attributes.get_varchar2('attr_client_item'),'P9_COD_CLIENTE');
    l_csc_cita        varchar2(4000);
    l_cod_cliente     varchar2(4000);

    function h(p_value varchar2) return varchar2 is
    begin return apex_escape.html(nvl(p_value,'')); end;
    function a(p_value varchar2) return varchar2 is
    begin return apex_escape.html_attribute(nvl(p_value,'')); end;
    function val(p_name varchar2) return varchar2 is
        l_col_idx pls_integer;
    begin
        l_col_idx := apex_exec.get_column_position(
            p_context     => l_ctx,
            p_column_name => upper(p_name),
            p_is_required => false );
        if l_col_idx is null then
            return null;
        end if;
        return apex_exec.get_varchar2(
            p_context    => l_ctx,
            p_column_idx => l_col_idx );
    exception
        when others then
            return null;
    end;
    function safe_class(p_value varchar2) return varchar2 is
    begin return regexp_replace(nvl(p_value,''),'[^A-Za-z0-9_ -]',''); end;
    function safe_color(p_value varchar2) return varchar2 is
    begin
      if regexp_like(nvl(p_value,''),'^(#[0-9A-Fa-f]{3,8}|[A-Za-z]{3,20})$') then return p_value; end if;
      return '#b26a00';
    end;
begin
    if apex_application.g_debug then
        apex_plugin_util.debug_region(p_plugin=>p_plugin,p_region=>p_region);
    end if;

    l_csc_cita    := apex_util.get_session_state(l_csc_item);
    l_cod_cliente := apex_util.get_session_state(l_client_item);

    htp.p('<div id="'||a(l_region_id)||'" class="apxpc">');
    htp.p('<div class="apxpc-viewport"><div class="apxpc-track">');

    l_ctx := apex_exec.open_query_context();
    while apex_exec.next_row(l_ctx) loop
        l_count := l_count + 1;
        htp.p('<div class="apxpc-slide'||case when l_count=1 then ' is-active' end||
              '" data-index="'||to_char(l_count - 1)||'">');
        htp.p('<article class="apxpc-card">');
        htp.p('<div class="apxpc-title"><span class="apxpc-title-icon" aria-hidden="true"></span><span class="apxpc-title-text">'||h(val('DESCRIPCION_PRODUCTO'))||'</span></div>');

        htp.p('<div class="apxpc-bank">');
        if val('DIR_URL_IMAGEN_FONDO_TJT') is not null then
            htp.p('<img class="apxpc-bank-img" src="'||a(val('DIR_URL_IMAGEN_FONDO_TJT'))||'" alt="">');
        end if;
        htp.p('<div class="apxpc-bank-shade"></div>');
        htp.p('<div class="apxpc-pan">'||h(val('NUMERO_DE_TARJETA_MASCARA'))||'</div>');
        htp.p('<div class="apxpc-holder">'||h(coalesce(val('NOMBRE_PLASTICO_TJT'),val('NOMBRE_CLIENTE')))||'</div>');
        htp.p('</div>');

        htp.p('<div class="apxpc-grid">');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Número solicitud</div><div class="apxpc-value">'||h(val('ID_SOLICITUD'))||'</div></div>');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Evento</div><div class="apxpc-value">'||h(val('EVENTO_DE_TARJETA'))||'</div></div>');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Tipo producto</div><div class="apxpc-value">'||h(val('CATEG_TARJETA_DESC'))||'</div></div>');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Tipo tarjeta</div><div class="apxpc-value">'||h(val('TIPO_TARJETA_SOLICITADA'))||'</div></div>');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Cuenta crédito</div><div class="apxpc-value">'||h(val('NUM_CTA_CREDITO'))||'</div></div>');
        htp.p('<div class="apxpc-field"><div class="apxpc-label">Estado entrega</div><div class="apxpc-value"><span class="apxpc-status" style="color:'||a(safe_color(val('COLOR')))||'"><span class="apxpc-status-dot"></span>'||h(val('DES_ESTADO_VISITA_SOLICITUD'))||'</span></div></div>');
        htp.p('</div>');

        if upper(nvl(val('TIENE_PERMISO_ENTREGAR_TARJETA'),'N')) = 'Y' then
            htp.p('<a href="#" class="apxpc-action entregarTarjeta" data-num-solicitud="'||a(val('ID_SOLICITUD'))||'" data-estado-solicitud="'||a(val('IND_ESTADO_VISITA_SOLICITUD'))||'" data-csc-cita="'||a(l_csc_cita)||'" data-cod-cliente="'||a(l_cod_cliente)||'">'||h(nvl(val('TEXTO_BOTON'),'Realizar Entrega'))||'<span class="apxpc-action-icon fa '||a(safe_class(nvl(val('ICONO_BOTON'),'fa-chevron-right')))||'" aria-hidden="true"></span></a>');
        end if;

        htp.p('</article></div>');
    end loop;
    apex_exec.close(l_ctx);

    htp.p('</div></div>');
    if l_count > 1 then
        htp.p('<div class="apxpc-dots" aria-label="Productos">');
        for i in 0..l_count-1 loop
            htp.p('<button type="button" class="apxpc-dot'||case when i=0 then ' is-active' end||
                  '" data-index="'||to_char(i)||'" aria-label="Producto '||to_char(i + 1)||'"></button>');
        end loop;
        htp.p('</div>');
    elsif l_count = 0 then
        htp.p('<div class="apxpc-empty">'||h(nvl(p_region.no_data_found_message,'No hay productos disponibles.'))||'</div>');
    end if;
    htp.p('</div>');

    if l_count = 1 then
        apex_javascript.add_onload_code('document.getElementById('||apex_javascript.add_value(l_region_id,false)||').classList.add("is-single");');
    end if;
    apex_javascript.add_onload_code('ApexProductCards.init('||apex_javascript.add_value(l_region_id,false)||');');
exception
    when others then
        begin apex_exec.close(l_ctx); exception when others then null; end;
        raise;
end render;
