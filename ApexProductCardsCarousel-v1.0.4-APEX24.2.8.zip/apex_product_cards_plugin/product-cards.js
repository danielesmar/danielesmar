window.ApexProductCards = (function () {
  "use strict";
  function init(regionId) {
    var root = document.getElementById(regionId);
    if (!root || root.dataset.apxpcReady === "Y") return;
    root.dataset.apxpcReady = "Y";
    var viewport = root.querySelector(".apxpc-viewport");
    var track = root.querySelector(".apxpc-track");
    var slides = Array.prototype.slice.call(root.querySelectorAll(".apxpc-slide"));
    var dots = Array.prototype.slice.call(root.querySelectorAll(".apxpc-dot"));
    if (!viewport || !track || !slides.length) return;
    var active = 0, startX = 0;
    var mobile = function(){ return window.matchMedia("(max-width:600px)").matches; };
    function position(i, animate) {
      active = Math.max(0, Math.min(slides.length - 1, i));
      slides.forEach(function(s,n){ s.classList.toggle("is-active", n === active); });
      dots.forEach(function(d,n){ d.classList.toggle("is-active", n === active); });
      if (mobile() && slides.length > 1) {
        var s = slides[active];
        var x = viewport.clientWidth / 2 - (s.offsetLeft + s.offsetWidth / 2);
        track.style.transition = animate === false ? "none" : "transform .34s cubic-bezier(.22,.7,.25,1)";
        track.style.transform = "translate3d(" + x + "px,0,0)";
      } else {
        track.style.transform = "";
      }
    }
    dots.forEach(function(d){ d.addEventListener("click", function(){ position(Number(d.dataset.index)); }); });
    track.addEventListener("click", function(e){
      var s = e.target.closest(".apxpc-slide");
      if (s && mobile() && slides.length > 1 && !e.target.closest(".entregarTarjeta")) position(Number(s.dataset.index));
    });
    viewport.addEventListener("touchstart", function(e){ startX = e.touches[0].clientX; }, {passive:true});
    viewport.addEventListener("touchend", function(e){
      if (!mobile() || slides.length < 2) return;
      var dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 35) position(active + (dx < 0 ? 1 : -1));
    }, {passive:true});
    window.addEventListener("resize", function(){ window.requestAnimationFrame(function(){ position(active, false); }); });
    position(0, false);
  }
  return { init:init };
})();
