# ApexProductCardsCarousel v1.0.4 — APEX 24.2.8

Corrige el ORA-06502 que aparecía al ejecutar la región después de instalar v1.0.3.

El backtrace de APEX apuntaba a la línea que construía `data-index`.
La expresión anterior concatenaba directamente `l_count-1` dentro del texto.
En PL/SQL, la combinación de concatenación y aritmética podía provocar una
conversión implícita de texto a NUMBER.

Ahora toda salida numérica HTML se convierte explícitamente:
- `to_char(l_count - 1)`
- `to_char(i)`
- `to_char(i + 1)`

También conserva la corrección de APEX_EXEC de v1.0.3 y las correcciones de
instalación de v1.0.1/v1.0.2.
