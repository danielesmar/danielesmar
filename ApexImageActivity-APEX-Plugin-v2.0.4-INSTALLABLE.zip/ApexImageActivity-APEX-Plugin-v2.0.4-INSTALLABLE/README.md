# ApexImageActivity APEX Region Plug-in v2.0.4

Variante de ApexImageActivity para Oracle APEX 24.2.8. Conserva galería, visor, editor, cámara/galería, compresión y diseño Promerica.

## Cambio principal
INSERT y DELETE ya no invocan procedimientos almacenados. El plug-in recibe los nombres de dos procesos APEX **Ajax Callback** y los ejecuta asíncronamente con `apex.server.process`. LIST y GET continúan encapsulados en el Ajax del Region Plug-in.

## Atributos
1. ID imagen (mapping)
2. Imagen BLOB (mapping)
3. MIME type (mapping)
4. Nombre archivo (mapping)
5. Tipo actividad (Page Item dinámico)
6. Cantidad máxima de imágenes
7. Proceso APEX INSERT
8. Proceso APEX DELETE
9. Target KB

Al iniciar con Tipo actividad vacío no genera error. Al cambiar el Page Item, configure una Dynamic Action **Change -> Refresh** sobre la región. El refresh vuelve a ejecutar el Source SQL y carga las imágenes del nuevo tipo.

## Procesos incluidos
- `apex_processes/APEX_PROCESS_INSERT.sql`
- `apex_processes/APEX_PROCESS_DELETE.sql`
- `apex_processes/REGION_SOURCE_SQL_EJEMPLO.sql`

El INSERT usa `PV.PV_INTC_CONFIGURACIONES.ObtenerIdPorCodigoCatalogo(pCatalogo=>'TIPO_ACTIVIDAD', pCodigo=>PARAM_TIPO_ACTIVIDAD)` y guarda en `pv_actividades_imagenes_tmp` los campos solicitados. No agrega auditoría adicional.

### IMPORTANTE sobre la PK
No se proporcionó el nombre físico de la columna ID de `pv_actividades_imagenes_tmp`. Los ejemplos usan **CSC_ACTIVIDAD_IMAGEN** como marcador. Si la PK real tiene otro nombre, sustituya únicamente ese identificador en el proceso DELETE y en el Source SQL de ejemplo.

## Colores
- Primario `#00683B`
- Secundario `#69BE38`

## Cambios v2.0.4
- El INSERT y DELETE toman el valor actual del Page Item de Tipo actividad al momento de ejecutar AJAX.
- Se valida que ObtenerIdPorCodigoCatalogo retorne un CSC antes de insertar/eliminar.
- El Source SQL tolera punto y coma o slash final; el plugin los normaliza antes de envolver la consulta.


## Corrección v2.0.4 — ciclo de vida APEX
- La región APEX se registra con el Static ID real de la región, no con el host interno del SDK.
- Un Refresh de Dynamic Action ejecuta refresh lógico (LIST/GET) sin destruir el DOM ni perder estilos.
- Inicialización idempotente: una instancia anterior se destruye antes de crear otra.
- Listeners globales usan AbortController para evitar duplicados/fugas.
- Se conserva el estado vacío cuando no hay tipo de actividad y se relee el Page Item actual en cada refresh.


## Cambios v2.0.4 — confirmación de eliminación

- Sustituye `apex.message.confirm` por un modal propio del plug-in.
- Muestra miniatura, nombre, tipo y tamaño de la imagen antes de eliminar.
- Botón destructivo rojo y Cancelar secundario, responsive para móvil/PWA.
- El DELETE continúa ejecutándose mediante el Ajax Callback configurado y sólo se invoca después de confirmar.


## v2.0.4 - Hotfix de archivos estáticos
Corrige el instalador v2.0.3, que podía registrar contenido CSS bajo apex-image-sdk.js. Todos los archivos estáticos embebidos fueron regenerados desde sus archivos fuente y validados byte a byte.
