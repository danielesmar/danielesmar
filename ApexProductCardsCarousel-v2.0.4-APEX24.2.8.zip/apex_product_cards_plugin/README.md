# ApexProductCardsCarousel v2.0.4 — Oracle APEX 24.2.8

## Cambios de esta versión

- Gesto móvil con **bloqueo direccional**:
  - Si el movimiento dominante es vertical, APEX/la página conserva su scroll normal.
  - Si el movimiento dominante es horizontal, el carrusel captura el gesto y evita el desplazamiento vertical de ese gesto.
  - Se usa una zona muerta de 8 px para no decidir la dirección por micro-movimientos del dedo.
- En móvil, con 2 o más registros:
  - card activo = `100vw - 64px`;
  - gap real entre cards = `16px`;
  - quedan 32 px libres a cada lado del card activo;
  - después del gap se ven **16 px del card vecino**, de modo que el usuario sabe que hay más contenido.
- Con un solo registro se mantiene el modo single: ancho disponible completo con 16 px de margen, sin dots ni peek lateral.
- Imagen física de tarjeta: **274 × 176 px**, centrada, `object-fit: contain`, sin borde/radio añadido por el plug-in.
- Nombre del cliente más grande y con sombra.
- Número/últimos dígitos más grandes y con sombra.
- Indicador activo del carrusel en verde primario `#00683B`.
- Botón outline primario sin background; icono en flujo flex para que nunca se monte sobre el texto.
- Contenido vertical más compacto.

## Configuración JSON completa equivalente al diseño actual

```json
{
  "titleColumn": "DESCRIPCION_PRODUCTO",
  "imageColumn": "DIR_URL_IMAGEN_FONDO_TJT",
  "panColumn": "NUMERO_DE_TARJETA_MASCARA",
  "holderColumn": "NOMBRE_PLASTICO_TJT",
  "sections": [
    {
      "class": "datos-producto",
      "fields": [
        {"label":"Número solicitud","column":"ID_SOLICITUD"},
        {"label":"Evento","column":"EVENTO_DE_TARJETA"},
        {"label":"Tipo producto","column":"CATEG_TARJETA_DESC"},
        {"label":"Tipo tarjeta","column":"TIPO_TARJETA_SOLICITADA"},
        {"label":"Cuenta crédito","column":"NUM_CTA_CREDITO"},
        {
          "label":"Estado entrega",
          "column":"DES_ESTADO_VISITA_SOLICITUD",
          "type":"status",
          "colorColumn":"COLOR"
        }
      ]
    }
  ],
  "button": {
    "permissionColumn": "TIENE_PERMISO_ENTREGAR_TARJETA",
    "textColumn": "TEXTO_BOTON",
    "iconColumn": "ICONO_BOTON",
    "requestColumn": "ID_SOLICITUD",
    "stateColumn": "IND_ESTADO_VISITA_SOLICITUD"
  }
}
```

## Columnas del SELECT consideradas por la configuración anterior

- `DESCRIPCION_PRODUCTO`: título del producto.
- `DIR_URL_IMAGEN_FONDO_TJT`: URL de la imagen física.
- `NUMERO_DE_TARJETA_MASCARA`: número enmascarado/últimos dígitos.
- `NOMBRE_PLASTICO_TJT`: nombre mostrado sobre la tarjeta.
- `ID_SOLICITUD`: número de solicitud y `data-num-solicitud`.
- `EVENTO_DE_TARJETA`: evento.
- `CATEG_TARJETA_DESC`: tipo de producto.
- `TIPO_TARJETA_SOLICITADA`: tipo de tarjeta.
- `NUM_CTA_CREDITO`: cuenta.
- `DES_ESTADO_VISITA_SOLICITUD`: texto del estado.
- `COLOR`: color semántico del estado.
- `TIENE_PERMISO_ENTREGAR_TARJETA`: controla si se genera el botón.
- `TEXTO_BOTON`: texto del botón.
- `ICONO_BOTON`: clase Font Awesome del botón.
- `IND_ESTADO_VISITA_SOLICITUD`: `data-estado-solicitud`.

Los valores `data-csc-cita` y `data-cod-cliente` continúan viniendo de los items configurables del plug-in, por defecto `P9_CSC_CITA` y `P9_COD_CLIENTE`.

## Campos dinámicos adicionales

Cada entrada de `sections[].fields[]` admite:

```json
{
  "label": "Prioridad",
  "column": "PRIORIDAD",
  "type": "status",
  "colorColumn": "COLOR_PRIORIDAD",
  "classColumn": "CLASE_PRIORIDAD",
  "span": "2",
  "template": "<strong style=\"color:#COLOR#\">#VALUE#</strong>"
}
```

Marcadores disponibles en `template`:
`#VALUE#`, `#LABEL#`, `#COLOR#`, `#CLASS#`.

## Contrato del botón

Se conserva:

```html
<a class="apxpc-action entregarTarjeta"
   data-num-solicitud="..."
   data-estado-solicitud="..."
   data-csc-cita="..."
   data-cod-cliente="...">
</a>
```

Por tanto, el evento JavaScript existente asociado a `.entregarTarjeta` no necesita cambiar.

## Ajustes v2.0.4
- Arrastre horizontal 1:1 con el dedo: el track acompaña continuamente el `touchmove`.
- Zoom in/out continuo de los cards según su proximidad al centro, no solamente al soltar.
- Snap suave al card destino al finalizar el gesto.
- Mayor peek lateral: card móvil `100vw - 96px`; con gap 16px quedan ~32px visibles del vecino.
- El gesto vertical sigue siendo nativo de la página.
- Botón outline primario de 48px de alto.
- Todos los cards usan borde neutro `#dde3de`, incluso el activo.
- Sombra uniforme `0 2px 8px rgba(0,0,0,.05)`.

## Ajustes v2.0.4
- Se redujo a la mitad el espacio lateral móvil respecto a v2.0.2.
- En móvil el card usa `100vw - 48px`, manteniendo `gap:16px`.
- La imagen física deja de estar limitada a 274 px en móvil y se adapta al 100% del ancho útil del card conservando `aspect-ratio:274/176` y `object-fit:contain`.
- Nombre del cliente y número de tarjeta reducidos.
- Snap/transición horizontal aumentado a 380 ms con curva más suave.
- Escritorio: todos los cards son de 390 px, exactamente iguales, sin zoom, opacidad ni efecto de foco.
- Escritorio conserva únicamente desplazamiento horizontal cuando la suma de cards excede el ancho disponible.

## Ajustes v2.0.4
- En móvil el carrusel sale del padding/contenedor de la región APEX y usa `100vw` real.
- Se eliminan los márgenes laterales impuestos por la región para que el desplazamiento se sienta de borde a borde.
- Card móvil activo: 78vw.
- Gap móvil: 12px.
- Esto deja visible una porción clara del card anterior/siguiente incluso sin mantener el dedo presionado.
- El track usa `align-items:stretch` y los cards `height:100%` para conservar alturas visuales iguales.
- La imagen ocupa el 100% del ancho interno del card y conserva `aspect-ratio:274/176`.
- El cálculo JavaScript del zoom/transición ahora lee el gap real desde CSS.
- Snap final suavizado a 420ms.
