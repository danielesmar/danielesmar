# ApexDateTimeSDK v1.3.9 — Corrección de fidelidad visual

Objetivo: conservar la integración APEX de v1.1.x sin rediseñar el componente validado en `PRO Configurator v0.5`.

## Fuente visual canónica
La interfaz v1.3.9 replica las decisiones del prototipo:
- campo consolidado de 58 px, dividido Fecha | Hora;
- iconos verdes y valores dentro de cada zona;
- editor inline con borde/radio de 8 px;
- tabs de 66 px y línea verde de 4 px;
- calendario con botones 44x44 y días de 42 px;
- área de contenido de 382 px;
- selector de hora dentro de card interno;
- encabezados HORA / MINUTOS / PERÍODO;
- ruedas de 238 px, filas de 58 px y banda central a 90 px;
- banda seleccionada `#e8f4ed` con borde `#00683B`;
- valores vecinos atenuados;
- AM/PM como slider vertical de dos estados;
- botones Aceptar/Cancelar de 49 px, apilados;
- animación v0.5 de slide puro de 18 px, sin fade ni scale.

## Correcciones respecto de v1.1.0
- Se elimina el rediseño accidental del campo.
- Placeholder por defecto queda vacío; no se introduce texto visual nuevo.
- Se recuperan proporciones y jerarquía de las ruedas.
- Se recupera el card interno de hora.
- Se recupera el comportamiento visual AM/PM.
- Se recupera la transición Fecha → Hora.
- Se mantiene Modo `DATETIME` / `DATE`, confirmación automática en Solo fecha, límites, 12/24 h, minute step, posición adaptativa, haptics, APEX item API y session state.

## Solo fecha
En modo DATE:
- desaparecen divisor, zona Hora y tab Hora;
- el calendario conserva exactamente el lenguaje visual;
- con confirmación AUTO, tocar un día actualiza el item y cierra sin mostrar Aceptar/Cancelar;
- el valor se normaliza a `YYYY-MM-DD 00:00:00`.

## APEX
El propio Page Item sigue siendo el valor real. No cree un Hidden Item adicional.

```javascript
apex.item("P200_FECHA_VISITA").getValue()
apex.item("P200_FECHA_VISITA").setValue("2026-10-23 19:30:00")
```

PL/SQL:
```sql
to_date(:P200_FECHA_VISITA,'YYYY-MM-DD HH24:MI:SS')
```

## Prueba de regresión visual recomendada
Compare en el mismo teléfono:
1. PRO Configurator v0.5
2. Plug-in v1.3.9 en APEX

Verifique: campo, tabs, calendario, card de hora, banda central, tipografía relativa, separación, botones y animación.


## Corrección v1.3.9 — cruce AM/PM en la rueda de horas
Se restauró exactamente la lógica circular del prototipo v0.5: la rueda conserva el índice visual anterior, calcula dirección y cruces de bloque, y alterna AM/PM cada vez que se atraviesa el límite 12 ↔ 01. El recentrado de la rueda continúa siendo silencioso y no cambia el período por sí solo.


## Corrección v1.3.9 — Placeholder realmente opcional
Se corrigió el valor predeterminado heredado en la definición SQL del atributo `Placeholder`.

- Si `Placeholder` está vacío en Page Designer, el plug-in NO muestra ningún texto inventado.
- La zona Fecha conserva únicamente su etiqueta `Fecha`.
- La zona Hora conserva únicamente su etiqueta `Hora`.
- El atributo Placeholder continúa disponible únicamente si el desarrollador desea configurarlo explícitamente.
- No se modificaron estilos, ruedas ni la corrección AM/PM de v1.1.2.


## v1.3.9 — Modos estrictos del control

El atributo **Modo del control** ahora tiene tres responsabilidades visuales reales:

### Fecha y hora
Muestra únicamente la composición Fecha | Hora y permite navegar entre calendario y rueda horaria.

### Solo fecha
Muestra un único campo Fecha. Al abrirlo, renderiza únicamente calendario. No se crea zona Hora, tab Hora, rueda de horas ni AM/PM. Si Confirmación = Automática, seleccionar el día confirma y cierra sin botones.

### Solo hora
Muestra un único campo Hora. Al abrirlo, renderiza únicamente la rueda de Hora / Minutos / Período (o dos columnas en 24h). No se crea zona Fecha, tab Fecha ni calendario.

Para mantener un único contrato textual compatible con el item, Solo hora utiliza internamente una fecha neutral:
`1970-01-01 HH24:MI:00`.
Visualmente jamás se muestra esa fecha. Para una columna Oracle DATE puede convertirse con el mismo `TO_DATE`. Si el destino es otra estructura, puede extraerse la porción horaria según la lógica de la aplicación.

Las opciones de Page Designer que no aplican a un modo pueden seguir apareciendo por limitaciones de esta definición inicial de atributos, pero **no alteran ni renderizan controles que no correspondan al modo seleccionado**. Una revisión posterior puede incorporar dependencias de atributos en Page Designer sin modificar la UI runtime.

## v1.3.9 — corrección crítica del renderer APEX

La causa de que todos los modos se vieran como Fecha + Hora estaba en el callback PL/SQL `render_adt`: el atributo 16 **Modo del control** existía en Page Designer, pero nunca se enviaba al inicializador JavaScript. Por eso el cliente siempre utilizaba el default `DATETIME`.

Se corrigió el contrato servidor → cliente y ahora se transmiten también los atributos 16 a 19.

Contrato visual/runtime:
- `DATETIME`: sin cambios respecto del control completo validado.
- `DATE`: un único input visual Fecha; abre solo calendario; tocar un día válido confirma y cierra inmediatamente; no hay tabs ni botones Aceptar/Cancelar.
- `TIME`: un único input visual Hora; abre solo las ruedas; conserva Aceptar/Cancelar y el comportamiento circular AM/PM.

## v1.3.9 — Inline / Bottom Sheet + configuración contextual
Nuevo atributo **Modo de visualización**:
- INLINE: comportamiento existente.
- BOTTOM_SHEET: reutiliza exactamente calendario/ruedas actuales dentro de un panel inferior con backdrop, safe-area y cierre al tocar fuera.

Page Designer incorpora dependencias para ocultar opciones que no aplican:
- Solo fecha: oculta opciones horarias.
- Solo hora: oculta opciones de calendario/fecha.
- Bottom Sheet: oculta Posición del editor y Desplazamiento automático.
- Texto Limpiar: visible únicamente cuando Permitir limpiar está activo.

El modo del control sigue siendo independiente del modo de visualización.


## v1.3.9 — Installer ID collision fix
Se corrigió una colisión de IDs del export APEX. Los valores `Inline` y `Bottom Sheet` del atributo 20 habían reutilizado IDs ya asignados a valores del atributo `Confirmación en Solo fecha`, provocando `WWV_FLOW_PLUGIN_ATTRV_PK`.

Nuevos IDs:
- Inline: `901000000000003001`
- Bottom Sheet: `901000000000003002`

No hay cambios funcionales ni visuales respecto de v1.3.0.

## v1.3.9 — Bottom Sheet CSS scope fix
La v1.3.1 movía `.adt-panel` directamente a `body`. El diseño canónico está namespaced bajo `.adt-sdk`, por lo que al sacar el panel de ese ancestro se perdían prácticamente todos los estilos y el navegador mostraba botones/ruedas HTML nativos.

La v1.3.9 mueve el contenedor `.adt-sdk` completo al overlay mientras el Bottom Sheet está abierto. De esta forma calendario, tabs, wheel card, selector central, AM/PM y acciones conservan exactamente el mismo CSS del modo Inline. Al cerrar, el host vuelve a su posición original mediante un marcador DOM.

## v1.3.9 — Swipe/drag para cambiar mes
El calendario ahora admite navegación horizontal adicional:
- swipe derecha → izquierda: mes siguiente;
- swipe izquierda → derecha: mes anterior;
- mouse/trackpad mediante arrastre horizontal;
- los botones anterior/siguiente permanecen intactos;
- umbral de 46 px y validación vertical para no confundir scroll/toque con swipe;
- después de un swipe se suprime el click residual para evitar seleccionar accidentalmente un día;
- transición horizontal de 180 ms y soporte `prefers-reduced-motion`;
- funciona tanto Inline como Bottom Sheet porque ambos reutilizan el mismo calendario.

## v1.3.9 — Landscape Geometry Fix
Esta versión vuelve a partir de v1.3.3, no de v1.3.4.
- Detecta landscape usando visualViewport.
- Calendario compacto real para mostrar el mes completo.
- Mantiene intacta la geometría canónica de ruedas: 238px / banda 58px / top 90px.
- No recorta las ruedas ni desplaza el valor seleccionado respecto a la banda.
- Reduce solamente espacios, cabecera y acciones en landscape.
- Scroll de emergencia únicamente por debajo de 430px de altura.
- Conserva swipe/drag mensual v1.3.3.

## v1.3.9 — Hotfix + Adaptive Presentation
- Reconstruida desde v1.3.5 estable.
- Corrige el error JavaScript introducido en v1.3.6: la lógica responsive quedó fuera del scope de `init`.
- BOTTOM_SHEET funciona en móvil y pasa a Inline automáticamente desde 768px.
- Cambio de breakpoint/orientación se maneja dentro de cada instancia del item.
- Bottom Sheet usa altura por contenido y reduce el espacio vacío antes de las acciones.
- Conserva swipe mensual y geometría correcta de las ruedas.

## v1.3.9 — Load Hotfix / Stable Calendar / Fixed Device Presentation
- Corrige el fallo de carga introducido en v1.3.8.
- JavaScript validado sintácticamente antes de empaquetar.
- Calendario reserva siempre 42 celdas (6 semanas), evitando cambios de altura entre meses.
- Si se configura BOTTOM_SHEET, el modo se decide una sola vez al cargar:
  - ancho inicial < 768 px: Bottom Sheet;
  - ancho inicial >= 768 px: Inline.
- Rotar o redimensionar ya NO cambia Bottom Sheet ↔ Inline ni mueve el control.
- Se eliminó la lógica JavaScript de orientación/visualViewport que alteraba la presentación.
- El swipe mensual y la lógica funcional de v1.3.7 se conservan.
