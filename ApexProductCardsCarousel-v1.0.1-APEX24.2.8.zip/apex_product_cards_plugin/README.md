# ApexProductCardsCarousel v1.0.1 — Oracle APEX 24.2.8

Corrección de instalación respecto a v1.0.0.

## Error corregido
APEX 24.2.8 rechazaba durante la importación:
`create_plugin_std_attribute(... p_name=>'AJAX_ITEMS_TO_SUBMIT')`
con `APEX_240200.PLUGIN_STD_ATTR_NAME_CK`.

La exportación anterior declaraba los atributos estándar en `p_standard_attributes`
y además intentaba crearlos manualmente con `create_plugin_std_attribute`.
En v1.0.1 se eliminan esas llamadas manuales. Se conserva la declaración:
`SOURCE_LOCATION:AJAX_ITEMS_TO_SUBMIT:NO_DATA_FOUND_MESSAGE`.

## Instalación
1. Shared Components > Plug-ins > Import.
2. Importe `region_type_plugin_com_banpro_product_cards_carousel.sql`.
3. Instale el plug-in.
4. Cree una región del tipo `Product Cards Carousel`.
5. Pegue la consulta SQL de productos en Source.
6. Configure los items CSC Cita y Código Cliente si no son P9_CSC_CITA/P9_COD_CLIENTE.

El botón conserva la clase `entregarTarjeta` y los data attributes:
- data-num-solicitud
- data-estado-solicitud
- data-csc-cita
- data-cod-cliente

El carrusel mantiene el comportamiento móvil 15% / 70% / 15%, y con un único
registro usa el ancho disponible sin dots ni espacios laterales.
