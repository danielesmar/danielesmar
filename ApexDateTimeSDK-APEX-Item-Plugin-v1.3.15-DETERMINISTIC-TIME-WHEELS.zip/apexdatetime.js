/* ApexDateTimeSDK Item Plug-in v1.3.15 — faithful PRO Configurator v0.5 UI */
(function(apex,$){"use strict";
window.ApexDateTimeSDK=window.ApexDateTimeSDK||{};
const pad=n=>String(n).padStart(2,"0");
const MONTHS=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
const SHORT=["JAN","FEB","MAR","APR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"];
function parse(v){if(!v)return null;let m=String(v).trim().match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/);if(!m)return null;let H=+(m[4]||0);return{y:+m[1],m:+m[2]-1,d:+m[3],h:(H%12)||12,min:+(m[5]||0),ap:H>=12?"PM":"AM"}}
function now(){let x=new Date(),H=x.getHours();return{y:x.getFullYear(),m:x.getMonth(),d:x.getDate(),h:(H%12)||12,min:x.getMinutes(),ap:H>=12?"PM":"AM"}}
function ora(x,mode){let H=x.h%12+(x.ap==="PM"?12:0);if(x.h===12)H=x.ap==="AM"?0:12;if(mode==="DATE")return `${x.y}-${pad(x.m+1)}-${pad(x.d)} 00:00:00`;if(mode==="TIME")return `1970-01-01 ${pad(H)}:${pad(x.min)}:00`;return `${x.y}-${pad(x.m+1)}-${pad(x.d)} ${pad(H)}:${pad(x.min)}:00`}
function init(id,o){
 const input=document.getElementById(id); if(!input)return;
 const host=document.getElementById(id+"_ADT"); if(!host)return;
 const opt=Object.assign({mode:"DATETIME",dateConfirm:"AUTO",hourFormat:"12",minuteStep:5,dateFormat:"DD/MM/YYYY",position:"AUTO",autoScroll:true,haptics:true,minMode:"NONE",minValue:"",maxMode:"NONE",maxValue:"",acceptText:"Aceptar",cancelText:"Cancelar",dateText:"Fecha",timeText:"Hora",placeholder:"",allowClear:false,clearText:"Limpiar",displayMode:"INLINE",calendarIcon:"fa fa-calendar",clockIcon:"fa fa-clock-o"},o||{});
 opt.mode=String(opt.mode||"DATETIME").toUpperCase();
 const isDateOnly=opt.mode==="DATE",isTimeOnly=opt.mode==="TIME",isDateTime=opt.mode==="DATETIME";
 const isSheet=String(opt.displayMode||"INLINE").toUpperCase()==="BOTTOM_SHEET";
 let saved=parse(input.value),draft=saved?{...saved}:now(),active=isTimeOnly?"time":"date",closeTimer,lastHaptic=0;
 host.className="adt-sdk"+(isSheet?" adt-bottom-sheet":"")+(isDateOnly?" adt-date-only":"")+(isTimeOnly?" adt-time-only":"")+(isDateOnly?" adt-auto-confirm":"");
 host.innerHTML=`<div class="adt-field" role="group">
 ${!isTimeOnly?`<button type="button" class="adt-zone adt-date" aria-label="Editar fecha"><i class="${opt.calendarIcon}"></i><span><small>${esc(opt.dateText)}</small><strong></strong></span></button>`:""}
 ${isDateTime?`<span class="adt-divider"></span>`:""}
 ${!isDateOnly?`<button type="button" class="adt-zone adt-time" aria-label="Editar hora"><i class="${opt.clockIcon}"></i><span><small>${esc(opt.timeText)}</small><strong></strong></span></button>`:""}</div>
 <section class="adt-panel">
 <div class="adt-tabs" role="tablist">
 ${!isTimeOnly?`<button type="button" class="adt-tab adt-date-tab" role="tab"><small>${esc(opt.dateText)}</small><strong></strong></button>`:""}
 ${!isDateOnly?`<button type="button" class="adt-tab adt-time-tab" role="tab"><small>${esc(opt.timeText)}</small><strong></strong></button>`:""}
 </div><div class="adt-content" role="tabpanel"></div>
 <div class="adt-actions"><button type="button" class="adt-primary">${esc(opt.acceptText)}</button><button type="button" class="adt-secondary">${esc(opt.cancelText)}</button>${opt.allowClear?`<button type="button" class="adt-clear">${esc(opt.clearText)}</button>`:""}</div></section>`;
 let overlay=null,homeMarker=null;
 if(isSheet){overlay=document.createElement("div");overlay.className="adt-sheet-overlay";overlay.setAttribute("aria-hidden","true");document.body.appendChild(overlay);homeMarker=document.createComment("ApexDateTimeSDK home");host.parentNode.insertBefore(homeMarker,host)}
 const panel=host.querySelector(".adt-panel"),content=host.querySelector(".adt-content"),dateZone=host.querySelector(".adt-date"),timeZone=host.querySelector(".adt-time"),dateTab=host.querySelector(".adt-date-tab"),timeTab=host.querySelector(".adt-time-tab");
 function esc(s){return $("<div>").text(s||"").html()}
 function vd(x){if(!x)return opt.placeholder||"";let d=pad(x.d),m=pad(x.m+1);if(opt.dateFormat==="MM/DD/YYYY")return`${m}/${d}/${x.y}`;if(opt.dateFormat==="YYYY-MM-DD")return`${x.y}-${m}-${d}`;if(opt.dateFormat==="DD-MON-YYYY")return`${d}-${SHORT[x.m]}-${x.y}`;return`${d}/${m}/${x.y}`}
 function vt(x){if(!x)return"";let H=x.h%12+(x.ap==="PM"?12:0);if(x.h===12)H=x.ap==="AM"?0:12;return opt.hourFormat==="24"?`${pad(H)}:${pad(x.min)}`:`${pad(x.h)}:${pad(x.min)} ${x.ap}`}
 function paint(){if(dateZone)dateZone.querySelector("strong").textContent=saved?vd(saved):(opt.placeholder||"");if(timeZone)timeZone.querySelector("strong").textContent=saved?vt(saved):(opt.placeholder||"");if(dateTab)dateTab.querySelector("strong").textContent=vd(draft);if(timeTab)timeTab.querySelector("strong").textContent=vt(draft)}
 function hap(){if(!opt.haptics||!("vibrate" in navigator))return;let t=performance.now();if(t-lastHaptic<45)return;lastHaptic=t;try{navigator.vibrate(10)}catch(e){}}
 function lim(mode,val){let t=new Date();t.setHours(0,0,0,0);if(mode==="TODAY")return t;if(mode==="FUTURE"){t.setDate(t.getDate()+1);return t}if(mode==="VALUE"&&val){let p=parse(String(val).length===10?val+" 00:00:00":val);if(p)return new Date(p.y,p.m,p.d)}return null}
 function allowed(y,m,d){let x=new Date(y,m,d),mn=lim(opt.minMode,opt.minValue),mx=lim(opt.maxMode,opt.maxValue);return(!mn||x>=mn)&&(!mx||x<=mx)}
 function commit(){saved={...draft};input.value=ora(saved,opt.mode);input.dispatchEvent(new Event("change",{bubbles:true}));paint();close()}
 function renderCalendar(){
  let vy=draft.y,vm=draft.m,gesture=null;
  const shiftMonth=(dir,viaGesture=false)=>{
   vm+=dir;if(vm<0){vm=11;vy--}else if(vm>11){vm=0;vy++}
   if(viaGesture)hap();
   draw(dir);
  };
  const bindSwipe=()=>{
   const days=content.querySelector(".adt-calendar-swipe");if(!days)return;
   if(window.matchMedia("(min-width: 768px)").matches){days.style.touchAction="auto";return;}
   const threshold=46,maxVertical=54;
   days.addEventListener("pointerdown",e=>{
    if(e.pointerType==="mouse"&&e.button!==0)return;
    gesture={id:e.pointerId,x:e.clientX,y:e.clientY,dx:0,dy:0,moved:false};
    try{days.setPointerCapture(e.pointerId)}catch(_){}
   });
   days.addEventListener("pointermove",e=>{
    if(!gesture||gesture.id!==e.pointerId)return;
    gesture.dx=e.clientX-gesture.x;gesture.dy=e.clientY-gesture.y;
    if(Math.abs(gesture.dx)>8&&Math.abs(gesture.dx)>Math.abs(gesture.dy)){gesture.moved=true;days.classList.add("dragging");e.preventDefault()}
   });
   const finish=e=>{
    if(!gesture||gesture.id!==e.pointerId)return;
    const g=gesture;gesture=null;days.classList.remove("dragging");
    try{days.releasePointerCapture(e.pointerId)}catch(_){}
    if(Math.abs(g.dx)>=threshold&&Math.abs(g.dx)>Math.abs(g.dy)&&Math.abs(g.dy)<=maxVertical){
      days.dataset.suppressClick="1";setTimeout(()=>delete days.dataset.suppressClick,120);
      shiftMonth(g.dx<0?1:-1,true);
    }
   };
   days.addEventListener("pointerup",finish);days.addEventListener("pointercancel",e=>{gesture=null;days.classList.remove("dragging")});
  };
  const draw=(dir=0)=>{
   content.innerHTML=`<div class="adt-calendar-frame ${dir>0?"adt-month-next":dir<0?"adt-month-prev":""}"><div class="adt-monthbar"><button type="button" class="prev" aria-label="Mes anterior"><i class="fa fa-chevron-left"></i></button><strong>${MONTHS[vm]} ${vy}</strong><button type="button" class="next" aria-label="Mes siguiente"><i class="fa fa-chevron-right"></i></button></div><div class="adt-calendar-swipe"><div class="adt-week"><span>Lu</span><span>Ma</span><span>Mi</span><span>Ju</span><span>Vi</span><span>Sá</span><span>Do</span></div><div class="adt-days"></div></div></div>`;
   let days=content.querySelector(".adt-days"),swipe=content.querySelector(".adt-calendar-swipe"),off=(new Date(Date.UTC(vy,vm,1)).getUTCDay()+6)%7,total=new Date(Date.UTC(vy,vm+1,0)).getUTCDate();
   for(let i=0;i<off;i++){let e=document.createElement("span");e.className="adt-empty";days.append(e)}
   for(let n=1;n<=total;n++){let b=document.createElement("button");b.type="button";b.className="adt-day"+(draft.y===vy&&draft.m===vm&&draft.d===n?" sel":"");b.textContent=n;b.disabled=!allowed(vy,vm,n);b.onclick=()=>{if(window.innerWidth<768&&swipe?.dataset.suppressClick)return;draft.y=vy;draft.m=vm;draft.d=n;paint();hap();if(isDateOnly){commit()}else{draw();if(isDateTime)setTimeout(()=>setTab("time"),180)}};days.append(b)}
   for(let i=off+total;i<42;i++){let e=document.createElement("span");e.className="adt-empty";days.append(e)}
   content.querySelector(".prev").onclick=()=>shiftMonth(-1,false);content.querySelector(".next").onclick=()=>shiftMonth(1,false);
   bindSwipe();
  };draw();
 }
 function wheel(el,values,current,cb,circular=true){
   const row=58;
   el.innerHTML="";
   const base=values.slice();
   const repeat=7;
   const all=[];
   for(let r=0;r<repeat;r++)for(const v of base)all.push(v);
   all.forEach((v,i)=>{
     const o=document.createElement("div");
     o.className="adt-wheel-option";
     o.textContent=String(v).padStart(2,"0");
     o.dataset.value=v;
     o.dataset.index=i;
     o.setAttribute("role","option");
     el.append(o);
   });
   const mid=Math.floor(repeat/2);
   let baseIndex=Math.max(0,base.findIndex(v=>String(v)===String(current)));
   let selected=mid*base.length+baseIndex;
   let settling=false, timer=0, lastCommitted=String(current);
   const center=(idx,behavior="auto")=>{
     el.scrollTo({top:idx*row,behavior});
   };
   const nearest=()=>Math.max(0,Math.min(all.length-1,Math.round(el.scrollTop/row)));
   const paint=idx=>{
     [...el.children].forEach((n,i)=>{
       const on=i===idx;n.classList.toggle("selected",on);n.setAttribute("aria-selected",on?"true":"false");
     });
   };
   const commit=()=>{
     let idx=nearest(), value=String(all[idx]);
     selected=idx;paint(idx);
     center(idx,"auto");
     if(value!==lastCommitted){lastCommitted=value;cb(all[idx]);hap();}
     // silent recenter into the middle copy, preserving the exact value
     const bi=base.findIndex(v=>String(v)===value);
     if(bi>=0){
       const safe=mid*base.length+bi;
       if(Math.abs(idx-safe)>base.length){
         selected=safe;
         requestAnimationFrame(()=>{center(safe,"auto");paint(safe)});
       }
     }
   };
   el.onscroll=()=>{
     clearTimeout(timer);
     timer=setTimeout(commit,110);
   };
   el.onwheel=e=>{
     e.preventDefault();
     clearTimeout(timer);
     const dir=e.deltaY===0?0:(e.deltaY>0?1:-1);
     if(!dir)return;
     selected=Math.max(0,Math.min(all.length-1,nearest()+dir));
     center(selected,"smooth");paint(selected);
     timer=setTimeout(commit,130);
   };
   el.onclick=e=>{
     const o=e.target.closest(".adt-wheel-option");if(!o)return;
     selected=Number(o.dataset.index);paint(selected);center(selected,"smooth");
     clearTimeout(timer);timer=setTimeout(commit,150);
   };
   requestAnimationFrame(()=>{center(selected,"auto");paint(selected)});
 }
 function renderPeriod(){
  let el=content.querySelector(".adt-period");el.innerHTML=`<div class="adt-period-track"><button type="button" class="adt-period-choice" data-p="AM">AM</button><button type="button" class="adt-period-choice" data-p="PM">PM</button></div>`;
  let track=el.firstChild;
  const sync=(instant=false)=>{track.classList.toggle("is-pm",draft.ap==="PM");track.classList.toggle("instant",instant);el.querySelectorAll("button").forEach(b=>b.classList.toggle("selected",b.dataset.p===draft.ap));if(instant)requestAnimationFrame(()=>track.classList.remove("instant"))};
  el.querySelectorAll("button").forEach(b=>b.onclick=()=>{if(b.dataset.p!==draft.ap){draft.ap=b.dataset.p;sync();hap();paintHeader()}});
  let pid=null,sy=0;el.onpointerdown=e=>{pid=e.pointerId;sy=e.clientY;el.setPointerCapture?.(pid)};el.onpointerup=e=>{if(e.pointerId!==pid)return;let dy=e.clientY-sy,p=dy<0?"PM":"AM";pid=null;if(Math.abs(dy)>=24&&p!==draft.ap){draft.ap=p;sync();hap();paintHeader()}};el.onpointercancel=()=>pid=null;sync(true);
 }
 function paintHeader(){if(dateTab)dateTab.querySelector("strong").textContent=vd(draft);if(timeTab)timeTab.querySelector("strong").textContent=vt(draft)}
 function renderTime(){
  content.innerHTML=`<div class="adt-wheel-card"><div class="adt-wheel-labels"><span>Hora</span><span>Minutos</span><span>Período</span></div><div class="adt-wheel-wrap"><div class="adt-selector"></div><div class="adt-wheel adt-hours" role="listbox"></div><div class="adt-wheel adt-minutes" role="listbox"></div><div class="adt-period" role="radiogroup"></div></div></div>`;
  let card=content.querySelector(".adt-wheel-card"),H=draft.h%12+(draft.ap==="PM"?12:0);if(draft.h===12)H=draft.ap==="AM"?0:12;
  if(opt.hourFormat==="24"){card.classList.add("mode-24");wheel(content.querySelector(".adt-hours"),Array.from({length:24},(_,i)=>i),H,v=>{draft.ap=v>=12?"PM":"AM";draft.h=(v%12)||12})}
  else wheel(content.querySelector(".adt-hours"),Array.from({length:12},(_,i)=>i+1),draft.h,(v,meta)=>{if(meta&&meta.crossings&&Math.abs(meta.crossings)%2===1){draft.ap=draft.ap==="AM"?"PM":"AM";renderPeriod();hap()}draft.h=v});
  let mins=[];for(let i=0;i<60;i+=Math.max(1,+opt.minuteStep||5))mins.push(i);let nearest=mins.reduce((a,b)=>Math.abs(b-draft.min)<Math.abs(a-draft.min)?b:a,mins[0]);draft.min=nearest;wheel(content.querySelector(".adt-minutes"),mins,nearest,v=>draft.min=v);
  if(opt.hourFormat==="12")renderPeriod();
 }
 function setTab(t){
   const fromTime=host.classList.contains("adt-tab-time");
   const toTime=t==="time";
   if(fromTime!==toTime){
     host.classList.remove("adt-slide-to-date","adt-slide-to-time");
     void host.offsetWidth;
     host.classList.add(toTime?"adt-slide-to-time":"adt-slide-to-date");
     clearTimeout(host._adtSlideTimer);
     host._adtSlideTimer=setTimeout(()=>host.classList.remove("adt-slide-to-date","adt-slide-to-time"),220);
   }
   host.classList.toggle("adt-tab-time",toTime);
   host.classList.toggle("adt-tab-date",!toTime);
if(isDateOnly)t="date";if(isTimeOnly)t="time";let prev=active;active=t;if(dateTab){dateTab.classList.toggle("active",t==="date");dateTab.setAttribute("aria-selected",t==="date")
 }if(timeTab){timeTab.classList.toggle("active",t==="time");timeTab.setAttribute("aria-selected",t==="time")}content.classList.remove("slide-from-left","slide-from-right");void content.offsetWidth;if(prev!==t&&isDateTime)content.classList.add(t==="time"?"slide-from-right":"slide-from-left");t==="date"?renderCalendar():renderTime();paintHeader()}
 const useSheet=isSheet&&window.innerWidth<768;
 function effectiveSheet(){return useSheet}
 function restoreHome(){if(homeMarker&&homeMarker.parentNode&&host.parentNode!==homeMarker.parentNode)homeMarker.parentNode.insertBefore(host,homeMarker.nextSibling)}
 function place(){
  if(effectiveSheet()){if(host.parentNode!==overlay)overlay.appendChild(host);panel.classList.remove("position-top");panel.classList.add("position-bottom");return}
  restoreHome();
  let p=String(opt.position||"AUTO").toUpperCase();
  if(isSheet&&!useSheet)p="BOTTOM";
  else if(p==="AUTO"){let r=host.querySelector(".adt-field").getBoundingClientRect(),vh=window.visualViewport?visualViewport.height:innerHeight,above=r.top,below=vh-r.bottom;p=(below>=430||below>=above)?"BOTTOM":"TOP"}
  if(p==="TOP"){host.insertBefore(panel,host.firstChild);panel.classList.add("position-top");panel.classList.remove("position-bottom")}
  else{host.appendChild(panel);panel.classList.add("position-bottom");panel.classList.remove("position-top")}
 }
 function ensure(){if(effectiveSheet()||!opt.autoScroll)return;requestAnimationFrame(()=>requestAnimationFrame(()=>{let vh=window.visualViewport?visualViewport.height:innerHeight,r=panel.getBoundingClientRect();if(r.top<8||r.bottom>vh-8)panel.scrollIntoView({behavior:"smooth",block:"nearest",inline:"nearest"})}))}
 function open(t){draft=saved?{...saved}:now();paint();panel.classList.remove("closing");place();if(effectiveSheet()){overlay.classList.add("open");overlay.setAttribute("aria-hidden","false");document.documentElement.classList.add("adt-sheet-lock")}panel.classList.add("open");setTab(t);ensure()}
 function close(){if(!panel.classList.contains("open"))return;let finish=()=>{clearTimeout(closeTimer);panel.classList.remove("closing","open");if(isSheet){overlay.classList.remove("open");overlay.setAttribute("aria-hidden","true");document.documentElement.classList.remove("adt-sheet-lock");restoreHome()}};if(matchMedia?.("(prefers-reduced-motion: reduce)").matches){finish();return}panel.classList.add("closing");closeTimer=setTimeout(finish,230)}
 if(dateZone)dateZone.onclick=()=>open("date");if(timeZone)timeZone.onclick=()=>open("time");if(dateTab)dateTab.onclick=()=>setTab("date");if(timeTab)timeTab.onclick=()=>setTab("time");
 host.querySelector(".adt-primary").onclick=commit;host.querySelector(".adt-secondary").onclick=close;let clear=host.querySelector(".adt-clear");if(clear)clear.onclick=()=>{saved=null;input.value="";input.dispatchEvent(new Event("change",{bubbles:true}));paint();close()};
 if(overlay)overlay.addEventListener("click",e=>{if(e.target===overlay)close()});
 document.addEventListener("keydown",e=>{if(e.key==="Escape"&&panel.classList.contains("open"))close()});
 apex.item.create(id,{getValue:()=>input.value,setValue:v=>{input.value=v||"";saved=parse(v);draft=saved?{...saved}:now();paint()},setFocus:()=>{(dateZone||timeZone)?.focus()},disable:()=>{input.disabled=true;host.setAttribute("aria-disabled","true");if(dateZone)dateZone.disabled=true;if(timeZone)timeZone.disabled=true},enable:()=>{input.disabled=false;host.removeAttribute("aria-disabled");if(dateZone)dateZone.disabled=false;if(timeZone)timeZone.disabled=false},isDisabled:()=>!!input.disabled,isEmpty:()=>!input.value,displayValueFor:v=>{let x=parse(v);return x?(isDateOnly?vd(x):isTimeOnly?vt(x):vd(x)+" · "+vt(x)):""}});
 paint();
}
window.ApexDateTimeSDK.init=init;
})(apex,apex.jQuery)
