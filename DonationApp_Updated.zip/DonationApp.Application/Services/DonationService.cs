using DonationApp.Application.Interfaces;
using DonationApp.Domain.Entities;

namespace DonationApp.Application.Services;

public class DonationService : IDonationService
{
    public async Task<bool> ProcessDonation(Donation donation)
    {
        // Aquí se implementaría la lógica real de procesamiento de pago
        await Task.Delay(500);
        return true;
    }
}