using DonationApp.Domain.Entities;

namespace DonationApp.Application.Interfaces;

public interface IAuthService
{
    Task<string> Register(User user, string password);
    Task<string> Login(string email, string password);
}