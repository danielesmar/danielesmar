using System.Threading.Tasks;

namespace DonationApp.Application.Interfaces;

public interface IUserRoleService
{
    Task AssignRole(string userId, string role);
}