using DonationApp.Domain.Entities;

namespace DonationApp.Application.Interfaces;

public interface IDonationService
{
    Task<bool> ProcessDonation(Donation donation, string cvv);
}