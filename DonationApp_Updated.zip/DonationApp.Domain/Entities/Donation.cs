namespace DonationApp.Domain.Entities;

public class Donation
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Company { get; set; }
    public decimal Amount { get; set; }
    public string Project { get; set; }
    public string Periodicity { get; set; }
    public string CardNumber { get; set; } // Solo se almacenará cifrado
    public string ExpiryDate { get; set; }
    public string CVV { get; set; } // No se almacenará por seguridad
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}