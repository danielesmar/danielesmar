namespace DonationApp.Domain.Entities;

public static class UserRoles
{
    public const string Admin = "Admin";
    public const string Donor = "Donor";
}