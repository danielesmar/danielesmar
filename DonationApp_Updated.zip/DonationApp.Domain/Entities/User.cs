using Microsoft.AspNetCore.Identity;

namespace DonationApp.Domain.Entities;

public class User : IdentityUser
{
    public string FullName { get; set; }
}