using DonationApp.Application.Interfaces;
using DonationApp.Domain.Entities;
using Stripe;
using Stripe.Checkout;

namespace DonationApp.Infrastructure.Payments;

public class StripePaymentService : IDonationService
{
    private readonly string _stripeSecretKey = "sk_test_xxxxxxxxxxxxxxxxxxx"; // Reemplazar con clave real

    public async Task<bool> ProcessDonation(Donation donation, string cvv)
    {
        StripeConfiguration.ApiKey = _stripeSecretKey;

        var options = new PaymentIntentCreateOptions
        {
            Amount = (long)(donation.Amount * 100),
            Currency = "usd",
            PaymentMethodTypes = new List<string> { "card" },
            PaymentMethodData = new PaymentIntentPaymentMethodDataOptions
            {
                Card = new PaymentIntentPaymentMethodDataCardOptions
                {
                    Number = donation.CardNumber,
                    ExpMonth = int.Parse(donation.ExpiryDate.Split('/')[0]),
                    ExpYear = int.Parse(donation.ExpiryDate.Split('/')[1]),
                    Cvc = cvv
                }
            },
            Confirm = true
        };

        var service = new PaymentIntentService();
        var intent = await service.CreateAsync(options);

        return intent.Status == "succeeded";
    }
}