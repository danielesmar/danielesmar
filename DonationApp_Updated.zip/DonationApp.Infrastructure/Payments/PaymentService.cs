using DonationApp.Application.Interfaces;
using DonationApp.Domain.Entities;

namespace DonationApp.Infrastructure.Payments;

public class PaymentService : IDonationService
{
    public async Task<bool> ProcessDonation(Donation donation)
    {
        // Simulación de procesamiento de pago
        await Task.Delay(1000);
        return true; // Simulación de pago exitoso
    }
}