using DonationApp.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace DonationApp.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Donation> Donations { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Donation>().HasKey(d => d.Id);
    }
}