-- Ejemplo de Source SQL de la región.
-- IMPORTANTE: ajuste CSC_ACTIVIDAD_IMAGEN si el nombre real de la PK es distinto.
select i.CSC_ACTIVIDAD_IMAGEN as ID_IMAGEN,
       i.IMAGEN               as IMAGEN_BLOB,
       i.TIPO_MIME            as MIME_TYPE,
       i.NOMBRE_ARCHIVO       as NOMBRE_ARCHIVO
  from pv_actividades_imagenes_tmp i
 where i.CSC_TIPO_ACTIVIDAD = PV.PV_INTC_CONFIGURACIONES.ObtenerIdPorCodigoCatalogo(
           pCatalogo => 'TIPO_ACTIVIDAD',
           pCodigo   => :PXX_TIPO_ACTIVIDAD
       )
   and i.COD_APLICACION = v('APP_ID')
   and i.USR_TCG = v('APP_USER_TCG')
 order by i.FECHA_INGRESO desc;