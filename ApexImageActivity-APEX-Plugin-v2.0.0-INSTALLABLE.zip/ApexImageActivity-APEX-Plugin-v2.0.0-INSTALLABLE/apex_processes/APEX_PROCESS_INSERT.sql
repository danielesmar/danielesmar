-- APEX Ajax Callback Process - INSERT
-- Configure el nombre de este proceso en el atributo "Proceso APEX INSERT" del plug-in.
declare
    PARAM_TIPO_ACTIVIDAD varchar2(4000) := apex_application.g_x02;
    l_clob               clob;
    l_blob               blob;
    l_csc_tipo_actividad number;
    l_tamano_real        number;
    l_max_imagenes       number := nvl(to_number(apex_application.g_x06),5);
    l_total              number;
begin
    if PARAM_TIPO_ACTIVIDAD is null then
        raise_application_error(-20001,'Debe seleccionar el tipo de actividad.');
    end if;
    if apex_application.g_f01.count = 0 then
        raise_application_error(-20002,'No se recibió contenido de imagen.');
    end if;
    if lower(apex_application.g_x04) not in ('image/jpeg','image/png') then
        raise_application_error(-20003,'Tipo de imagen no permitido.');
    end if;

    l_csc_tipo_actividad := PV.PV_INTC_CONFIGURACIONES.ObtenerIdPorCodigoCatalogo(
        pCatalogo => 'TIPO_ACTIVIDAD',
        pCodigo   => PARAM_TIPO_ACTIVIDAD
    );

    select count(*) into l_total
      from pv_actividades_imagenes_tmp
     where CSC_TIPO_ACTIVIDAD = l_csc_tipo_actividad
       and COD_APLICACION = v('APP_ID')
       and USR_TCG = v('APP_USER_TCG');
    if l_total >= l_max_imagenes then
        raise_application_error(-20004,'Se alcanzó el límite de imágenes permitido.');
    end if;

    dbms_lob.createtemporary(l_clob,true);
    for i in 1 .. apex_application.g_f01.count loop
        dbms_lob.writeappend(l_clob,length(apex_application.g_f01(i)),apex_application.g_f01(i));
    end loop;
    l_blob := apex_web_service.clobbase642blob(l_clob);
    l_tamano_real := dbms_lob.getlength(l_blob);

    insert into pv_actividades_imagenes_tmp (
        CSC_TIPO_ACTIVIDAD,
        NOMBRE_ARCHIVO,
        TIPO_MIME,
        TAMANO_ARCHIVO,
        IMAGEN,
        COD_APLICACION,
        USR_TCG,
        FECHA_INGRESO,
        USR_INGRESO
    ) values (
        l_csc_tipo_actividad,
        apex_application.g_x03,
        lower(apex_application.g_x04),
        l_tamano_real,
        l_blob,
        v('APP_ID'),
        v('APP_USER_TCG'),
        sysdate,
        v('APP_USER')
    );

    apex_json.open_object;
    apex_json.write('success',true);
    apex_json.close_object;

    if dbms_lob.istemporary(l_clob)=1 then dbms_lob.freetemporary(l_clob); end if;
exception
    when others then
        if dbms_lob.istemporary(l_clob)=1 then dbms_lob.freetemporary(l_clob); end if;
        apex_debug.error('ApexImageActivity v2 INSERT: %s',sqlerrm);
        apex_json.open_object;
        apex_json.write('success',false);
        apex_json.write('message',sqlerrm);
        apex_json.close_object;
end;