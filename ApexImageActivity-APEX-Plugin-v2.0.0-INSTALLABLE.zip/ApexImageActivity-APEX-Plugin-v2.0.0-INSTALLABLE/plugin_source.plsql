function safe_col(p_value varchar2) return varchar2 is
begin return dbms_assert.simple_sql_name(trim(p_value)); end;
function f_render(p_region in apex_plugin.t_region,p_plugin in apex_plugin.t_plugin,p_is_printer_friendly in boolean) return apex_plugin.t_region_render_result is
 l_result apex_plugin.t_region_render_result; l_host varchar2(255):=nvl(p_region.static_id,'apxiact_'||p_region.id)||'_sdk'; l_ajax varchar2(4000):=apex_plugin.get_ajax_identifier; l_code varchar2(32767);
begin
 htp.p('<div id="'||apex_escape.html_attribute(l_host)||'" class="apxiact-plugin-root"></div>');
 l_code:='ApexImageActivityPlugin.init({'||
  'regionId:'||apex_javascript.add_value(l_host,false)||','||'ajaxIdentifier:'||apex_javascript.add_value(l_ajax,false)||','||
  'functionTypeItem:'||apex_javascript.add_value(p_region.attribute_05,false)||','||
  'maxImages:'||to_char(nvl(to_number(p_region.attribute_06),5))||','||
  'insertProcess:'||apex_javascript.add_value(p_region.attribute_07,false)||','||
  'deleteProcess:'||apex_javascript.add_value(p_region.attribute_08,false)||','||
  'targetKB:'||to_char(nvl(to_number(p_region.attribute_09),150))||','||
  'workerUrl:'||apex_javascript.add_value(p_plugin.file_prefix||'apex-image-worker.js',false)||',primaryColor:"#00683B",secondaryColor:"#69BE38"}).catch(function(e){console.error("ApexImageActivity",e);});';
 apex_javascript.add_onload_code(p_code=>l_code,p_key=>'apxiact_'||p_region.id); return l_result;
end;
function f_ajax(p_region in apex_plugin.t_region,p_plugin in apex_plugin.t_plugin) return apex_plugin.t_region_ajax_result is
 l_result apex_plugin.t_region_ajax_result; l_action varchar2(20):=upper(nvl(apex_application.g_x10,'LIST')); l_idc varchar2(261):=safe_col(p_region.attribute_01); l_blobc varchar2(261):=safe_col(p_region.attribute_02); l_mimec varchar2(261):=safe_col(p_region.attribute_03); l_filec varchar2(261):=safe_col(p_region.attribute_04); l_type varchar2(4000):=apex_util.get_session_state(p_region.attribute_05); l_max number:=nvl(to_number(p_region.attribute_06),5); l_sql varchar2(32767); l_data apex_plugin_util.t_column_value_list2; l_rows pls_integer:=0; l_blob blob;
 function val(c pls_integer,r pls_integer) return varchar2 is begin return apex_plugin_util.get_value_as_varchar2(l_data(c).data_type,l_data(c).value_list(r)); end;
begin
 if p_region.source is null then raise_application_error(-20001,'Debe definir la Consulta SQL de la región.'); end if;
 if l_action='LIST' and l_type is null then
  apex_json.open_object; apex_json.write('success',true); apex_json.write('contextReady',false); apex_json.write('maxImages',l_max); apex_json.open_array('images'); apex_json.close_array; apex_json.close_object; return l_result;
 end if;
 if l_type is null then raise_application_error(-20002,'Debe seleccionar el tipo de actividad.'); end if;
 if l_action='LIST' then
  l_sql:='select to_char(q.'||l_idc||') sdk_id,to_char(q.'||l_mimec||') sdk_mime,to_char(q.'||l_filec||') sdk_file from ('||p_region.source||') q';
  l_data:=apex_plugin_util.get_data2(p_sql_statement=>l_sql,p_min_columns=>3,p_max_columns=>3,p_component_name=>p_region.name,p_auto_bind_items=>true); if l_data.count>0 then l_rows:=l_data(1).value_list.count; end if;
  apex_json.open_object; apex_json.write('success',true); apex_json.write('contextReady',true); apex_json.write('maxImages',l_max); apex_json.open_array('images'); for r in 1..l_rows loop apex_json.open_object;apex_json.write('id',val(1,r));apex_json.write('mimeType',val(2,r));apex_json.write('fileName',val(3,r));apex_json.close_object;end loop;apex_json.close_array;apex_json.close_object;
 elsif l_action='GET' then
  l_sql:='select to_char(q.'||l_idc||') sdk_id,q.'||l_blobc||' sdk_blob,to_char(q.'||l_mimec||') sdk_mime,to_char(q.'||l_filec||') sdk_file from ('||p_region.source||') q';
  l_data:=apex_plugin_util.get_data2(p_sql_statement=>l_sql,p_min_columns=>4,p_max_columns=>4,p_component_name=>p_region.name,p_search_type=>apex_plugin_util.c_search_exact_case,p_search_column_name=>'SDK_ID',p_search_string=>apex_application.g_x01,p_auto_bind_items=>true); if l_data.count=0 or l_data(1).value_list.count=0 then raise no_data_found; end if; l_blob:=l_data(2).value_list(1).blob_value; if l_blob is null then raise no_data_found; end if; apex_json.open_object;apex_json.write('success',true);apex_json.write('mimeType',nvl(val(3,1),'image/jpeg'));apex_json.write('fileName',nvl(val(4,1),'imagen'));apex_json.write('base64',apex_web_service.blob2clobbase64(l_blob));apex_json.close_object;
 else raise_application_error(-20020,'Acción no soportada: '||l_action); end if; return l_result;
exception when no_data_found then apex_json.open_object;apex_json.write('success',false);apex_json.write('message','Imagen no encontrada.');apex_json.close_object;return l_result; when others then apex_debug.error('ApexImageActivity v2: %s',sqlerrm);apex_json.open_object;apex_json.write('success',false);apex_json.write('message',sqlerrm);apex_json.close_object;return l_result;
end;