# ApexProductCardsCarousel v1.0.2 — APEX 24.2.8

## Corrección v1.0.2
Corrige ORA-06502 durante la instalación en el bloque:
`wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;`

La causa era el empaquetado de los archivos estáticos CSS/JS dentro del export:
el contenido hexadecimal completo se había colocado en una única entrada
`g_varchar2_table(1)`, excediendo el buffer VARCHAR2 usado por el importador.

Ahora CSS y JavaScript se dividen en fragmentos de 2000 caracteres hexadecimales
antes de llamar a `wwv_flow_imp.varchar2_to_blob`.

También conserva la corrección v1.0.1 de los atributos estándar.

## Instalar
Importar:
`region_type_plugin_com_banpro_product_cards_carousel.sql`

como Plug-in en Oracle APEX 24.2.8.

El botón conserva:
- class="entregarTarjeta"
- data-num-solicitud
- data-estado-solicitud
- data-csc-cita
- data-cod-cliente
