# ApexProductCardsCarousel v2.0.12 — Oracle APEX 24.2.8

## Cambios de esta versión

- Gesto móvil con **bloqueo direccional**:
  - Si el movimiento dominante es vertical, APEX/la página conserva su scroll normal.
  - Si el movimiento dominante es horizontal, el carrusel captura el gesto y evita el desplazamiento vertical de ese gesto.
  - Se usa una zona muerta de 8 px para no decidir la dirección por micro-movimientos del dedo.
- En móvil, con 2 o más registros:
  - card activo = `100vw - 64px`;
  - gap real entre cards = `16px`;
  - quedan 32 px libres a cada lado del card activo;
  - después del gap se ven **16 px del card vecino**, de modo que el usuario sabe que hay más contenido.
- Con un solo registro se mantiene el modo single: ancho disponible completo con 16 px de margen, sin dots ni peek lateral.
- Imagen física de tarjeta: **274 × 176 px**, centrada, `object-fit: contain`, sin borde/radio añadido por el plug-in.
- Nombre del cliente más grande y con sombra.
- Número/últimos dígitos más grandes y con sombra.
- Indicador activo del carrusel en verde primario `#00683B`.
- Botón outline primario sin background; icono en flujo flex para que nunca se monte sobre el texto.
- Contenido vertical más compacto.

## Configuración JSON completa equivalente al diseño actual

```json
{
  "titleColumn": "DESCRIPCION_PRODUCTO",
  "imageColumn": "DIR_URL_IMAGEN_FONDO_TJT",
  "panColumn": "NUMERO_DE_TARJETA_MASCARA",
  "holderColumn": "NOMBRE_PLASTICO_TJT",
  "sections": [
    {
      "class": "datos-producto",
      "fields": [
        {"label":"Número solicitud","column":"ID_SOLICITUD"},
        {"label":"Evento","column":"EVENTO_DE_TARJETA"},
        {"label":"Tipo producto","column":"CATEG_TARJETA_DESC"},
        {"label":"Tipo tarjeta","column":"TIPO_TARJETA_SOLICITADA"},
        {"label":"Cuenta crédito","column":"NUM_CTA_CREDITO"},
        {
          "label":"Estado entrega",
          "column":"DES_ESTADO_VISITA_SOLICITUD",
          "type":"status",
          "colorColumn":"COLOR"
        }
      ]
    }
  ],
  "button": {
    "permissionColumn": "TIENE_PERMISO_ENTREGAR_TARJETA",
    "textColumn": "TEXTO_BOTON",
    "iconColumn": "ICONO_BOTON",
    "requestColumn": "ID_SOLICITUD",
    "stateColumn": "IND_ESTADO_VISITA_SOLICITUD"
  }
}
```

## Columnas del SELECT consideradas por la configuración anterior

- `DESCRIPCION_PRODUCTO`: título del producto.
- `DIR_URL_IMAGEN_FONDO_TJT`: URL de la imagen física.
- `NUMERO_DE_TARJETA_MASCARA`: número enmascarado/últimos dígitos.
- `NOMBRE_PLASTICO_TJT`: nombre mostrado sobre la tarjeta.
- `ID_SOLICITUD`: número de solicitud y `data-num-solicitud`.
- `EVENTO_DE_TARJETA`: evento.
- `CATEG_TARJETA_DESC`: tipo de producto.
- `TIPO_TARJETA_SOLICITADA`: tipo de tarjeta.
- `NUM_CTA_CREDITO`: cuenta.
- `DES_ESTADO_VISITA_SOLICITUD`: texto del estado.
- `COLOR`: color semántico del estado.
- `TIENE_PERMISO_ENTREGAR_TARJETA`: controla si se genera el botón.
- `TEXTO_BOTON`: texto del botón.
- `ICONO_BOTON`: clase Font Awesome del botón.
- `IND_ESTADO_VISITA_SOLICITUD`: `data-estado-solicitud`.

Los valores `data-csc-cita` y `data-cod-cliente` continúan viniendo de los items configurables del plug-in, por defecto `P9_CSC_CITA` y `P9_COD_CLIENTE`.

## Campos dinámicos adicionales

Cada entrada de `sections[].fields[]` admite:

```json
{
  "label": "Prioridad",
  "column": "PRIORIDAD",
  "type": "status",
  "colorColumn": "COLOR_PRIORIDAD",
  "classColumn": "CLASE_PRIORIDAD",
  "span": "2",
  "template": "<strong style=\"color:#COLOR#\">#VALUE#</strong>"
}
```

Marcadores disponibles en `template`:
`#VALUE#`, `#LABEL#`, `#COLOR#`, `#CLASS#`.

## Contrato del botón

Se conserva:

```html
<a class="apxpc-action entregarTarjeta"
   data-num-solicitud="..."
   data-estado-solicitud="..."
   data-csc-cita="..."
   data-cod-cliente="...">
</a>
```

Por tanto, el evento JavaScript existente asociado a `.entregarTarjeta` no necesita cambiar.

## Ajustes v2.0.12
- Arrastre horizontal 1:1 con el dedo: el track acompaña continuamente el `touchmove`.
- Zoom in/out continuo de los cards según su proximidad al centro, no solamente al soltar.
- Snap suave al card destino al finalizar el gesto.
- Mayor peek lateral: card móvil `100vw - 96px`; con gap 16px quedan ~32px visibles del vecino.
- El gesto vertical sigue siendo nativo de la página.
- Botón outline primario de 48px de alto.
- Todos los cards usan borde neutro `#dde3de`, incluso el activo.
- Sombra uniforme `0 2px 8px rgba(0,0,0,.05)`.

## Ajustes v2.0.12
- Se redujo a la mitad el espacio lateral móvil respecto a v2.0.2.
- En móvil el card usa `100vw - 48px`, manteniendo `gap:16px`.
- La imagen física deja de estar limitada a 274 px en móvil y se adapta al 100% del ancho útil del card conservando `aspect-ratio:274/176` y `object-fit:contain`.
- Nombre del cliente y número de tarjeta reducidos.
- Snap/transición horizontal aumentado a 380 ms con curva más suave.
- Escritorio: todos los cards son de 390 px, exactamente iguales, sin zoom, opacidad ni efecto de foco.
- Escritorio conserva únicamente desplazamiento horizontal cuando la suma de cards excede el ancho disponible.

## Ajustes v2.0.12
- En móvil el carrusel sale del padding/contenedor de la región APEX y usa `100vw` real.
- Se eliminan los márgenes laterales impuestos por la región para que el desplazamiento se sienta de borde a borde.
- Card móvil activo: 78vw.
- Gap móvil: 12px.
- Esto deja visible una porción clara del card anterior/siguiente incluso sin mantener el dedo presionado.
- El track usa `align-items:stretch` y los cards `height:100%` para conservar alturas visuales iguales.
- La imagen ocupa el 100% del ancho interno del card y conserva `aspect-ratio:274/176`.
- El cálculo JavaScript del zoom/transición ahora lee el gap real desde CSS.
- Snap final suavizado a 420ms.

## Ajustes v2.0.12
- Posicionamiento edge-aware en móvil.
- Primer card activo: 8px desde el borde izquierdo, sin espacio reservado para un card inexistente.
- Cards intermedios: centrados, mostrando vecinos izquierdo y derecho.
- Último card activo: 8px desde el borde derecho, sin espacio vacío posterior.
- Cards laterales exactamente 15% menores (`scale(.85)`); card enfocado `scale(1)`.
- Label: `rgba(63,63,63,1)` = `#3F3F3F`, bold.
- Value/column: `rgba(93,93,93,1)` = `#5D5D5D`, regular.
- Descripción del producto: `#3F3F3F`, 16px, weight 700.
- Icono de producto: Font Awesome credit-card (`fa fa-credit-card`, unicode f09d).

## Ajustes v2.0.12
- Modo de un solo producto corregido: 8px exactos a izquierda y derecha en móvil, sin desbordamiento horizontal.
- El card usa `border-radius: 8px`.
- Se eliminan las divisiones verticales de la sección de detalles.
- Se conservan separadores horizontales muy sutiles para mantener lectura por filas.
- Columna izquierda alineada a la izquierda.
- Columna derecha (label y value) alineada a la derecha.
- El estado de entrega sigue la alineación derecha cuando pertenece a esa columna.
- El comportamiento del carrusel para 2 o más productos se conserva sin cambios.

## Ajustes v2.0.12
- Primer/último card del carrusel: 16px respecto al borde cuando no existe otro elemento en ese lado.
- Un solo producto: 16px exactos a izquierda y derecha.
- Eliminadas también las líneas horizontales de la sección de detalles.
- Cada field incorpora `padding-top: 8px`.
- Valores operativos aumentados a `13px`.
- PAN enmascarado desplazado ligeramente hacia abajo y con mayor `letter-spacing`.
- `title-icon` y `product-icon` fuerzan el glifo Font Awesome `fa-credit-card` (`f09d`).

## Ajustes v2.0.12
- Eliminado el icono CSS anterior que se superponía al `fa-credit-card`.
- Valores de fields a 14px.
- Botón del card aumentado a 56px de alto y texto a 14px.
- Cards fuera de foco ahora se renderizan realmente al 85% en ancho y altura aparente.
- Se corrigió la transición continua durante el gesto para que el zoom 85% ↔ 100% funcione aun con reglas legacy `!important`.
- Imagen física con `border-radius: 12px`, fondo blanco igual al card y recorte limpio de esquinas.
- PAN enmascarado con mayor `letter-spacing` (1.8px).

## Ajustes v2.0.12
- Padding interno del card aumentado a 16px.
- Separación entre cards fijada exactamente en 12px.
- Se conserva sin cambios la animación/zoom de foco introducida en v2.0.8.
- No se aumenta el padding externo del carrusel.

## Ajustes v2.0.12
- Separación estructural entre slides fijada en 12px.
- El escalado visual se aplica al card interior y no al contenedor del slide, evitando que `scale(.85)` genere un hueco visual enorme entre productos.
- Se conserva el foco 100% / laterales 85%.
- `apxpc-dots` aumenta su separación superior de 6px a 12px y añade margen superior de 12px.

## Ajustes v2.0.12
- Corregido el espacio visual real entre el card enfocado y el lateral.
- Se compensa matemáticamente el espacio invisible generado por `scale(.85)`.
- Separación visible final: 12px, no 12px + el espacio producido por el escalado.
- No se modifica la animación de zoom/foco de v2.0.8-v2.0.10.
- El siguiente card vuelve a quedar visible sin necesidad de iniciar el swipe.
- Dots mantienen 12px de separación superior.

## Ajustes v2.0.12
- Corregida la dirección matemática del zoom durante el drag.
- Al arrastrar hacia la izquierda, el card actual disminuye progresivamente de 100% a 85% y el siguiente crece simultáneamente de 85% a 100%.
- Al arrastrar hacia la derecha ocurre exactamente el proceso inverso.
- Eliminado el doble escalado introducido por reglas anteriores: ahora solo se escala el slide, no también el card interior.
- Al soltar el dedo ya no se limpia el zoom de golpe; posición, escala y opacidad completan juntos la transición de 420 ms.
- Se mantiene la compensación para 12px de separación visual y los 12px de los dots.
