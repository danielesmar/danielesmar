# PROMPT MAESTRO DE TRANSFERENCIA — ApexImageSDK v5.0.0

Estoy continuando dentro del mismo proyecto el desarrollo de una VARIANTE del Oracle APEX Region Plug-in **ApexImageSDK v5.0.0**. Adjunto el ZIP de v5.0.0. **El ZIP es la fuente de verdad del código. Antes de modificarlo, inspecciónalo completo.** Esta variante debe conservar las capacidades y UX del SDK, pero tendrá un origen/modelo de datos diferente. No reescribas el SDK desde cero ni elimines comportamientos existentes salvo que yo lo pida.

## 1. Plataforma y arquitectura
- Oracle APEX 24.2.8, Region Plug-in reutilizable, PWA/mobile-first y compatible desktop/tablet/híbrido.
- Archivos estáticos embebidos en el plug-in y cargados automáticamente.
- SDK/editor JavaScript separado de la capa de integración APEX.
- AJAX interno LIST / GET / SAVE.
- Configuración declarativa mediante SQL Query + mappings lógicos, evitando acoplar el plugin a nombres físicos de tabla.
- Persistencia corporativa exclusivamente mediante paquete/procedimiento PL/SQL. No hacer UPDATE/INSERT directo desde el plug-in/APEX.
- Seguridad/autorización/editabilidad se revalida en servidor. Flags del frontend son solo UX.
- No hacer COMMIT dentro del paquete de referencia salvo que la arquitectura de la aplicación lo exija explícitamente.

## 2. Modelo lógico del plug-in base
Atributos conocidos:
01 Request Item
02 Tipo componente CARGA/CORRECCION
03 ID imagen
04 ID solicitud
05 descripción/título
06 BLOB
07 MIME
08 nombre archivo
09 editable
10 requiere corrección
11 estado
12 motivo corrección
13 paquete
14 procedimiento
15 target KB

Ejemplo conceptual de SQL base:
SELECT I.ID AS ID,
       I.CODIGO_SOL AS CODIGO_SOL,
       I.TITULO_DOC AS TITULO_DOC,
       I.IMAGEN_BLOB AS IMAGEN_BLOB,
       I.MIME_TYPE AS MIME_TYPE,
       I.NOMBRE_ARCHIVO AS NOMBRE_ARCHIVO,
       'S' AS ES_EDITABLE,
       'N' AS REQUIERE_CORRECCION,
       CAST(NULL AS VARCHAR2(50)) AS ESTADO_IMAGEN,
       CAST(NULL AS VARCHAR2(4000)) AS MOTIVO_CORRECCION
FROM APP_IMAGENES I
WHERE I.CODIGO_SOL = :PXX_CODIGO_SOL
ORDER BY I.ID;

En la nueva variante NO asumas que APP_IMAGENES ni estas columnas físicas siguen siendo el origen. Conserva el contrato lógico y adapta el origen según lo que te indique.

## 3. Persistencia / contrato PL/SQL
La evolución del proyecto usa nombres formales de negocio estilo:
pIdImagen
pIdSolicitud
pNombreArchivo
pTamanoBytes
pExtension
pMimeType
pContenido
pEstadoActual
pEstadoNuevo
pOperacion
pCodigoError
pMensajeUsuario
pMensajeTecnico

Históricamente el contrato incluyó pEstado/pOperacion; la aplicación final evolucionó a pEstadoActual/pEstadoNuevo y pMensajeUsuario. **Inspecciona el SQL de v5.0.0 antes de asumir la firma exacta que ejecuta esta build.**
- pOperacion se deriva server-side (CARGA/CORRECCION), nunca se confía en un valor del navegador.
- El paquete debe reconsultar el estado/autorización real.
- Valida solicitud/documento/permisos/estado/MIME/extensión/tamaño.
- Decodifica Base64 a BLOB.
- Verifica tamaño BLOB real contra tamaño declarado.
- Convención OUT: 0 éxito; distinto de 0 error funcional; mensaje usuario + mensaje técnico.
- No inventes columnas de estado/corrección en tablas si no existen.
- Cuidado con reemplazos globales: parámetros de negocio como pMimeType NO deben alterar APIs internas de APEX como create_plugin_file(p_mime_type=>...).

## 4. Flujo de galería
- Documentos preexistentes pueden tener BLOB vacío.
- Todos los documentos requeridos; no hay borrado normal: una imagen existente se reemplaza.
- La imagen vieja permanece hasta que SAVE de reemplazo termine correctamente.
- Galería 2×N en móvil, cards responsivas.
- v5.0.0: tarjetas/miniaturas de galería usan border-radius **8px**.
- Documento sin imagen usa exactamente la clase corporativa **`bi bi-image-circle`**. La app ya carga esa librería; el plugin NO debe importar otra librería por ello.
- La app ya aplica **Nunito Sans globalmente**. El plugin no debe declarar `font-family` ni shorthand `font:` que sustituya la fuente.
- Color primario configurable `--apxisdk-primary` / corporativo.
- Corrección: borde rojo y motivo cuando REQUIERE_CORRECCION lógico lo indique; no hardcodear nombres de estados de negocio en JS.
- Editable, requiere corrección, estado y motivo son conceptos separados.
- Cuando no editable: galería/visor siguen disponibles, pero no aparecen acciones de agregar/reemplazar; SAVE también debe bloquearse server-side.

## 5. Visor de documentos
Al pulsar una miniatura cargada abre lightbox/fullscreen.
Desde v4.4.12 y preservado en v5.0.0:
- Zoom 1×–5×.
- Móvil/tablet: pinch con dos dedos.
- Con zoom >1: pan con un dedo.
- Desktop: rueda para zoom y arrastre para pan.
- Doble clic alterna 1×/2×.
- Al cerrar/cambiar documento resetea 1×.
- Es puramente visual: no modifica BLOB ni editor.
No confundas el visor con el editor.

## 6. Editor
- Modal/bottom-sheet responsive; mobile y desktop.
- Guardar verde primario y Cancelar blanco/gris; full width móvil.
- Reintentar origen dentro del editor: “Volver a tomar” o “Elegir otra imagen”.
- Acciones rápidas Retry + Enderezar.
- Herramientas móvil: fila 1: -90°, +90°, zoom -, zoom +; fila 2: Restablecer, Imagen completa.
- Zoom -/+ se deshabilita en límites.
- Crop con 8 handles.
- Crop inicial = imagen completa.
- “Imagen completa” selecciona toda la imagen respetando orientación/enderezado actual; Restablecer es el reset real.
- Arrastre/pan/touch deben permanecer suaves.
- Crop final nunca puede contener checkerboard/vacío: restricciones mantienen el crop cubierto por píxeles reales.
- Rotar ±90° preserva lógicamente los mismos píxeles seleccionados; full-image sigue full-image.
- No free-rotation por gesto.
- Orientación landscape móvil ya fue corregida; no reintroducir desaparición/ocultamiento de herramientas.

## 7. Enderezar
- Analiza únicamente el crop/selección actual, no necesariamente la imagen fuente completa.
- Corrección conservadora de inclinación pequeña (~±15°), idempotente.
- Web Worker es optimización, NO punto único de falla.
- Si Worker falla/timeout, debe ejecutar fallback main-thread `analyzeStraightenPixels(...)`.
- No reintroducir el bug donde Enderezar fallaba para todas las imágenes.

## 8. Compresión
- Prioridad calidad/velocidad; objetivo configurable, históricamente ~150 KB ±8 KB, max ~1920.
- createImageBitmap/OffscreenCanvas/Worker con fallback.
- Base64 se produce después de comprimir.
- PNG: conservar PNG únicamente si el resultado realmente contiene transparencia.
- PNG opaco debe convertirse a JPEG y pasar por compresión adaptativa.
- PNG con alpha puede superar target.
- Existe `_canvasHasTransparency(canvas)` / lógica equivalente.
- No reintroducir el problema de PNG opaco de ~770 KB.
- Loader textual: Preparando imagen…, Optimizando imagen…, Guardando imagen…; sin porcentajes.

## 9. SAVE y feedback
- Guardar se deshabilita mientras guarda.
- Error: editor permanece abierto y conserva estado; toast dentro del editor, no apex.message.alert detrás del modal; Guardar vuelve a habilitarse.
- Éxito: toast “Imagen guardada correctamente.” y puede seguir visible después de cerrar editor.
- No bloquear UI innecesariamente.

## 10. Correcciones históricas APEX que NO deben regresar
- APEX 24.2.8: `apex_plugin.t_region_render_result` no dispone de `ajax_identifier`; no asignarlo. Usar `apex_plugin.get_ajax_identifier`.
- Plugin File URLs van separados por saltos de línea, NO con `:`.
- ORA-01006 en SQL de editabilidad: USING solo cuando realmente existe el bind.
- `create_plugin_attribute` debe usar únicamente argumentos/tipos comprobados compatibles; mappings se manejaron como TEXT.
- Instalador: los hex chunks de `wwv_flow_imp.g_varchar2_table` deben ser **máximo 3000 caracteres hex** por asignación.
- Siempre validar round-trip de archivos embebidos: concatenar chunks, `bytes.fromhex(...)` y comparar byte a byte con archivo original.
- No modificar accidentalmente `p_mime_type` de `wwv_flow_imp_shared.create_plugin_file`.

## 11. Corrección visual importante v4.4.11 preservada
Había una línea/borde residual debajo de la galería. La causa real era la `.apxisdk__card` raíz persistente en modo integración, no la tarjeta interna del editor. Se corrigió con reglas específicas para:
`.apxisdk--integration > .apxisdk__card`
quitando border/radius/background/shadow del wrapper de integración y ocultando editor cerrado. **No reintroducir ese borde.**

## 12. Principios para esta nueva variante
1. Usa v5.0.0 adjunto como baseline estable.
2. Antes de editar, inspecciona ZIP, JS, CSS, PL/SQL, installer y README.
3. Cambia solamente lo necesario para el nuevo origen/modelo de datos.
4. Conserva editor, viewer, gestures, compresión, corrección, UX y fixes salvo instrucción expresa.
5. No inventes tablas/columnas/procedimientos. Pídeme o usa el nuevo esquema que yo suministre.
6. Mantén compatibilidad APEX 24.2.8.
7. Cada versión debe incluir ZIP instalable, README actualizado e installer SQL.
8. Antes de entregar: syntax-check JS, ZIP integrity, ausencia de font-family/font override, chunks <=3000, round-trip de estáticos, y comparación byte-a-byte de archivos que se supone no cambiaron.
9. Si un cambio solicitado parece romper una corrección previa, detente y explica el conflicto antes de implementarlo.

## 13. Fuente de verdad
El ZIP **ApexImageSDK-APEX-Plugin-v5.0.0-INSTALLABLE.zip** que adjunto manda sobre cualquier detalle de este prompt si existe una discrepancia de implementación. Este prompt explica decisiones e invariantes; el ZIP contiene el estado exacto del código.

Mi siguiente mensaje describirá el NUEVO ORIGEN DE DATOS y las diferencias funcionales de la variante. Primero analiza el ZIP y dime qué componentes concretos deben adaptarse, sin modificar todavía las funciones no relacionadas.
