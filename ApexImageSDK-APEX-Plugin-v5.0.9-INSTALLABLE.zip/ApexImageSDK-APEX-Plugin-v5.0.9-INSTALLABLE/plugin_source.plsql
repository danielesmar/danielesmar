function safe_col(p_value varchar2) return varchar2 is
begin
  return dbms_assert.simple_sql_name(trim(p_value));
end;

function is_true(p_value varchar2) return boolean is
begin
  return upper(trim(nvl(p_value,'N'))) in ('Y','YES','S','SI','1','TRUE');
end;

function f_render(
 p_region in apex_plugin.t_region,p_plugin in apex_plugin.t_plugin,p_is_printer_friendly in boolean
) return apex_plugin.t_region_render_result is
 l_result apex_plugin.t_region_render_result;
 l_host varchar2(255):=nvl(p_region.static_id,'apxisdk_'||p_region.id)||'_sdk';
 l_ajax varchar2(4000):=apex_plugin.get_ajax_identifier;
 l_code varchar2(32767);
begin
 htp.p('<div id="'||apex_escape.html_attribute(l_host)||'" class="apxisdk-plugin-root"></div>');
 l_code:='ApexImageSDKPlugin.init({'||
   'regionId:'||apex_javascript.add_value(l_host,false)||','||
   'ajaxIdentifier:'||apex_javascript.add_value(l_ajax,false)||','||
   'requestItem:'||apex_javascript.add_value(p_region.attribute_01,false)||','||
   'componentMode:'||apex_javascript.add_value(upper(nvl(p_region.attribute_02,'CARGA')),false)||','||
   'workerUrl:'||apex_javascript.add_value(p_plugin.file_prefix||'apex-image-worker.js',false)||','||
   'targetKB:'||to_char(nvl(to_number(p_region.attribute_15),150))||',maxWidth:1920,maxHeight:1920,primaryColor:"#00683B",'||
   'showSummary:'||case when upper(nvl(p_region.attribute_18,'Y'))='Y' then 'true' else 'false' end||','||
   'emptyHtml:'||apex_javascript.add_value(nvl(p_region.attribute_19,''),false)||
   '}).catch(function(e){console.error("ApexImageSDK Plugin",e);});';
 apex_javascript.add_onload_code(p_code=>l_code,p_key=>'apxisdk_'||p_region.id);
 return l_result;
end;

function f_ajax(p_region in apex_plugin.t_region,p_plugin in apex_plugin.t_plugin)
 return apex_plugin.t_region_ajax_result is
 l_result apex_plugin.t_region_ajax_result;
 l_action varchar2(20):=upper(nvl(apex_application.g_x10,'LIST'));
 l_request varchar2(4000):=apex_util.get_session_state(p_region.attribute_01);
 l_doc varchar2(4000):=apex_application.g_x01;
 l_mode varchar2(20):=upper(nvl(p_region.attribute_02,'CARGA'));
 l_idc varchar2(261):=safe_col(p_region.attribute_03);
 l_reqc varchar2(261):=safe_col(p_region.attribute_04);
 l_titlec varchar2(261):=safe_col(p_region.attribute_05);
 l_blobc varchar2(261):=safe_col(p_region.attribute_06);
 l_mimec varchar2(261):=safe_col(p_region.attribute_07);
 l_filec varchar2(261):=safe_col(p_region.attribute_08);
 l_editc varchar2(261):=safe_col(p_region.attribute_09);
 l_corrc varchar2(261):=case when p_region.attribute_10 is not null then safe_col(p_region.attribute_10) end;
 l_statusc varchar2(261):=case when p_region.attribute_11 is not null then safe_col(p_region.attribute_11) end;
 l_reasonc varchar2(261):=case when p_region.attribute_12 is not null then safe_col(p_region.attribute_12) end;
 l_statusdescc varchar2(261):=safe_col(p_region.attribute_17);
 l_persistence_proc varchar2(4000):=dbms_assert.qualified_sql_name(trim(p_region.attribute_13));
 l_new_status varchar2(4000):=trim(p_region.attribute_16);
 l_sql varchar2(32767); l_data apex_plugin_util.t_column_value_list2; l_rows pls_integer:=0;
 l_id varchar2(4000);l_req varchar2(4000);l_title varchar2(4000);l_loaded varchar2(20);
 l_edit varchar2(30);l_corr varchar2(30);l_status varchar2(4000);l_reason varchar2(4000);
 l_blob blob;l_clob clob;l_mime varchar2(100);l_file varchar2(255);l_size number;l_ext varchar2(30);
 l_err varchar2(4000);l_msg varchar2(4000);l_tech varchar2(4000);
 function val(c pls_integer,r pls_integer) return varchar2 is
 begin return apex_plugin_util.get_value_as_varchar2(l_data(c).data_type,l_data(c).value_list(r)); end;
begin
 if l_request is null then l_request:=apex_application.g_x02;end if;
 if l_request is null then l_request:=apex_application.g_x01;end if;
 if p_region.source is null then raise_application_error(-20001,'Debe definir la Consulta SQL de la región.');end if;
 if l_mode not in ('CARGA','CORRECCION') then raise_application_error(-20002,'Tipo de componente inválido.');end if;
 if l_mode='CORRECCION' and (l_corrc is null or l_reasonc is null) then
   raise_application_error(-20003,'En modo CORRECCION debe mapear Requiere corrección y Motivo.');end if;

 if l_action='LIST' then
   l_sql:='select to_char(q.'||l_idc||') sdk_id,to_char(q.'||l_reqc||') sdk_req,to_char(q.'||l_titlec||') sdk_title,'||
     'case when q.'||l_blobc||' is null then ''0'' else ''1'' end sdk_loaded,'||
     'to_char(q.'||l_editc||') sdk_edit,'||
     case when l_corrc is null then '''N''' else 'to_char(q.'||l_corrc||')' end||' sdk_corr,'||
     case when l_statusc is null then 'cast(null as varchar2(4000))' else 'to_char(q.'||l_statusc||')' end||' sdk_status,'||
     case when l_reasonc is null then 'cast(null as varchar2(4000))' else 'substr(to_char(q.'||l_reasonc||'),1,4000)' end||' sdk_reason,'||
     'substr(to_char(q.'||l_statusdescc||'),1,4000) sdk_status_desc '||
     'from ('||p_region.source||') q';
   l_data:=apex_plugin_util.get_data2(p_sql_statement=>l_sql,p_min_columns=>9,p_max_columns=>9,p_component_name=>p_region.name,p_auto_bind_items=>true);
   if l_data.count>0 then l_rows:=l_data(1).value_list.count;end if;
   apex_json.open_object;apex_json.write('success',true);apex_json.write('requestId',l_request);apex_json.open_array('documents');
   for r in 1..l_rows loop
     l_id:=val(1,r);l_req:=val(2,r);l_title:=val(3,r);l_loaded:=val(4,r);l_edit:=val(5,r);l_corr:=val(6,r);l_status:=val(7,r);l_reason:=val(8,r);
     apex_json.open_object;apex_json.write('id',l_id);apex_json.write('requestId',l_req);apex_json.write('title',l_title);
     apex_json.write('loaded',l_loaded='1');apex_json.write('editable',is_true(l_edit));apex_json.write('requiresCorrection',is_true(l_corr));
     apex_json.write('status',l_status);apex_json.write('reason',l_reason);apex_json.write('statusDescription',val(9,r));apex_json.close_object;
   end loop;apex_json.close_array;apex_json.write('total',l_rows);
   declare n number:=0;begin for r in 1..l_rows loop if val(4,r)='1' then n:=n+1;end if;end loop;apex_json.write('loaded',n);apex_json.write('pending',l_rows-n);end;
   apex_json.close_object;

 elsif l_action='GET' then
   l_sql:='select to_char(q.'||l_idc||') sdk_id,q.'||l_blobc||' sdk_blob,to_char(q.'||l_mimec||') sdk_mime,to_char(q.'||l_filec||') sdk_file,to_char(q.'||l_reqc||') sdk_req from ('||p_region.source||') q';
   l_data:=apex_plugin_util.get_data2(p_sql_statement=>l_sql,p_min_columns=>5,p_max_columns=>5,p_component_name=>p_region.name,
     p_search_type=>apex_plugin_util.c_search_exact_case,p_search_column_name=>'SDK_ID',p_search_string=>l_doc,p_auto_bind_items=>true);
   if l_data.count=0 or l_data(1).value_list.count=0 then raise no_data_found;end if;
   l_req:=val(5,1);if l_request is not null and l_req<>l_request then raise_application_error(-20011,'Documento fuera de la solicitud actual.');end if;
   l_blob:=l_data(2).value_list(1).blob_value;if l_blob is null then raise no_data_found;end if;
   l_mime:=val(3,1);l_file:=val(4,1);
   apex_json.open_object;apex_json.write('success',true);apex_json.write('mimeType',nvl(l_mime,'image/jpeg'));apex_json.write('fileName',nvl(l_file,'imagen'));
   apex_json.write('base64',apex_web_service.blob2clobbase64(l_blob));apex_json.close_object;

 elsif l_action='SAVE' then
   if apex_application.g_f01.count=0 then raise_application_error(-20012,'No se recibió contenido de imagen.');end if;
   l_sql:='select to_char(q.'||l_idc||') sdk_id,to_char(q.'||l_reqc||') sdk_req,to_char(q.'||l_editc||') sdk_edit,'||
     case when l_statusc is null then 'cast(null as varchar2(4000))' else 'to_char(q.'||l_statusc||')' end||' sdk_status from ('||p_region.source||') q';
   l_data:=apex_plugin_util.get_data2(p_sql_statement=>l_sql,p_min_columns=>4,p_max_columns=>4,p_component_name=>p_region.name,
     p_search_type=>apex_plugin_util.c_search_exact_case,p_search_column_name=>'SDK_ID',p_search_string=>l_doc,p_auto_bind_items=>true);
   if l_data.count=0 or l_data(1).value_list.count=0 then raise no_data_found;end if;
   l_req:=val(2,1);l_edit:=val(3,1);l_status:=val(4,1);
   if l_req<>apex_application.g_x02 then raise_application_error(-20013,'El documento no pertenece a la solicitud enviada.');end if;
   if not is_true(l_edit) then raise_application_error(-20014,'La imagen no está habilitada para modificación.');end if;
   if lower(apex_application.g_x04) not in ('image/jpeg','image/png') then raise_application_error(-20015,'Tipo de imagen no permitido.');end if;
   dbms_lob.createtemporary(l_clob,true);
   for i in 1..apex_application.g_f01.count loop dbms_lob.writeappend(l_clob,length(apex_application.g_f01(i)),apex_application.g_f01(i));end loop;
   l_size:=to_number(apex_application.g_x05);l_ext:=lower(regexp_substr(apex_application.g_x03,'\.([^.]+)$',1,1,null,1));
   if l_ext is null then l_ext:=case lower(apex_application.g_x04) when 'image/png' then 'png' else 'jpg' end;end if;
   execute immediate 'begin '||l_persistence_proc||
     '(pIdImagen=>:1,pIdSolicitud=>:2,pNombreArchivo=>:3,pTamanoBytes=>:4,pExtension=>:5,pMimeType=>:6,pContenido=>:7,pEstadoActual=>:8,pEstadoNuevo=>:9,pOperacion=>:10,pCodigoError=>:11,pMensajeUsuario=>:12,pMensajeTecnico=>:13); end;'
     using in l_doc,in apex_application.g_x02,in apex_application.g_x03,in l_size,in l_ext,in lower(apex_application.g_x04),in l_clob,in l_status,in l_new_status,in l_mode,out l_err,out l_msg,out l_tech;
   if nvl(trim(l_err),'0')<>'0' then
     apex_debug.error('ApexImageSDK package error %s: %s',l_err,l_tech);
     apex_json.open_object;
     apex_json.write('success',false);
     apex_json.write('codigoError',l_err);
     apex_json.write('mensajeUsuario',nvl(l_msg,'No fue posible actualizar la imagen.'));
     apex_json.write('mensajeTecnico',l_tech);
     apex_json.close_object;
   else
     apex_json.open_object;
     apex_json.write('success',true);
     apex_json.write('codigoError',nvl(l_err,'0'));
     apex_json.write('mensajeUsuario',l_msg);
     apex_json.write('mensajeTecnico',l_tech);
     apex_json.write('id',l_doc);
     apex_json.write('newStatus',case when l_mode='CORRECCION' then l_new_status else null end);
     apex_json.close_object;
   end if;
   if dbms_lob.istemporary(l_clob)=1 then dbms_lob.freetemporary(l_clob);end if;
 else raise_application_error(-20020,'Acción no soportada: '||l_action);end if;
 return l_result;
exception
 when no_data_found then
   if dbms_lob.istemporary(l_clob)=1 then dbms_lob.freetemporary(l_clob);end if;
   apex_json.open_object;apex_json.write('success',false);apex_json.write('message','Documento o imagen no encontrado.');apex_json.close_object;return l_result;
 when others then
   if dbms_lob.istemporary(l_clob)=1 then dbms_lob.freetemporary(l_clob);end if;
   apex_debug.error('ApexImageSDK v5.0.7: %s',sqlerrm);
   apex_json.open_object;
   apex_json.write('success',false);
   apex_json.write('codigoError',sqlcode);
   apex_json.write('mensajeUsuario','No fue posible procesar la imagen.');
   apex_json.write('mensajeTecnico',sqlerrm);
   apex_json.close_object;
   return l_result;
end;