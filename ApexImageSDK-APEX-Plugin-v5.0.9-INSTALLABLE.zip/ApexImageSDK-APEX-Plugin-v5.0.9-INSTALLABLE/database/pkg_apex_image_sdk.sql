create or replace package pkg_apex_image_sdk as

    procedure actualizar_imagen (
        pIdImagen       in  varchar2,
        pIdSolicitud    in  varchar2,
        pNombreArchivo  in  varchar2,
        pTamanoBytes    in  number,
        pExtension       in  varchar2,
        pMimeType       in  varchar2,
        pContenido       in  clob,
        pEstadoActual   in  varchar2,
        pEstadoNuevo    in  varchar2,
        pOperacion       in  varchar2,
        pCodigoError    out number,
        pMensajeUsuario   out varchar2,
        pMensajeTecnico out varchar2
    );

end pkg_apex_image_sdk;
/

create or replace package body pkg_apex_image_sdk as

    procedure actualizar_imagen (
        pIdImagen       in  varchar2,
        pIdSolicitud    in  varchar2,
        pNombreArchivo  in  varchar2,
        pTamanoBytes    in  number,
        pExtension       in  varchar2,
        pMimeType       in  varchar2,
        pContenido       in  clob,
        pEstadoActual   in  varchar2,
        pEstadoNuevo    in  varchar2,
        pOperacion       in  varchar2,
        pCodigoError    out number,
        pMensajeUsuario   out varchar2,
        pMensajeTecnico out varchar2
    ) is
        l_id              app_imagenes.id%type;
        l_blob            blob;
        l_tamano_real     number;
        l_firma           varchar2(16);
        l_mime_real       varchar2(100);
        l_extension_real  varchar2(10);
        l_operacion       varchar2(20);
        l_estado_actual   varchar2(100);
        l_estado_nuevo    varchar2(100);
        l_usuario         varchar2(100);
        l_existe          number;
    begin
        pCodigoError := 0;
        pMensajeUsuario := null;
        pMensajeTecnico := null;

        l_operacion     := upper(trim(pOperacion));
        l_estado_actual := upper(trim(pEstadoActual));
        l_estado_nuevo  := upper(trim(pEstadoNuevo));

        if trim(pIdImagen) is null or trim(pIdSolicitud) is null then
            pCodigoError := 1001;
            pMensajeUsuario := 'No se recibió la identificación completa del documento.';
            return;
        end if;

        if pContenido is null or dbms_lob.getlength(pContenido) = 0 then
            pCodigoError := 1002;
            pMensajeUsuario := 'No se recibió contenido de imagen.';
            return;
        end if;

        if l_operacion not in ('CARGA','CORRECCION') then
            pCodigoError := 1003;
            pMensajeUsuario := 'La operación solicitada no es válida.';
            pMensajeTecnico := 'Operación recibida: '||substr(pOperacion,1,100);
            return;
        end if;

        if l_operacion = 'CORRECCION' and l_estado_nuevo is null then
            pCodigoError := 1004;
            pMensajeUsuario := 'No se configuró el estado nuevo para la corrección.';
            return;
        end if;

        begin
            l_id := to_number(trim(pIdImagen));
        exception
            when value_error then
                pCodigoError := 1005;
                pMensajeUsuario := 'El identificador de imagen no es válido.';
                return;
        end;

        select count(*)
          into l_existe
          from app_imagenes
         where id = l_id
           and codigo_sol = pIdSolicitud;

        if l_existe = 0 then
            pCodigoError := 1006;
            pMensajeUsuario := 'El documento no pertenece a la solicitud indicada.';
            return;
        end if;

        /*
          VALIDACIÓN DE ESTADO AUTORITATIVO
          ---------------------------------
          pEstadoActual llega desde el SQL del plug-in como contexto.
          Antes del UPDATE debe reconsultarse el estado real en la tabla corporativa
          que lo almacena.

          Regla indicada para CORRECCION:
            E = En corrección       -> permite cargar -> nuevo estado P
            P = Pendiente revisión  -> permite cargar -> permanece P

          APP_IMAGENES no contiene actualmente una columna ESTADO, por lo que este
          paquete no inventa dónde se persiste. Sustituya este bloque por la consulta
          a la tabla corporativa de estados cuando esté definida.

          Ejemplo conceptual:
             select estado into l_estado_bd
               from <TABLA_ESTADO>
              where ... for update;

             if l_operacion = 'CORRECCION'
                and l_estado_bd not in ('E','P') then
                 devolver error funcional;
             end if;

             if l_estado_bd <> l_estado_actual then
                 devolver error por cambio concurrente;
             end if;
        */

        l_blob := apex_web_service.clobbase642blob(pContenido);

        if l_blob is null or dbms_lob.getlength(l_blob) = 0 then
            pCodigoError := 1007;
            pMensajeUsuario := 'La imagen está vacía o no pudo decodificarse.';
            return;
        end if;

        l_tamano_real := dbms_lob.getlength(l_blob);
        l_firma := rawtohex(dbms_lob.substr(l_blob,8,1));

        if substr(l_firma,1,6) = 'FFD8FF' then
            l_mime_real := 'image/jpeg';
            l_extension_real := 'jpg';
        elsif l_firma = '89504E470D0A1A0A' then
            l_mime_real := 'image/png';
            l_extension_real := 'png';
        else
            pCodigoError := 1008;
            pMensajeUsuario := 'El contenido no corresponde a una imagen JPEG o PNG válida.';
            pMensajeTecnico := 'Firma detectada: '||nvl(l_firma,'(NULL)');
            return;
        end if;

        if lower(trim(pMimeType)) <> l_mime_real then
            pCodigoError := 1009;
            pMensajeUsuario := 'El MIME recibido no coincide con el contenido.';
            pMensajeTecnico := 'MIME enviado='||pMimeType||'; detectado='||l_mime_real;
            return;
        end if;

        if lower(replace(trim(pExtension),'.','')) not in
           (l_extension_real,
            case when l_extension_real='jpg' then 'jpeg' else l_extension_real end)
        then
            pCodigoError := 1010;
            pMensajeUsuario := 'La extensión no coincide con el contenido.';
            return;
        end if;

        if pTamanoBytes is not null and pTamanoBytes <> l_tamano_real then
            pCodigoError := 1011;
            pMensajeUsuario := 'El tamaño informado no coincide con la imagen recibida.';
            pMensajeTecnico := 'Enviado='||pTamanoBytes||'; real='||l_tamano_real;
            return;
        end if;

        l_usuario := substr(coalesce(sys_context('APEX$SESSION','APP_USER'),user),1,100);

        update app_imagenes
           set imagen_blob    = l_blob,
               nombre_archivo = substr(pNombreArchivo,1,255),
               mime_type      = l_mime_real,
               tamano_bytes   = l_tamano_real,
               fecha_carga    = sysdate,
               usuario_carga  = l_usuario
         where id = l_id
           and codigo_sol = pIdSolicitud;

        if sql%rowcount = 0 then
            pCodigoError := 1012;
            pMensajeUsuario := 'No fue posible actualizar la imagen.';
            return;
        end if;

        /*
          TRANSICIÓN DE ESTADO
          --------------------
          En CORRECCION, después de validar el estado real:
              E -> P
              P -> P

          Use pEstadoNuevo como transición configurada por la región, pero valide
          contra las reglas corporativas antes de persistirla.

          Ejemplo conceptual:
             if l_operacion = 'CORRECCION' then
                 update <TABLA_ESTADO>
                    set estado = l_estado_nuevo
                  where ...;
             end if;

          No se implementa contra APP_IMAGENES porque esa tabla no posee ESTADO.
        */

        pCodigoError := 0;
        pMensajeUsuario := null;
        pMensajeTecnico := null;

        -- Sin COMMIT.
    exception
        when others then
            pCodigoError := sqlcode;
            pMensajeUsuario := 'Ocurrió un error al actualizar la imagen.';
            pMensajeTecnico := substr(sqlerrm,1,4000);
    end actualizar_imagen;

end pkg_apex_image_sdk;
/
